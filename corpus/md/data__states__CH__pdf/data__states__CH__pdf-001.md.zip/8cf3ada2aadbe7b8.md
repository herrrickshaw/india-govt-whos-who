---
doc_id: "8cf3ada2aadbe7b8"
source_url: "https://chandigarhenvis.gov.in/sites/default/files/LawsNotificationsRules/showfile-compressed.pdf"
ministry: "Environment Department, Chandigarh"
title: "Hazardous and Other Wastes (Management and Transboundary Movement) Rules, 2016"
date: ""
pages: 20
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6282ce8d57d2ff37"
---

<!-- page 1 -->

[PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY, PART II,
SECTION 3, SUB-SECTION (i)]
GOVERNMENT OF INDIA
MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE

NOTIFICATION
New Delhi, the 04th April, 2016
G.S.R N0. 395 (E). - Whereas the draft rules, namely the Hazardous And Other Wastes
(Management and Transboundary Movement) Rules, 2015, were published by the Government of
India in the Ministry of Environment, Forest and Climate Change vide number G.S.R. 582(E),
dated the 24th July, 2015 in the Gazette of India, Extraordinary Part II, section 3, sub—section (ii)
inviting objections and suggestions from all persons likely to be affected thereby, before the
expiry of the period of sixty days from the date on which copies of the Gazette containing the said
notification were made available to the public;
AND WHEREAS the copies of the said Gazette containing the said notification were
made available to the public on the 24th day of July, 2015;
AND WHEREAS the objections and suggestions received within the specified period from
the public in respect of the said draft rules have been duly considered by the Central
Government;
NOW, THEREFORE, in exercise of the powers conferred by sections 6, 8 and 25 of the
Environment (Protection) Act, 1986 (29 of 1986), and in supersession of the Hazardous Wastes
(Management, Handling and Transboundary Movement) Rules, 2008, except as respects things
done or omitted to be done before such supersession, the Central Government hereby makes the
following rules, namely:-

CHAPTER I
PRELI M INARY
1.
Short title and commencement. - (1) These rules may be called the Hazardous and
Other Wastes (Management and Transboundary Movement) Rules, 2016.
(2) They shall come into force on the date of their publication in the Official Gazette.
2.
Application. - These rules shall apply to the management of hazardous and other wastes
as specified in the Schedules to these rules but shall not apply to (a)

(b)

waste-water and exhaust gases as covered under the provisions of the Water
(Prevention and Control of Pollution) Act, 1974 (6 of 1974) and the Air (Prevention and
Control of Pollution) Act, 1981 (14 of 1981) and the rules made thereunder and as
amended from time to time;
wastes arising out of the operation from ships beyond five kilometres of the relevant
baseline as covered under the provisions of the Merchant Shipping Act, 1958 (44 of
1958) and the rules made thereunder and as amended from time to time;

1

<!-- page 2 -->

(c)
(d)
(e)

radio-active wastes as covered under the provisions of the Atomic Energy Act, 1962
(33 of 1962) and the rules made thereunder and as amended from time to time;
bio-medical wastes covered under the Bio-Medical Wastes (Management and
Handling) Rules, 1998 made under the Act and as amended from time to time; and
wastes covered under the Municipal Solid Wastes (Management and Handling) Rules,
2000 made under the Act and as amended from time to time.
Definitions. - (1) In these rules, unless the context otherwise requires,-

1.

“Act” means the Environment (Protection) Act, 1986 (29 of 1986);

2.

“actual user” means an occupier who procures and processes hazardous and other
waste for reuse, recycling, recovery, pre-processing, utilisation including coprocessing;

3.

“authorisation” means permission for generation, handling, collection, reception,
treatment, transport, storage, reuse, recycling, recovery, pre—processing, utilisation
including co—processing and disposal of hazardous wastes granted under sub-rule (2)
of rule 6;

4.

“Basel Convention” means the United Nations Environment Programme Convention
on the Control of Transboundary Movement of Hazardous Wastes and their Disposal;

5.

“captive treatment, storage and disposal facility” means a facility developed within the
premises of an occupier for treatment, storage and disposal of wastes generated
during manufacture, processing, treatment, package, storage, transportation, use,
collection, destruction, conversion, offering for sale, transfer or the like of hazardous
and other wastes;

6.

“Central Pollution Control Board” means the Central Pollution Control Board
constituted under sub-section (1) of section 3 of the Water (Prevention and Control of
Pollution) Act, 1974 (6 of 1974);

7.

“common treatment, storage and disposal facility” means a common facility identified
and established individually orjointly or severally by the State Government, occupier,
operator of a facility or any association of occupiers that shall be used as common
facility by multiple occupiers or actual users for treatment, storage and disposal of the
hazardous and other wastes;

8.

“co—processing” means the use of waste materials in manufacturing processes for the
purpose of energy or resource recovery or both and resultant reduction in the use of
conventional fuels or raw materials or both through substitution;

9.

“critical care medical equipment” means life saving equipment and includes such
equipment as specified by the Ministry of Health and Family Welfare from time to
time;

10.

“disposal” means any operation which does not lead to reuse, recycling, recovery,
utilisation including co—processing and includes physico-chemical treatment, biological
treatment, incineration and disposal in secured landfill;

<!-- page 3 -->

11.

“export”, with its grammatical variations and cognate expressions, means taking out
of India to a place outside India;

12.

“exporter” means any person or occupier under the jurisdiction of the exporting
country who exports hazardous or other wastes, including the country which exports
hazardous or other waste;

13.

“environmentally sound management of hazardous and other wastes” means taking
all steps required to ensure that the hazardous and other wastes are managed in a
manner which shall protect health and the environment against the adverse effects
which may result from such waste;

14.

“environmentally sound technologies” means any technology approved by the Central
Government from time to time;

15.

“facility” means any establishment wherein the processes incidental to the generation,
handling, collection, reception, treatment, storage, reuse, recycling, recovery, preprocessing, co-processing, utilisation and disposal of hazardous and, or, other wastes
are carried out;

16.

“Form” means a form appended to these rules;

17.

“hazardous waste” means any waste which by reason of characteristics such as
physical, chemical, biological, reactive, toxic, flammable, explosive or corrosive,
causes danger or is likely to cause danger to health or environment, whether alone or
in contact with other wastes or substances, and shall include (i) waste specified under column (3) of Schedule I;
(ii) waste having equal to or more than the concentration limits specified for the
constituents in class A and class B of Schedule II or any of the characteristics
as specified in class C of Schedule II; and
(iii) wastes specified in Part A of Schedule III in respect of import or export of
such wastes or the wastes not specified in Part A but exhibit hazardous
characteristics specified in Part C of Schedule III;

18.

“import”, with its grammatical variations and cognate expressions, means bringing into
India from a place outside India;

19.

“importer” mean any person or occupier who imports hazardous or other waste;

20.

“manifest” means transporting document prepared and signed by the sender
authorised in accordance with the provisions of these rules;

21.

“occupier” in relation to any factory or premises, means a person who has, control
over the affairs of the factory or the premises and includes in relation to any
hazardous and other wastes, the person in possession of the hazardous or other
waste;

22.

“operator of disposal facility” means a person who owns or operates a facility for
collection, reception, treatment, storage and disposal of hazardous and other wastes;

23.

“other wastes” means wastes specified in Part B and Part D of Schedule III for import
or export and includes all such waste generated indigenously within the country;

<!-- page 4 -->

24.

“pre—processing” means the treatment of waste to make it suitable for co-processing
or recycling or for any further processing;

25.

“recycling” means reclamation and processing of hazardous or other wastes in an
environmentally sound manner for the originally intended purpose or for other
purposes;

26.

“reuse” means use of hazardous or other waste for the purpose of its original use or
other use;

27.

“recovery” means any operation or activity wherein specific materials are recovered;

28.

“Schedule” means a Schedule appended to these rules;

29.

“State Government” in relation to a Union territory means, the Administrator thereof
appointed under article 239 of the Constitution;

30.

“State Pollution Control Board” means the State Pollution Control Board constituted
under section 4 of the Water (Prevention and Control of Pollution) Act, 1974 (6 of
1974) and includes, in relation to a Union territory, the Pollution Control Committee;

31.

“storage” mean storing any hazardous or other waste for a temporary period, at the
end of which such waste is processed or disposed of;

32.

“transboundary movement” means any movement of hazardous or other wastes from
an area under the jurisdiction of one country to or through an area under the
jurisdiction of another country or to or through an area not under the jurisdiction of any
country, provided that at least two countries are involved in the movement;

33.

“transport” means off-site movement of hazardous or other wastes by air, rail, road or
water;

34.

“transporter” means a person engaged in the off-site transportation of hazardous or
other waste by air, rail, road or water;

35.

“treatment” means a method, technique or process, designed to modify the physical,
chemical or biological characteristics or composition of any hazardous or other waste
so as to reduce its potential to cause harm;

36.

“used oil” means any oil(i)
(ii)

37.

derived from crude oil or mixtures containing synthetic 0“ including spent 0“,
used engine 0“, gear 0“, hydraulic oil, turbine oi|, compressor 0“, industrial
gear oi|, heat transfer 0“, transformer oil and their tank bottom sludges; and
suitable for reprocessing, if it meets the specification laid down in Part A of
Schedule V but does not include waste oil;

“utilisation” means use of hazardous or other waste as a resource;

<!-- page 5 -->

38.

“waste” means
materials that are not products or by-products, for which the
generator has no further use for the purposes of production, transformation or
consumption.
Explanation.- for the purposes of this clause,
(i)
waste includes the materials that may be generated during, the extraction of
raw materials, the processing of raw materials into intermediates and final
products, the consumption of final products, and through other human
activities and excludes residuals recycled or reused at the place of generation;
and
(ii)
by-product means a material that is not intended to be produced but gets
produced in the production process of intended product and is used as such;

39.

“waste oil” means any oil which includes spills of crude oil, emulsions, tank bottom
sludge and slop 0“ generated from petroleum refineries, installations or ships and can
be used as fuel in furnaces for energy recovery, if it meets the specifications laid
down in Part-B of Schedule V either as such or after reprocessing.

(2) Words and expressions used in these rules and not defined but defined in the Act shall have
the meanings respectively assigned to them in the Act.
CHAPTER II
PROCEDURE FOR MANAGEMENT OF HAZARDOUS AND OTHER WASTES
4.

Responsibilities of the occupier for management of hazardous and other wastes.-

(1) For the management of hazardous and other wastes, an occupier shall follow the following
steps, namely:(a) prevention;
(b) minimization;
(c) reuse,
(d) recycling;
(e) recovery, utilisation including co-processing;
(f) safe disposal.
(2) The occupier shall be responsible for safe and environmentally sound management of
hazardous and other wastes.
(3) The hazardous and other wastes generated in the establishment of an occupier shall be sent
or sold to an authorised actual user or shall be disposed of in an authorised disposal facility.
(4) The hazardous and other wastes shall be transported from an occupier’s establishment to an
authorised actual user or to an authorised disposal facility in accordance with the provisions of
these rules.
(5) The occupier who intends to get its hazardous and other wastes treated and disposed of by
the operator of a treatment, storage and disposal facility shall give to the operator of that facility,
such specific information as may be needed for safe storage and disposal.
(6) The occupier shall take all the steps while managing hazardous and other wastes to-

<!-- page 6 -->

(a) contain contaminants and prevent accidents and limit their consequences on human
beings and the environment; and
(b) provide persons working in the site with appropriate training, equipment and the
information necessary to ensure their safety.
5.
Responsibilities of State Government for environmentally sound management of
hazardous and other wastes. — (1) Department of Industry in the State or any other government
agency authorised in this regard by the State Government, to ensure earmarking or allocation of
industrial space or shed for recycling, pre-processing and other utilisation of hazardous or other
waste in the existing and upcoming industrial park, estate and industrial clusters;
(2) Department of Labour in the State or any other government agency authorised in this regard
by the State Government shall,(a) ensure
recognition and registration of workers involved in recycling, preprocessing and other utilisation activities;
(b) assist formation of groups of such workers to facilitate setting up such facilities;
(c) undertake
industrial skill development activities for the workers involved in
recycling, pre-processing and other utilisation;
(d) undertake annua| monitoring and to ensure safety and health of workers involved
in recycling, pre-processing and other utilisation.
(3) Every State Government may prepare integrated plan for effective implementation of these
provisions and to submit annual report to the Ministry of Environment, Forest and Climate
Change, in the Central Government.
6.
Grant of authorisation for managing hazardous and other wastes.- (1) Every occupier
of the facility who is engaged in handling, generation, collection, storage, packaging,
transportation, use, treatment, processing, recycling, recovery, pre-processing, co-processing,
utilisation, offering for sale, transfer or disposal of the hazardous and other wastes shall be
required to make an application in Form 1 to the State Pollution Control Board and obtain an
authorisation from the State Pollution Control Board within a period of sixty days from the date of
publication of these rules. Such application for authorisation shall be accompanied with a copy
each of the following documents, namely:(a) consent to establish granted by the State Pollution Control Board under the Water
(Prevention and Control of Pollution) Act, 1974 (25 of 1974) and the Air (Prevention and
Control of Pollution) Act, 1981 (21 of 1981);
(b) Consent to operate granted by the State Pollution Control Board under the Water
(Prevention and Control of Pollution) Act, 1974 (25 of 1974) and/or Air (Prevention and
Control of Pollution) Act, 1981, (21 of 1981);
(c) in case of renewal of authorisation, a seIf-certified compliance report in respect of effluent,
emission standards and the conditions specified in the authorisation for hazardous and
other wastes:
Provided that an application for renewal of authorisation may be made three months before
the expiry of such authorisation:
Provided further that(i) any person authorised under the provisions of the Hazardous Waste (Management,
Handling and Transboundary Movement) Rules, 2008, prior to the date of commencement

<!-- page 7 -->

(ii)

of these rules, shall not be required to make an application for authorisation till the period
of expiry of such authorisation;
any person engaged in recycling or reprocessing of the hazardous waste specified in
Schedule IV and having registration under the provisions of the Hazardous Waste
(Management, Handling and Transboundary Movement) Rules, 2008, shall not be
required to make an application for authorisation till the period of expiry of such
registration.

(2) On receipt of an application complete in all respects for the authorisation, the State Pollution
Control Board may, after such inquiry as it considers necessary, and on being satisfied that the
applicant possesses appropriate facilities for collection, storage, packaging, transportation,
treatment, processing, use, destruction, recycling, recovery, pre—processing, co-processing,
utilisation, offering for sale, transfer or disposal of the hazardous and other waste, as the case
may be, and after ensuring technical capabilities and equipment complying with the standard
operating procedure or other guidelines specified by the Central Pollution Control Board from time
to time and through site inspection, grant within a period of one hundred and twenty days, an
authorisation in Form 2 to the applicant, which shall be valid for a period of five years subject to
such conditions as may be laid down therein. For commonly recyclable hazardous waste as given
in Schedule IV, the guidelines already prepared by the Central Pollution Control Board shall be
followed:
Provided that in the case of an application for renewal of authorisation, the State Pollution
Control Board may, before granting such authorisation, satisfy itself that there has been no
violation of the conditions specified in the authorisation earlier granted by it and same shall be
recorded in the inspection report.
(3) The authorisation granted by the State Pollution Control Board under sub-rule (2) shall be
accompanied by a copy of the field inspection report signed by that Board indicating the
adequacy of facilities for collection, storage, packaging, transportation, treatment, processing,
use, destruction, recycling, recovery, pre-processing, co-processing, utilisation, offering for sale,
transfer or disposal of the hazardous and other wastes and compliance to the guidelines or
standard operating procedures specified by the Central Pollution Control Board from time to time.
(4) The State Pollution Control Board may, for the reasons to be recorded in writing and after
giving reasonable opportunity of being heard to the applicant, refuse to grant any authorisation
under these rules.
(5) Every occupier authorised under these rules, shall maintain a record of hazardous and other
wastes managed by him in Form 3 and prepare and submit to the State Pollution Control Board,
an annual return containing the details specified in Form 4 on or before the 30th day of June
following the financial year to which that return relates.
(6) The State Pollution Control Board shall maintain a register containing particulars of the
conditions imposed under these rules for management of hazardous and other wastes and it shall
be open for inspection during office hours to any interested or affected person.
(7) The authorised actual user of hazardous and other wastes shall maintain records of
hazardous and other wastes purchased in a passbook issued by the State Pollution Control
Board along with the authorisation.
(8) Handing over of the hazardous and other wastes to the authorised actual user shall be only
after making the entry into the passbook of the actual user.

<!-- page 8 -->

7.
Power to suspend or cancel an authorisation.- (1) The State Pollution Control Board,
may, if in its opinion the holder of the authorisation has failed to comply with any of the conditions
of the authorisation or with any provisions of the Act or these rules and after giving him a
reasonable opportunity of being heard and after recording reasons thereof in writing cancel or
suspend the authorisation issued under rule 6 for such period as it considers necessary in the
public interest.
(2) Upon suspension or cancellation of the authorisation, the State Pollution Control Board may
give directions to the person whose authorisation has been suspended or cancelled for the safe
storage and management of the hazardous and other wastes, and such occupier shall comply
with such directions.
8.
Storage of hazardous and other wastes.- (1) The occupiers of facilities may store the
hazardous and other wastes for a period not exceeding ninety days and shall maintain a record of
sale, transfer, storage, recycling, recovery, pre—processing, co-processing and utilisation of such
wastes and make these records available for inspection:
Provided that the State Pollution Control Board may extend the said period of ninety days
in following cases, namely:(i)
sma|| generators (up to ten tonnes per annum) up to one hundred and
eighty days of their annual capacity;
(ii)
actual users and disposal facility operators up to one hundred and eighty
days of their annual capacity,
(iii)
occupiers who do not have access to any treatment, storage, disposal
facility in the concerned State; or
(iv)
the waste which needs to be specifically stored for development of a
process for its recycling, recovery, pre-processing, co-processing or
utilisation;
(v)
in any other case, on justifiable grounds up to one hundred and eighty
days.
9.
Utilisation of hazardous and other wastes.- (1) The utilisation of hazardous and other
wastes as a resource or after pre—processing either for co-processing or for any other use,
including within the premises of the generator (if it is not part of process), shall be carried out only
after obtaining authorisation from the State Pollution Control Board in respect of waste on the
basis of standard operating procedures or guidelines provided by the Central Pollution Control
Board.
(2) Where standard operating procedures or guidelines are not available for specific utilisation,
the approval has to be sought from Central Pollution Control Board which shall be granting
approval on the basis of trial runs and thereafter, standard operating procedures or guidelines
shall be prepared by Central Pollution Control Board:
Provided, if trial run has been conducted for particular waste with respect to particular
utilisation and compliance to the environmental standards has been demonstrated, authorisation
may be granted by the State Pollution Control Board with respect to the same waste and
utilisation, without need of separate trial run by Central Pollution Control Board and such cases of
successful trial run, Central Pollution Control Board shall intimate all the State Pollution Control
Board regarding the same.
(3) No tria| runs shall be required for co-processing of waste in cement plants for which guidelines
by the Central Pollution Control Board are already available; however, the actual users sha||

<!-- page 9 -->

ensure compliance to the standards notified under the Environment (Protection) Act,1986 (29 of
1986), for cement plant with respect to co-processing of waste:
Provided that till the time the standards are notified, the procedure as applicable to other
kind of utilisation of hazardous and other waste, as enumerated above shall be followed.

10.
Standard Operating Procedure or guidelines for actual users.- The Ministry of
Environment, Forest and Climate Change or the Central Pollution Control Board may issue
guidelines or standard operating procedures for environmentally sound management of
hazardous and other wastes from time to time.

CHAPTER III
IMPORT AND EXPORT OF HAZARDOUS AND OTHER WASTES
11.
Import and export (transboundary movement) of hazardous and other wastes.- The
Ministry of Environment, Forest and Climate Change shall be the nodal Ministry to deal with the
transboundary movement of the hazardous and other wastes in accordance with the provisions of
these rules.
12.
Strategy for Import and export of hazardous and other wastes.- (1) No import of the
hazardous and other wastes from any country to India for disposal shall be permitted.
(2) The import of hazardous and other wastes from any country shall be permitted only for
recycling, recovery, reuse and utilisation including co-processing.
(3) The import of hazardous waste in Part A of Schedule ”I may be allowed to actual users with
the prior informed consent of the exporting country and shall require the permission of the
Ministry of Environment, Forest and Climate Change.
(4) The import of other wastes in Part B of Schedule ”I may be allowed to actual users with the
permission of the Ministry of Environment, Forest and Climate Change.
(5) The import of other wastes in Part D of Schedule III will be allowed as per procedure given in
rule 13 and as per the note below the said Schedule.
(6) No import of the hazardous and other wastes specified in Schedule VI shall be permitted.
(7) The export of hazardous and other wastes from India listed in Part A and Part B of Schedule
III and Schedule VI shall be with the permission of Ministry of Environment, Forest and Climate
Change. In case of applications for export of hazardous and other waste listed in Part A of
Schedule III and Schedule VI, they shall be considered on the basis of prior informed consent of
the importing country.
(8) The import and export of hazardous and other wastes not specified in Schedule III, but
exhibiting the hazardous characteristics outlined in Part C of Schedule I” shall require prior
written permission of the Ministry of Environment, Forest and Climate Change before it is
imported to or exported from India, as the case may be.

<!-- page 10 -->

13.
Procedure for import of hazardous and other wastes.- (1) Actual users intending to
import or transit for transboundary movement of hazardous and other wastes specified in Part A
and Part B of Schedule ”I shall apply in Form 5 along with the documents listed therein, to the
Ministry of Environment, Forest and Climate Change for the proposed import together with the
prior informed consent of the exporting country in respect of Part A of Schedule III waste, and
shall send a copy of the application, simultaneously, to the concerned State Pollution Control
Board for information and the acknowledgement in this respect from the concerned State
Pollution Control Board shall be submitted to the Ministry of Environment, Forest and Climate
Change along with the application.
(2) For the import of other wastes listed in Part D of Schedule III, the importer shall not require the
permission of the Ministry of Environment, Forest and Climate Change. However, the importer
shall furnish the required information as per Form 6 to the Customs authorities, accompanied
with the following documents in addition to those listed in Schedule VIII, wherever applicable. For
used electrical and electronic assemblies listed at serial numbers 4 (e) to 4(i) of Schedule V|||
(Basel No. B1110), there is no specific requirement of documentation under these rules:
(a) the import license from Directorate General of Foreign Trade, if applicable;
(b) the valid consents under the Water (Prevention and Control of Pollution) Act, 1974 (25 of
1974) and the Air (Prevention and Control of Pollution) Act, 1981 (21 of 1981)and the
authorisation under these rules as well as the authorisation under the E-Waste (Management
and Handling) Rules, 2011, as amended from time to time, whichever applicable;
(c) importer who is a trader, importing waste on behalf of actual users, shall obtain one time
authorisation in Form 7 and copy of this authorisation shall be appended to Form 6.
(3)
For Part B of Schedule III, in case of import of any used electrical and electronic
assemblies or spares or part or component or consumables as listed under Schedule | of the EWaste (Management and Handling) Rules, 2011, as amended from time to time, the importer
need to obtain extended producer responsibi|ity-authorisation as producer under the said EWaste (Management and Handling) Rules, 2011.
(4) Prior to clearing of consignment of wastes listed in Part D of Schedule III, the Custom
authorities sha|| verify the documents as given in column (3) of Schedule VIII.
(5) On receipt of the complete application with respect to Part A and Part B of Schedule III, the
Ministry of Environment, Forest and Climate Change shall examine the application considering
the comments and observations, if any, received from the State Pollution Control Boards, and
may grant the permission for import within a period of sixty days subject to the condition that the
importer has (i) the environmentally sound facilities;
(ii) adequate arrangements for treatment and disposal of wastes generated;
(iii)a valid authorisation and consents from the State Pollution Control Board;
(iv) prior informed consent from the exporting country in case of Part A of Schedule III
wastes.
(6) The Ministry of Environment, Forest and Climate Change sha|| fonNard a copy of the
permission to the concerned Port and Customs authorities, Central Pollution Control Board and
the concerned State Pollution Control Board for ensuring compliance with respect to their
respective functions given in Schedule VII.

10

<!-- page 11 -->

(7) The importer of the hazardous and other wastes shall maintain records of the hazardous and
other waste imported by him in Form 3 and the record so maintained shall be made available for
inspection.
(8) The importer of the hazardous and other wastes shall file an annual return in Form 4 to the
State Pollution Control Board on or before the 30th day of June following the financial year to
which that return relates.
(9) Samples of hazardous and other wastes being imported for testing or research and
development purposes up to 1000 gm or 1000 ml shall be exempted from need of taking
permission for import under these rules.
(10) The Port and Customs authorities shall ensure that shipment is accompanied with the
movement document as given in Form 6 and the test report of analysis of the waste,
consignment, wherever applicable, from a laboratory accredited or recognised by the exporting
country. In case of any doubt, the customs may verify the analysis.
14.
Procedure for Export of hazardous and other wastes from India.- (1) Any occupier
intending to export waste specified in Part A of Schedule III, Part B of Schedule III and Schedule
VI, shall make an application in Form 5 along with insurance cover to the Ministry of
Environment, Forest and Climate Change for the proposed transboundary movement of the
hazardous and other wastes together with the prior informed consent in writing from the importing
country in respect of wastes specified in Part A of Schedule III and Schedule VI.
(2) On receipt of an application under sub-rule (1), the Ministry of Environment, Forest and
Climate Change may give permission for the proposed export within a period of sixty days from
the date of submission of complete application and may impose such conditions as it may
consider necessary.
(3) The Ministry of Environment, Forest and Climate Change sha|| fonNard a copy of the
permission granted under sub-rule (2) to the State Pollution Control Board of the State where the
waste is generated and the Pollution Control Board of the State where the port of export is
located and the concerned Port and Customs authorities for ensuring compliance of the
conditions of the export permission.
(4) The exporter shall ensure that no consignment is shipped before the prior informed consent is
received from the importing country, wherever applicable.
(5) The exporter shall also ensure that the shipment is accompanied with movement document in
Form 6.
(6) The exporter of the hazardous and other wastes shall maintain the records of the hazardous
or other waste exported by him in Form 3 and the record so maintained shall be available for
inspection.
15.
Illegal traffic.- (1) The export and import of hazardous or other wastes from and into
India, respectively shall be deemed illegal, if,(i) it is without permission of the Central Government in accordance with these rules; or
(ii) the permission has been obtained through falsification, mis-representation or fraud;
or
(iii) it does not conform to the shipping details provided in the movement documents; or

11

<!-- page 12 -->

(iv) it results in deliberate disposal (i.e., dumping) of hazardous or other waste in
contravention of the Basel Convention and of general principles of international or
domestic law.
(2) In case of illegal import of the hazardous or other waste, the importer sha|| re-export the waste
in question at his cost within a period of ninety days from the date of its arrival into India and its
implementation will be ensured by the concerned Port and the Custom authority. In case of
disposal of such waste by the Port and Custom authorities, they shall do so in accordance with
these rules with the permission of the Pollution Control Board of the State where the Port exists.
(3) In case of illegal import of hazardous or other waste, where the importer is not traceable then
the waste either can be sold by the Customs authority to any user having authorisation under
these rules from the concerned State Pollution Control Board or can be sent to authorised
treatment, storage and disposal facility.

CHAPTER - IV
TREATMENT, STORAGE AND DISPOSAL FACILITY FOR HAZARDOUS AND OTHER
WASTES
16.
Treatment, storage and disposal facility for hazardous and other wastes.- (1) The
State Government, occupier, operator of a facility or any association of occupiers sha||
individually or jointly or severally be responsible for identification of sites for establishing the
facility for treatment, storage and disposal of the hazardous and other waste in the State.
(2) The operator of common facility or occupier of a captive facility, shall design and set up the
treatment, storage and disposal facility as per technical guidelines issued by the Central Pollution
Control Board in this regard from time to time and shall obtain approval from the State Pollution
Control Board for design and layout in this regard.
(3) The State Pollution Control Board shall monitor the setting up and operation of the common or
captive treatment, storage and disposal facility, regularly.
(4) The operator of common facility or occupier of a captive facility shall be responsible for safe
and environmentally sound operation of the facility and its closure and post closure phase, as per
guidelines or standard operating procedures issued by the Central Pollution Control Board from
time to time.
(5) The operator of common facility or occupier of a captive facility shall maintain records of
hazardous and other wastes handled by him in Form 3.
(6) The operator of common facility or occupier of a captive facility shall file an annual return in
Form 4 to the State Pollution Control Board on or before the 30th day of June following the
financial year to which that return relates.

12

<!-- page 13 -->

CHAPTER - V
PACKAGING, LABELLING, AND TRANSPORT OF HAZARDOUS AND OTHER WASTES.
17.
Packaging and Labelling.- (1) Any occupier handling hazardous or other wastes and
operator of the treatment, storage and disposal facility shall ensure that the hazardous and other
wastes are packaged in a manner suitable for safe handling, storage and transport as per the
guidelines issued by the Central Pollution Control Board from time to time. The labelling shall be
done as per Form 8.
(2) The label shall be of non-washable material, weather proof and easily visible.
18.
Transportation of hazardous and other wastes.- (1) The transport of the hazardous
and other waste shall be in accordance with the provisions of these rules and the rules made by
the Central Government under the Motor Vehicles Act, 1988 and the guidelines issued by the
Central Pollution Control Board from time to time in this regard.
(2) The occupier shall provide the transporter with the relevant information in Form 9, regarding
the hazardous nature of the wastes and measures to be taken in case of an emergency and shall
label the hazardous and other wastes containers as per Form 8.
(3) In case of transportation of hazardous and other waste for final disposal to a facility existing in
a State other than the State where the waste is generated, the sender shall obtain ‘No Objection
Certificate’ from the State Pollution Control Board of both the States.
(4) In case of transportation of hazardous and other waste for recycling or utilisation including coprocessing, the sender sha|| intimate both the State Pollution Control Boards before handing over
the waste to the transporter.
(5) In case of transit of hazardous and other waste for recycling, utilisation including coprocessing or disposal through a State other than the States of origin and destination, the sender
shall give prior intimation to the concerned State Pollution Control Board of the States of transit
before handing over the wastes to the transporter.
(6) In case of transportation of hazardous and other waste, the responsibility of safe transport
shall be either of the sender or the receiver whosoever arranges the transport and has the
necessary authorisation for transport from the concerned State Pollution Control Board. This
responsibility should be clearly indicated in the manifest.
(7) The authorisation for transport shall be obtained either by the sender or the receiver on whose
behalf the transport is being arranged.
19.
Manifest system (Movement Document) for hazardous and other waste to be used
within the country only.- (1) The sender of the waste shall prepare seven copies of the manifest
in Form 10 comprising of colour code indicated below and all seven copies shall be signed by the
sender:

13

<!-- page 14 -->

Copy number with
colour code

(1)

Copy1 (White)
Copy 2 (Yellow)
Copy 3 (Pink)
Copy 4 (Orange)
Copy 5 (Green)
Copy 6 (Blue)
Copy 7 (Grey)

Purpose

(2)

To be forwarded by the sender to the State Pollution Control
Board after signing all the seven copies.
To be retained by the sender after taking signature on it from the
transporter and the rest of the five signed copies to be carried by
the transporter.
To be retained by the receiver (actual user or treatment storage
and disposal facility operator) after receiving the waste and the
remaining four copies are to be duly signed by the receiver.
To be handed over to the transporter by the receiver after
accepting waste.
To be sent by the receiver to the State Pollution Control Board.
To be sent by the receiver to the sender.
To be sent by the receiver to the State Pollution Control Board
of the sender in case the sender is in another State.

(2) The sender sha|| fonNard copy 1 (white) to the State Pollution Control Board, and in case the
hazardous or other wastes is likely to be transported through any transit State, the sender sha||
intimate State Pollution Control Boards of transit States about the movement of the waste.
(3) No transporter shall accept waste from the sender for transport unless it is accompanied by
signed copies 3 to 7 of the manifest.
(4) The transporter shall submit copies 3 to 7 of the manifest duly signed with date to the receiver
along with the waste consignment.
(5) The receiver after acceptance of the waste sha|| hand over copy 4 (orange) to the transporter
and send copy 5 (green) to his State Pollution Control Board and send copy 6 (blue) to the
sender and the copy 3 (pink) shall be retained by the reciever.
(6) The copy 7 (grey) shall only be sent to the State Pollution Control Board of the sender, if the
sender is in another State.

CHAPTER VI
MISCELLANIOUS
20.
Records and returns.- (1) The occupier handling hazardous or other wastes and
operator of disposal facility shall maintain records of such operations in Form 3.
(2) The occupier handling hazardous and other wastes and operator of disposal facility shall send
annual returns to the State Pollution Control Board in Form 4.
(3) The State Pollution Control Board based on the annual returns received from the occupiers
and the operators of the facilities for disposal of hazardous and other wastes shall prepare an
annual inventory of the waste generated; waste recycled, recovered, utilised including coprocessed; waste re-exported and waste disposed and submit to the Central Pollution Control
Board by the 30th day of September every year. The State Pollution Control Board shall also
prepare the inventory of hazardous waste generators, actual users, and common and captive

14

<!-- page 15 -->

disposal facilities and shall submit the information to Central Pollution Control Board every two
years.
(4) The Central Pollution Control Board shall prepare the consolidated review report on
management of hazardous and other wastes and fonNard it to the Ministry of Environment, Forest
and Climate Change, along with its recommendations before the 30th day of December once in
every year.
21.
Responsibility of authorities. - The authority specified in column (2) of Schedule VII shall
perform the duties as specified in column (3) of the said Schedule subject to the provisions of
these rules.
22.
Accident reporting. - Where an accident occurs at the facility of the occupier handling
hazardous or other wastes and operator of the disposal facility or during transportation, the
occupier or the operator or the transporter shall immediately intimate the State Pollution Control
Board through telephone, e-mail about the accident and subsequently send a report in Form 11.
23.

Liability of occupier, importer or exporter and operator of a disposal facility.-

(1) The occupier, importer or exporter and operator of the disposal facility shall be liable for all
damages caused to the environment or third party due to improper handling and management of
the hazardous and other waste.
(2) The occupier and the operator of the disposal facility shall be liable to pay financial penalties
as levied for any violation of the provisions under these rules by the State Pollution Control Board
with the prior approval of the Central Pollution Control Board.
24.
Appeal.- (1) Any person aggrieved by an order of suspension or cancellation or refusal of
authorisation or its renewal passed by the State Pollution Control Board may, within a period of
thirty days from the date on which the order is communicated to him, prefer an appeal in Form 12
to the Appellate Authority, namely, the Environment Secretary of the State.
(2) The Appellate Authority may entertain the appeal after expiry of the said period of thirty days,
if it is satisfied that the appellant was prevented by sufficient cause from filing the appeal in time.
(3) Every appeal filed under this rule shall be disposed of within a period of sixty days from the
date of its filing.
SCHEDULE |
[See rule 3(1) (17) (i)]
List of processes generating hazardous wastes
S.No.

(1)
1.

Processes

(2)

Petrochemical
processes
pyrolytic operations

Hazardous Waste*

(3)

and 1.1 Furnace or reactor residue and debris
1.2 Tarry residues and still bottoms
distillation
1.3 Oily sludge emulsion
1.4 Organic residues
1.5 Residues from alkali wash of fuels

15

from

<!-- page 16 -->

(1)
2.

3.

4.

5.

6.

7.

8.
9.
10.

11.

(2)

(3)

1.6 Spent catalyst and molecular sieves
1.7 Oil from wastewater treatment
Crude
oil
and
natural
gas 2.1 Dri|| cuttings excluding those from water
production
based mud
2.2 Sludge containing 0“
2.3 Drilling mud containing 0“
Cleaning,
emptying
and 3.1 cargo residue, washing water and sludge
maintenance of petroleum 0“
containing 0“
storage tanks including ships
3.2 cargo
residue
and
sludge
containing
chemicals
3.3 Sludge and filters contaminated with oil
3.4 Ba||ast water containing 0“ from ships
Petroleum
refining
or
re- 4.1 Oil sludge or emulsion
processing of used oil or recycling 4.2 Spent catalyst
of waste oil
4.3 Slop Oil
4.4 Organic residue from processes
4.5 Spent c|ay containing 0“
Industrial operations using mineral 5.1 Used or spent 0“
or synthetic oil as lubricant in 5.2 Wastes or residues containing 0“
hydraulic
systems
or
other 5.3 Waste cutting oi|s
applications
Secondary production and / or 6.1 Sludge and filter press cake arising out of
industrial use of zinc
production of Zinc Sulphate and other Zinc
Compounds.
6.2 Zinc fines or dust or ash or skimmings in
dispersible form
6.3 Other residues from processing of zinc ash or
skimmings
6.4 Flue gas dust and other particulates
Primary production of zinc or lead 7.1 Flue gas dust from roasting
or copper and other non-ferrous 7.2 Process residues
metals except aluminium
7.3 Arsenic-bearing sludge
7.4 Non-ferrous metal bearing sludge and
residue.
7.5 Sludge from scrubbers
Secondary production of copper
8.1 Spent electrolytic solutions
8.2 Sludge and filter cakes
8.3 Flue gas dust and other particulates
Secondary production of lead
9.1 Lead bearing residues
9.2 Lead ash or particulate from flue gas
9.3 Acid from used batteries
Production and/or industrial use of 10.1 Residues containing cadmium and arsenic
cadmium and arsenic and their
compounds
Production
of
primary
and 11.1 Sludges from off-gas treatment
secondary aluminum
11.2 Cathode residues including pot lining
wastes
11.3 Tar containing wastes
11.4 Flue gas dust and other particulates
11.5 Drosses and waste from treatment of
salt sludge

16

<!-- page 17 -->

(1)
12.

13.

14.

15.

16.

17.
18.

19.
20.

21.
22.
23.

(2)

(3)

11.6 Used anode butts
11.7 Vanadium sludge from alumina
refineries
Metal surface treatment, such as 12.1 Acidic and alkaline residues
etching,
staining,
polishing, 12.2 Spent acid and alkali
galvanizing, cleaning, degreasing, 12.3 Spent bath and sludge containing sulphide,
plating, etc.
cyanide and toxic metals
12.4 Sludge from bath containing organic
solvents
12.5 Phosphate sludge
12.6 Sludge from staining bath
12.7 Copper etching residues
12.8 Plating metal sludge
Production of iron and steel 13.1 Spent pickling liquor
including other ferrous a||oys 13.2 Sludge from acid recovery unit
(electric furnace; steel rolling and 13.3 Benzol acid sludge
finishing mills; Coke oven and by 13.4 Decantertanktar sludge
products plant)
13.5 Tar storage tank residue
13.6 Residues from coke oven by product plant.
Hardening of steel
14.1 Cyanide-, nitrate-, or nitrite -containing
sludge
14.2 Spent hardening salt
Production
of
asbestos
or 15.1 Asbestos-containing residues
asbestos-containing materials
15.2 Discarded asbestos
15.3 Dust or particulates from exhaust gas
treatment.
Production of caustic soda and 16.1 Mercury bearing sludge generated from
chlorine
mercury ce|| process
16.2 Residue or sludges and filter cakes
16.3 Brine sludge
Production of mineral acids
17.1 Process acidic residue, filter cake, dust
17.2 Spentcatalyst
Production of nitrogenous and 18.1 Spentcatalyst
complex fertilizers
18.2 Carbon residue
18.3 Sludge or residue containing arsenic
18.4 Chromium sludge from water cooling tower
Production of phenol
19.1 Residue or sludge containing phenol
19.2 Spentcatalyst
Production and/orindustrial use of 20.1 Contaminated
aromatic,
aliphatic
or
solvents
napthenic solvents may or may not be fit for
reuse.
20.2 Spentsolvents
20.3 Distillation residues
20.4 Process Sludge
Production and/or industrial use of 21.1 Process wastes, residues and sludges
paints,
pigments,
lacquers, 21.2 Spent solvent
varnishes and inks
Production of plastics
22.1 Spentcatalysts
22.2 Process residues
Production and /or industrial use 23.1 Wastes or residues (not made with
of
glues,
organic
cements,
vegetable or animal materials)

17

<!-- page 18 -->

(1)
24.
25.
26.

27.
28.

29.

30.
31.
32.

33.

34.

35.

36.

(2)

adhesive and resins

23.2 Spent solvents

(3)

Production of canvas and textiles 24.1 Chemical residues
Industrial
production
and 25.1 Chemical residues
formulation of wood preservatives 25.2 Residues from wood alkali bath
Production or industrial use of 26.1 Process waste sludge/residues containing
synthetic dyes, dye-intermediates
acid, toxic metals, organic compounds
and pigments
26.2 Dust from air filtration system
26.3 Spentacid
26.4 Spentsolvent
26.5 Spentcatalyst
Production
of
organic—silicone 27.1 Process residues
compound
Production/formulation
of 28.1 Process Residue and wastes
drugs/pharmaceutical and health 28.2 Spentcatalyst
care product
28.3 Spent carbon
28.4 Off specification products
28.5 Date-expired products
28.6 Spent solvents
Production, and formulation of 29.1 Process wastes or residues
pesticides including stock-piles
29.2 Sludge containing residual pesticides
29.3 Date-expired
and
off-specification
pesticides
29.4 Spentsolvents
29.5 Spentcatalysts
29.6 Spentacids
Leather tanneries
30.1 Chromium bearing residue and sludge
Electronic Industry
31.1 Process residue and wastes
31.2 Spent etching chemicals and solvents
Pulp and Paper Industry
32.1 Spentchemicals
32.2 Corrosive wastes arising from use of strong
acid and bases
32.3 Process sludge containing adsorbable
organic ha|ides(AOX)
Handling of hazardous chemicals 33.1 Empty
barrels/containers/Iiners
and wastes
contaminated with hazardous chemicals
/wastes
33.2 Contaminated cotton rags or other cleaning
materials
De-contamination of barrels /34.1 ChemicaI-containing residue arising from
containers used for handling of
decontamination.
hazardous wastes/chemicals
34.2 Sludge from treatment of waste water
arising out of cleaning / disposal of barrels/
containers
Purification and treatment of 35.1 ExhaustAir or Gas cleaning residue
exhaust air/gases, water and 35.2 Spent ion exchange resin containing toxic
waste water from the processes in
metals
this
schedule
and
common 35.3 Chemical
sludge
from
waste
water
industrial effluent treatment plants
treatment
(CETP’s)
35.4 Oil and grease skimming
35.5 Chromium sludge from cooling water
Purification process for organic 36.1 Any process or distillation residue

18

<!-- page 19 -->

(1)
37.

38.

(2)

(3)

compounds/solvents
36.2 Spent carbon or filter medium
Hazardous
waste
treatment 37.1 Sludge from wetscrubbers
processes, e.g. pre-processing, 37.2 Ash from incinerator and flue gas cleaning
incineration and concentration
residue
37.3 Concentration or evaporation residues
Chemical processing of Ores 38.1 Process residues
containing heavy metals such as 38.2 Spentacid
Chromium, Manganese, Nickel,
Cadmium etc.

* The inclusion of wastes contained in this Schedule does not preclude the use of
Schedule II to demonstrate that the waste is not hazardous. In case of dispute, the
matter would be referred to the Technical Review Committee constituted by Ministry of
Environment, Forest and Climate Change.
Note: The high volume low effect wastes such as ﬂy ash, Phosphogypsum, red mud, jarosiz‘e,
Slags from pyromez‘a/Iurgical operations, mine failings and ore beneﬁciaz‘ion rejects are excluded
from the category of hazardous wastes. Separate guidelines on the management of these wastes
shall be issued by Central Pollution Control Board.

19

<!-- page 20 -->

SCHEDULE ||

[See rule 3(1) (17) (ii)]
List of waste constituents with concentration limits

Class A: Based on leachable concentration limits [Toxicity Characteristic Leaching
Procedure (TCLP) or Soluble Threshold Limit Concentration (STLC)]
Class

(1)

A1
A2
A3
A4
A5
A6
A7
A8
A9
A10
A11
A12
A13
A14
A15
A16
A17
A18
A19
A20
A21
A22
A23
A24
A25
A26
A27
A28
A29
A30
A31
A32
A33
A34
A35
A36
A37
A38

Constituents

Concentration in
mgll

(2)

Arsenic
Barium
Cadmium
Chromium and/or Chromium
compounds
Lead
Manganese
Mercury
Selenium
Silver
Ammonia
Cyanide
Nitrate (as nitrate-nitrogen)
Sulphide (as H28)
1,1-Dichloroethylene
1,2-Dichloroethane
1,4-Dichlorobenzene
2,4,5-Trichlorophenol
2,4,6-Trichlorophenol
2,4-Dinitrotoluene
Benzene
Benzo (a) Pyrene
Bromodicholromethane
Bromoform
Carbon tetrachloride
Chlorobenzene
Chloroform
Cresol (ortho+ meta+ para)
Dibromochloromethane
Hexachlorobenzene
Hexachlorobutadiene
Hexachloroethane
Methyl ethyl ketone
Naphthalene
Nitrobenzene
Pentachlorophenol
Pyridine
Tetrachloroethylene
Trichloroethylene

20

(3)

(Ill)

5.0
100.0
1.0
50
'
5.0
10.0
0.2
1.0
5.0
50*
20*
1000.0
5.0
0.7
0.5
7.5
400.0
2.0
0.13
0.5
0.001
6.0
10.0
0.5
100.0
6.0
200.0
10.0
0.13
0.5
3.0
200.0
5.0
2.0
100.0
5.0
0.7
0.5
