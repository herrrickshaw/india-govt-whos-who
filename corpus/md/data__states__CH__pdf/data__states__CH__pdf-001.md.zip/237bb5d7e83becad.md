---
doc_id: "237bb5d7e83becad"
source_url: "https://www.library.puchd.ac.in/includes/tenders/2015/20151014090714-supplyofltctmeter2005ampforadmin.pdf"
ministry: "A. C. Joshi Library, Panjab University, Chandigarh"
title: "Supply of LT CT Meter 200/5 Amp with accuracy 0.5, complete with set of CTs 200/5"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "48668c2d197c4ac9"
---

<!-- page 1 -->

P.U. CONSTRUCTION OFFICE, CHANDIGARH
(Electrical-Wing)

From

To

The Sub Divisional Engineer (Elect.),
University Construction Office,
Chandigarh-160014
No. Works/………………….

Dated…………………

Dear Sir,
Please quote your lowest market rate for the supply of the following in a sealed cover marked
on the envelope “QUOTATION DUE ON 21.10.2015 at 3.30 p.m.,” along with your other terms and
conditions of supply, if any.
Subject: - Supply of LT CT Meter 200/5 Amp for Administrative Office in Panjab University
Campus, Sector – 14, Chandigarh.
Ch. To: - A.R. & M.I. of Electrical.
Sr.
Description of Material
No.
Supply of LT CT Meter 200/5 Amp with accuracy 0.5, complete with set of
1 CT’s 200/5, complete in all respect with Test Report of meter. Make: Secure,
L&T.

Quantity

1 Nos.

Conditions:
1.
2.
3.
4.

9.

Delivery of material immediate at site.
The firm should mention the rate of VAT if applicable.
Condition of payment in cash shall not be accepted
In case the cost of material involved is more than Rs. 16,000 the validity of rates must be
given for at least one month, otherwise it should be 15 days.
The supply is also commenced/ made within 7 days of the receipt of supply order.
No payment will be made on the Performa invoice. The payment will be made after two
weeks through Registrar’s Office.
The quotations will be received in the office of Er. Kulwant Singh S.D.E. (Elect.) through
Registered/Speed Post.
Panjab University does not take any responsibility for any postal delay in delivery by Post or
lost in transit of the quotation form. No quotation will be entertained by hand.
Name of Work, reference nos. and due date should be mentioned on the Envelope.

10.

The undersigned has right to reject any or all the quotations, without assigning any reasons.

5.
6.
7.
8.

S.D.E. (Electrical),
P.U., Chandigarh.
