---
doc_id: "a80b80fcdf6c5ad6"
source_url: "https://maths.puchd.ac.in/includes/noticeboard/2018/20180720104646-newmicrosoftofficeworddocument.pdf?2026"
ministry: "Mathematics Department, Panjab University, Chandigarh"
title: "CORRIGENDUM/EXTENDION OF LAST DATE FOR SUBMITTING QUOTATIONS"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "644c88ae152f2d80"
---

<!-- page 1 -->

DEPARTMENT OF MATHEMATICS
PANJAB UNIVERSITY, CHANDIGARH 160014(INDIA)
(Estted. under the Panjab University Act VII of 1947Enacted by the Govt. of India)

MAT/18/______
Dated:________

CORRIGENDUM/EXTENDION OF LAST DATE FOR SUBMITTING
QUOTATIONS

In reference to previous letter No. MAT/18/____ and MAT/18/____ dated 09.07.2018, it is
notified that the last date for submission of quotations have been extended upto 24.07.2018 till
5.00 P.M.
For detailed information please visit Panjab University website http://maths.puchd.ac.in/shownoticeboard.php?201815072342&nbid=3&id=14025.

Sd/(Gurmeet Bakshi)
Chairperson
