---
doc_id: "01d6ab0aab45df9f"
source_url: "https://moef.gov.in/uploads/2021/08/2-DTEPA-Notification.pdf"
ministry: "Environment Department, Chandigarh"
title: "Notifications under the Environment (Protection) Act, 1986"
date: ""
pages: 32
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2be0481dfcf0671d"
---

<!-- page 1 -->

Notifications under the Environment (Protection) Act, 1986

297

DAHANU TALUKA ENVIRONMENT (PROTECTION) AUTHORITY
MINISTRY OF ENVIRONMENT & FORESTS
NOTIFICATION
New Delhi, the 19th December, 1996
S.O.884(E).- In exercise of the powers conferred by sub-section (3) of Section 3 of the
Environment (Protection) Act, 1986 (29 of 1986) (hereinafter referred to as the said Act),
the Central Government hereby constitutes an authority known as the Dahanu Taluka
Environment Protection Authority, in the District of Thane, State of Maharashtra,
consisting of the following members for a period of one year on and from the date of
publication of this notification in the Official Gazette, namely : (1)

Justice Chandrashekhar Shankar Dharmadhikari
(Retired Judge of High Court, Mumbai)

- Chairperson

(2)

Director, National Institute of Hydrology, University Campus
Roorkee, (U.P.)
( Expert in the field of Hydrology)

- Member

(3)

Director, National Institute of Oceanography, Dona Paula, Goa
(Expert in the field of Oceanography and Aquatic Ecology )

- Member

(4)

Head of the Botany Department, Mumbai University, Mumbai
(Expert in the field of Terrestrial Ecology)

-Member

(5)

Head, Department of Environmental Engineering, IIT, Mumbai - Member
(Expert in the field of Environmental Engineering )

(6)

Prof. K.B.Jain, Center for Environmental Planning & Technology, - Member
Ahmedabad (Expert in the field of the Developmental and
Environmental Planning )

(7)

Director, National Institute of Design, Ahmedabad
(Expert in the field of Information Technology)

- Member

(8)

Collector, Thane

- Member

(9)

The Member Secretary, Maharasthra State Pollution Control
Board, Mumbai

- Member

(10)

A representative of Non-Governmental Organization
(To be appointed by the Central Government)

- Member

(11)

Shri V.W.Deshpande, Deputy Secretary, Urban Development
Department, Govt. of Maharashtra, Mumbai

- Member
Secretary

<!-- page 2 -->

298

Notifications under the Environment (Protection) Act, 1986

2.
The Authority shall exercise the following powers and perform the following
functions namely : exercise of powers under section 5 of the Environment (Protection) Act, 1986 for issuing
directions and for taking measures with respect to matters referred to in clauses (v), (vi),
(vii), (viii), (ix) and (xii) of sub-section (2) of section 3 of the said Act;
to protect the ecologically fragile areas of Dahanu Taluka and to control pollution
in the said area ;
to consider and implement the “Pre-cautionary Principle “ and the “Polluter Pays
Principle”;
to consider and implement the recommendations given by the National
Environmental Engineering Research Institute, Nagpur, in respect of Dahanu Taluka;
to ensure the implementation of the notifications issued by the Government of
India in the Ministry of Environment & Forests No. S.O.114 (E), dated 19th February,
1991 and No.S.O.416(E), dated the 20th June, 1991;
to comply with the relevant orders issued by the Bombay High Court and the
Supreme Court from time to time;
to deal with any other relevant environment issues pertaining to DahanuTaluka,
including those which may be referred to it by the Central Government in the Ministry of
Environment & Forests.
3. The Authority shall furnish a progress report about its activities at least once in
two months to the Central Government in the Ministry of Environment & Forests.
4. The Authority shall have its Headquarters at Mumbai, Maharashtra.
5. The terms and conditions of appointment of the Chairperson and Members
shall be as determined by the Central Government from time to time.

[F.No.J-17011/21/95-IA-III]
R.H.KHAWAJA, Jt. Srecretary

<!-- page 3 -->

Notifications under the Environment (Protection) Act, 1986

299

CENTRAL GROUND WATER BOARD AUTHORITY
MINISTRY OF ENVIRONMENT & FORESTS
NOTIFICATION
New Delhi, the 14th January, 1997
S.O.38(E).- In exercise of the powers conferred by sub-section (3) of section 3 of the
Environment (Protection) Act, 1986 (29 of 1986) (hereinafter referred to as the said Act),
the Central Government hereby constitute the Central Ground Water Board as an
Authority for the purposes of regulation and control of Ground Water Management and
Development for period of one year from the date of publication of this notification in the
official gazette, namely: (1)

Chairman, Central Ground Water Board

- Chairperson

(2)

Member (Exploratory Drilling and Materials Management),
Central Ground Water Board

- Member

Member (Sustainable Management and Liaison),
Central Ground Water Board

- Member

(3)
(4)
(5)

Member (Survey, Assessment and Monitoring), Central
Ground Water Board
………………………………………………………..
(An officer not below the rank of the Joint Secretary
to the Government of India to be appointed by the
Central Government)

- Member

- Member

2. The Authority shall exercise the following powers and perform the following
functions, namely : (i)

exercise of powers under section 5 of the Environment (Protection) Act,
1986 for issuing directions and taking such measures in respect of all the
matters referred to in sub-section (2) of section 3 of the said Act;

(ii)

to resort to the penal provisions contained in sections 15 to 21 of the said
Act;

(iii)

to regulate indiscriminate boring and withdrawal of ground water in the
country and to issue the necessary regulatory directions with a view to
preserve and protect the ground water.

3. The jurisdiction of the Authority shall be whole of India.
4. The Authority shall function under the administrative control of the Government of
India in the Ministry of Water Resources with its Headquarters at Delhi.
[F.No.L-11011/29/96-IA.III]
R.H.KHWAJA, Jt. Secretary

<!-- page 4 -->

300

Notifications under the Environment (Protection) Act, 1986

AQUACULTURE AUTHORITY
MINISTRY OF ENVIRONMENT & FORESTS
NOTIFICATION
New Delhi, the 6th February, 1997
S.O. 88(E). - In exercise of the powers conferred by sub-section (3) of Section 3 of the
Environment (Protection) Act, 1986 (29 of 1986) (hereinafter referred to as the said Act),
the Central Government hereby constitute an authority known as Aquaculture Authority
to deal with the situation created by the shrimp culture industry in the coastal States and
Union Territories consisting of the following members for a period of one year from the
date of publication of this notification in the Official Gazette, namely : (1)

………………………….………………………………
( A retired Judge of High Court to be appointed by the
Central Government )

Chairperson

(2)

……………………………….……………………………
(An expert in the field of aquaculture, to be appointed
by the Central Government)

Member

(3)

……………………………….……………………………
(An expert in the field of pollution control, to be appointed
by the Central Government)

Member

(4)

……………………………….…………………………… Member
(An expert in the field of environment protection, to be appointed
by the Central Government )

(5)

……………………………….…………………………… Member
( A representative of the Ministry of Environment & Forests,
to be appointed by the Central Government)

(6)

……………………………….…………………………… Member
( A representative of the Ministry of Agriculture, to be appointed
by the Central Government)

(7)

……………………………….…………………………… Member
( A representative of the Ministry of Commerce, to be
appointed by the Central Government )

(8)

………………………….………………………………
(To be appointed by the Central Government)

Member Secretary

<!-- page 5 -->

Notifications under the Environment (Protection) Act, 1986

301

2. The Authority shall exercise the following powers and perform the following
functions, namely : (i)

exercise of powers under section 5 of the Environment (Protection) Act,
1986 for issuing directions and for taking measures with respect to
matters referred to in clause (v), (vi), (vii), (viii), (ix) and (xii) of subsection (2) of section 3 of the said Act;

(ii)

to take steps and ensure the closure, demolition and removal of all the
existing aquaculture activities by the 31st March, 1997 from the Coastal
Regulation Zone areas as demarcated in the Coastal Zone Management
Plans prepared in accordance with the Coastal Regulation Zone
Notification No. S.O.114(E) dated the 19th February, 1991 by the
concerned coastal States and Union Territories and upto 1000 m in
respect of Chilka lake and Pulicat lake, except the traditional and
improved traditional types of technologies (as defined in Algarswami
report) which area practiced in the coastal low lying areas;

(iii)

to ensure that no shrimp culture pond can be constructed or setup within
the Coastal Regulation Zone and upto 1000 m of Chilka lake and Pulicat
lake (including bird sanctuaries namely, Yadurpattu and Nelpattu) ;

(iv)

to ensure and give approval to the farmers who are operating traditional
and improved traditional systems of aquaculture for adoption of
improved technology for increased production;

(v)

to ensure that the agricultural lands, salt pan lands, mangroves, wetlands,
forest lands, land for village common purposes and the land meant for
public purposes shall not be used or converted for construction of shrimp
culture ponds;

(vi)

the Authority shall implement the “Precautionary Principle” and the
“Polluter Pays Principle”, by adopting the procedure described in the
Supreme Court order dated 11-12-1996 passed in the Writ Petition
(Civil) No. 561 of 1994 ;

(vii)

the Authority shall also regulate the shrimp culture activities outside the
Coastal Regulation Zone areas and beyond 1000m from the Pulicat lake
and Chilka lake and also give the necessary approvals/authorisations by
the 30th April, 1997;

(viii)

the Authority in consultation with expert bodies like National
Environmental Engineering Research Institute, Central Pollution Control
Board, respective State Pollution Control Boards shall frame
Scheme/Schemes for reversing the damage caused to the ecology and
environment by pollution in the coastal States and Union Territories;

<!-- page 6 -->

Notifications under the Environment (Protection) Act, 1986

302

(ix)

the Authority shall ensure the payment of compensation to the workmen
employed in the shrimp culture industries as per the procedure laid down
in the Supreme Court order dated 11-12-1996 passed in the Writ Petition
(Civil) No. 561 of 1994;

(x)

to comply with the relevant orders issued by the concerned High Courts
and Supreme Court from time to time;

(xi)

to deal with any other relevant environment issues pertaining to coastal
areas with respect to shrimp culture farming, including those which may
be referred to it by the Central Government in the Ministry of
Environment & Forests;

3.
The jurisdiction of the Authority shall cover all the coastal States and Union
Territories.
4. The Scheme/Schemes framed by the Authority for reversing the damage caused due to
the pollution in the coastal States and Union Territories shall be executed by the
respective State Government and Union Territory Administrations under the supervision
of the Central Government.
5. The Authority shall function under the administrative control of Government of India
in the Ministry of Agriculture, with its headquarters at Delhi.
6. The terms and conditions of appointment of the Chairperson and Members shall be as
determined by the Central Government from time to time.
[F.NO.L-11011/12/94-IA-III]
R.H.KHAWAJA, Jt. SECRETARY

<!-- page 7 -->

Notifications under the Environment (Protection) Act, 1986

303

THE 2 - T OIL (REGULATION OF SUPPLY AND DISTRIBUTION)
ORDER, 1998.
MINISTRY OF ENVIRONMENT AND FORESTS
ORDER
New Delhi, the 31st December, 1998
G.S.R.778(E). - Whereas with a view to protecting and improving the quality of the
environmental and preventing, controlling and abating environment pollution in the
National Capital Territory of Delhi, it is expedient and necessary to take measures
relating to the supply, distribution, buying and selling of 2-T oil (lubricating oil);
Now, therefore, in exercise of the powers conferred by sub-sections (1) and (2) of Section
3 of the Environment (Protection) Act, 1986 (29 of 1986), the Central Government
hereby makes the following Order namely :1. SHORT TITLE, EXTENT AND COMMENCEMENT :(1) This Order may be called the 2-T Oil (Regulation of Supply and Distribution)
Order, 1998.
(2) It extends to the whole of the National Capital Territory of Delhi.
(3) It shall come into force on the date of its publication in the Official Gazette.
2. DEFINITIONS :In this Order, unless the context otherwise requires(a) "2-T Oil" means lubricating oil, meeting API-TC (American Petroleum
Institute-TC) or JASO (Japanese Automobile Standards Organisation) specification,
used in 2-stroke petrol driven vehicle engines;
(b) "container" means a sealed package containing pre-packed 2-T oil in declared
quantity;
(c) "loose 2-T oil" means 2-T oil which is not contained in a sealed container;
(d) "National Capital Territory of Delhi" means the National Capital Territory of
Delhi as defined in the Government of National Capital Territory of Delhi Act, 1991
(1 of 1992).

<!-- page 8 -->

304

Notifications under the Environment (Protection) Act, 1986

3. RESTRICTION ON SALE AND PURCHASE OF LOOSE 2-T OIL :(1) No person shall sell or agree to sell or otherwise dispose of loose 2-T oil in a
service garage for use in 2-stroke engine vehicle of any make;
(2) In petrol stations, 2-T oil shall be sold only pre-mixed with petrol through
nozzle:
Provided that the above restriction shall not apply to the 2-stroke engine vehicles
having separate sump for 2-T oil provided by the manufacturer in containers for use in
the engine of such vehicle through such sumps.

[File No. Q-16014/18/98-CPA]
VIJAI SHARMA, Jt. Secy.

<!-- page 9 -->

Notifications under the Environment (Protection) Act, 1986

305

WATER QUALITY ASSESSMENT AUTHORITY
MINISTRY OF ENVIRONMENT & FORESTS
ORDER
New Delhi, the 29th May, 2001
S.O.583(E) – In exercise of powers conferred by sub-section (1) and (3) of section 3 of
the Environment (Protection) Act, 1986 (29 of 1986) (hereinafter referred to as the said
Act), the Central Government hereby constitutes an authority to be known as ‘Water
Quality Assessment Authority’s consisting of the following members for a period of three
years with effect from the date of publication of this notification in the Official Gazette
namely:
1

1.

Secretary, Ministry of Environment & Forests

- Chairperson

2.

Additional Secretary and Project Director, National
River Conservation Directorate, Ministry of
Environment & Forests

- Member

3.

Chairman, Central Water Commission

- Member

4.

Additional Secretary, Ministry of Water Resources

- Member

5.

Adviser, National River Conservation Directorate,
Ministry of Environment and Forests

- Member

6.

Joint Secretary,
Cooperation

and

- Member

7.

Joint Secretary, Ministry of Urban Affairs and
Poverty Alleviation

- Member

8.

Chairman, Central Ground Water Authority

- Member

9.

Chairman, Central Pollution Control Board

- Member

10.

Directorate, Indian Agricultural Research Institute,
New Delhi

- Member

11.

Director, National Environmental
Research Institute, Nagpur

- Member

12.

Commissioner (Water Management) Ministry of
Water Resources

1

Ministry

of

Agriculture

Engineering

- Member Secretary

As published in the Gazette of India, Extraordinary, Part II section 3(ii) vide No.418, dated 22.6.2001.

<!-- page 10 -->

Notifications under the Environment (Protection) Act, 1986

306

2. The Authority shall exercise the following powers and functions:I.

to exercise powers under section 5 of the said Act for issuing directions and for
taking measures with respect to matters referred to in clauses (ix), (xi), (xii) and
(xiii) of sub-section 2 of section 3 of the Act;

II.

to direct the agencies (Government/local bodies/non-Governmental) for the
following
(a)

to standardize method(s) for water quality monitoring and to ensure
quality of data generation for utilization thereof;

(b)

to take measures so as to ensure proper treatment of wastewater with a
view to restoring the water quality of the river/water bodies to meet the
designated-best-uses;

(c)

to take up research and development activities in the area of water
quality management;

(d)

to promote recycling/re-use of treated sewage/trade effluent for
irrigation in development of agriculture;

(e)

to draw action plans for quality improvement in water bodies, and
monitor and review/assess implementation of the schemes launched/to
be launched to that effect;

(f)

to draw scheme(s) for imposition of restriction in water abstraction and
discharge of treated sewage/trade effluent on land, rivers and other
water bodies with a view to mitigating crises of water quality;

(g)

to maintain minimum discharge for sustenance of aquatic life forms in
riverine system;

(h)

to promote rain water harvesting;

(i)

to utilize self-assimilation capacities at the critical river stretches to
minimize cost of effluent treatment;

(j)

to provide information to pollution control authorities to facilitate
allocation of waste load;

(k)

to review of status of quality of national water resources (both surface
water & groundwater) and identify ‘Hot Spots’ for taking necessary
actions for improvement in water quality;

<!-- page 11 -->

Notifications under the Environment (Protection) Act, 1986

307

(l)

to interact with the authorities/committees constituted or to be
constituted under the provisions of said Act for matters relating to
management of water resources;

(m)

to constitute/set-up State level Water Quality Review Committees
(WQRC) to coordinate the work to the assigned to such committees;
and

(n)

to deal with any environmental issue concerning surface and
groundwater quality which may be referred to it by the Central
Government or the State Government relating to the respective areas,
for maintenance and/or restoration of quality to sustain designatedbest-uses.

3.

The Authority shall exercise the powers under section 19 of the said Act.

4.

The authority may appoint domain experts for facilitating the work assigned to it.

5.

The Ministry of Water Resources shall create a cell to assist the Authority to
carry out the assigned functions.

6.

The authority shall furnish report about its activity at least once in three months
to the Ministry of Environment & Forests.

(F.No.J-15011/8/2000-NRCD)
A.M.GOKHALE, Addl. Secy.

<!-- page 12 -->

Notifications under the Environment (Protection) Act, 1986

308

ENVIRONMENT POLLUTION (PREVENTION AND CONTROL)
AUTHORITY FOR NATIONAL CAPITAL REGION
MINISTRY OF ENVIRONMENT AND FORESTS
ORDER
New Delhi, the 29th January, 1998
S.O. 93 (E).– In exercise of the powers conferred by sub-sections (1) and (3) of section 3
of the Environment (Protection) Act, 1986 (29 of 1986) (hereinafter referred to as the
said Act), the Central Government hereby constitutes an authority to be known as the
Environment Pollution (Prevention and Control) Authority for the National Capital
Region (hereinafter referred to as the Authority) consisting of the following persons 1[for
a period of eight years] with effect from the date of publication of this Order in the
Official Gazette, namely:(1)

2

[Shri Bhure Lal
Secretary, Coordination and Public Grievances
Sardar Patel Bhawan
New Delhi – 110001

Chairman

(2)

3

[Commissioner-cum-Secretary
Transport Department,
Government of the National
Capital Territory of Delhi,
Delhi.]

Member

(3)

Shri Anil Agarwal,
Director,
Centre for Science and Environment,
41, Tughlakabad Industrial Area,
(Near Batra Hospital),
New Delhi - 110 062

Member

(4)

Shri Jagdish Khattar,
Representative of the Automobile
Manufacturers Association of India,
Executive Director (Marketing & Sales),
Maruti Udyog Limited,
11th Floor, Jeevan Prakash
25, Kasturba Gandhi Marg,
New Delhi - 110 001

Member

1
2
3

Substituted vide S.O.99(E), dated 28.1.2003.
Substituted, ibid.
Substituted, ibid.

<!-- page 13 -->

Notifications under the Environment (Protection) Act, 1986

1

[(5)

Shri N.R.Raje
Executive Dierctir, R&D Sector
Indian Oil Corporation, Sector – 13
Faridabad – 121007, Haryana

Member

(6)

Dr.P.C.Chaubey
Additional Professor
Hospital Administration
All India Institute of Medical Science
Ansari Nagar, New Delhi – 110029

Member

2

[6A

Smt. Kiran Dhingra
Joint Secretary
Ministry of Textiles, Government of India
Udyog Bhawan
New Delhi – 110011

Member

(7)

Shri D. K. Biswas,
Chairman,
Central Pollution Control Board
Parivesh Bhawan,
East Arjun Nagar,
Delhi - 110 054]

Convenor

309

3

[The terms and conditions of the Chairman, after his superannuation, shall be determined
by the Central Government.]
The Authority shall exercise the following powers and perform the following functions
for protecting and improving the quality of the environment and preventing, controlling
and abating environmental pollution, namely:1. exercise the powers under section 5 of the said Act for issuing directions in
respect of complaints relating to the violation of an order by any authority or
measure specified pertaining to-

1
2
3

(i)

standards for the quality of the environment in its various aspects,

(ii)

standards for omission or discharge of environmental pollutants from
various sources,

Substituted vide S.O.99(E), dated 28.1.2003.
Inserted vide S.O.396 (E), dated 3.4.2003.
Inserted vide S.O.99(E), dated 28.1.2003.

<!-- page 14 -->

Notifications under the Environment (Protection) Act, 1986

310

(iii)

restriction of areas in which any industries, operations or processes
or class of industries or processes shall not be carried out or shall be
carried out subject to certain safeguards,

(iv)

procedures and safeguards for the prevention of accidents which may
cause environmental pollution and remedial measures for such
accidents,

(v)

procedures and safeguards for the handling of hazardous substances.

2. The Authority shall have the power to take up matters as mentioned above, suo-moto,
or on the basis of complaints made by any individual, representative body or
organization functioning in the field of environment. Such complaints may be against
any individual, association, company, public undertaking or local body carrying on
any industry, operation or process.
3. The Authority shall, for controlling vehicular pollution, take all necessary steps to
ensure compliance of specified emission standards by vehicles including proper
calibration of the equipment for testing vehicular pollution, ensuring compliance of
fuel quality standards, monitoring and coordinating action for traffic planning and
management.
4. The Authority shall, for ensuring maintenance of the specified ambient noise
standards, have the power to issue directions under section 5 of the said Act,
including banning or restricting any industry, process or operation emitting noise.
5. The Authority shall deal with environmental issues pertaining to the National Capital
Region which may be referred to it by the Central Government.
6. The Authority shall monitor the progress of the action plan drawn up by the Ministry
of Environment and Forests on pollution in Delhi as contained in the 'White Paper on
Pollution in Delhi with an Action Plan', issued by the Central Government on 3 rd
December, 1997.
7. The Authority shall exercise the powers of entry, inspection, search and seizure under
section 10 of the said Act, in respect of any action to be taken under sub-paragraph
(1) of the paragraph 2 of this Order.
8. The Authority shall exercise the power to take samples under section 11 of the said
Act, in respect of any action to be taken under sub-paragraph (1) of paragraph 2 of
this Order.
9. The Authority shall exercise the powers under section 19 of the said Act, for making
complaints against offences under the said Act and for non-compliance of directions
issued by it under sub-paragraph (1) of paragraph 2 of this Order.

<!-- page 15 -->

Notifications under the Environment (Protection) Act, 1986

311

10. The Authority shall have jurisdiction over the National Capital Region as defined in
clause (f) of section 2 of the National Capital Region Planning Board Act, 1985 (2 of
1985).
11. The foregoing powers and functions of the Authority shall be subject to the
supervision and control of the Central Government.
12. The Authority shall furnish a progress report about its activities at least once in two
months to the Central Government.
13. The Authority shall have its headquarters in National Capital Region.
14(1). Notification of the Government of India in Ministry of Environment and Forests
number S.O.704(E), dated the 9th October, 1996 consisting the Environmental
Impact Assessment Authority for the National Capital Region shall stand
superseded (expect in respect of things done or omitted to be done before such
supersession) from the date of publication of this Order.
14(2). Any matter which relates to the powers and functions enumerated in this Order,
and pending with the Environmental Impact Assessment Authority shall stand
transferred to the Environment Pollution (Prevention and Control) Authority for
the National Capital Region constituted under this Order.
14(3). Any matter specifically not falling within the scope and jurisdiction of the
Authority as so constituted shall be dealt with by the statutory authorities
concerned.

[File No. Q-18011/14/90-CPA]
VIJAY SHARMA, Jt. Secy.
Note:
The principal order was published in the Gazette of India vide number S.O.93(E), dated
the 29th January, 1998, amended vide S.O. 68(E), dated the 25th January, 2000, S.O.
108(E), dated the 25th January, 2002, S.O. 99(E), dated 28th January, 2003 and
S.O.396(E), dated 3rd April, 2003.

<!-- page 16 -->

312

Notifications under the Environment (Protection) Act, 1986

TAJ TRAPEZIUM ZONE POLLUTION
(PREVENTION AND CONTROL) AUTHORITY
THE MINISTRY OF ENVIRONMENT & FORESTS
ORDER
New Delhi, the 30th April, 2003
S.O. 489(E).- In exercise of the powers conferred by sub-section (1) and (3) of section 3
of the Environment (Protection) Act, 1986 (29 of1986) (hereinafter referred to as the said
Act) and in supersession of the order of the Government. of India in the Ministry of
Environment & Forests, number S.O.350(E), dated 17th May, 1999, except as things done
or omitted to be done before such supersession, the Central Government hereby reconstitutes the Taj Trapezium Zone Pollution (Prevention and Control) Authority
(hereinafter referred to as the Authority), consisting of the following persons, for a period
of two years with effect from the date of publication of this Official Gazette, namely:1.

Principal
Secretary/Secretary,
Environment
Department, Government of Uttar Pradesh

2.

Commissioner, Agra Division

3.

Deputy Inspector General of Police, Agra Range

Member

4.

Member

8.

Member Secretary, Central Pollution Control
Board
A representative of the Ministry of Environment
& Forests
A representative of the Ministry of Petroleum and
Natural Gas
A representative of the Archeological Survey of
India
Municipal Commissioner, Agra

9.

District Magistrate, Agra

Member

10.

Vice Chairman, Agra Development Authority

Member

11.

Member Secretary, Rajasthan Pollution Control
Board
A representative of Secretary, Environment,
Government of Rajasthan

Member

13.

District Magistrate, Bharatpur, Rajasthan

Member

14.

Deputy Inspector General of Police, Bharatpur
Range
Deputy Chief Wild Life Warden, Bharatpur Birds
Sanctuary

Member

5.
6.
7.

12.

15.

Chairman
Vice Chairman

Member
Member
Member
Member

Member

Member

<!-- page 17 -->

Notifications under the Environment (Protection) Act, 1986

313

16.

Secretary, Urban Improvement Trust, Bharatpur

Member

17.

Superintending Mining Engineer, Department of
Mines, Bharatpur

Member

18.

Member Secretary, Uttar Pradesh Pollution
Control Board

Member-Convenor

2. The geographical limits of the Taj Trapezium Zone (see Annexure) is defined in the
shape of a trapezoid between 260 45’N & 770 15’E to 270 45’N & 770 15’E in the West of
the Taj Mahal and in the East of Taj Mahal between 270 00’N & 780 30’E to 270 30’N &
780 30’E, lying in the Agra Division of Uttar Pradesh and in the Bharatpur Division of
the State of Rajasthan.
3.The Authority shall, within the geographical limits of Agra Division and Bharatpur
Division and the Taj Trapezium Zone in the States of Uttar Pradesh and Rajasthan
respectively, have the power to –
(i)

(ii)
(iii)

(iv)

monitor the progress of implementation of various schemes for protection
of the Taj Mahal and programmes for protection and improvement of the
environment in Taj Trapezium zone;
exercise powers under section 5 of the said Act;
take all necessary steps to ensure compliance of specified emission
standards by motor vehicles and ensuring compliance of fuel quality
standards;
deal with any environmental issue which may be referred to it by the
Central Government or the State Governments of Uttar Pradesh and
Rajasthan relating to the Taj Trapezium Zone.

4. The forgoing powers and functions of the Authority shall be subject to the overall
supervision and control of the Central Government.
5. The Authority shall be authorized to exercise the powers under section 19 of the said
Act.
6. The Authority may co-opt experts for facilitating the work assigning to it.
7. The Authority shall furnish a report about its activities at least once in two months to
the Central Government in the Ministry of Environment & Forests.
8. The Authority shall have its headquarter at Agra in the State of Uttar Pradesh.

[ F.No.Z-20018/1/99-CPA)
C.VISHWANATH, JT. SECY.

<!-- page 18 -->

Notifications under the Environment (Protection) Act, 1986

314

LOSS OF ECOLOGY (PREVENTION AND
PAYMENT OF COMPENSATION) AUTHORITY
MINISTRY OF ENVIRONMENT & FORESTS
NOTIFICATION
New Delhi, the 30th September, 1996
S.O.671(E).- In exercise of the powers conferred by sub-section (3) of section 3 of the
Environment (Protection) Act, 1986 (29 of 1986) hereinafter referred to as the said Act,
the Central Government hereby constitutes the Loss of Ecology (Prevention and
Payments of Compensation) Authority for the State of Tamil Nadu consisting of the
following members for a period of two years and from the date of publication of this
notification in the Official Gazette, namely:(1)

Chairperson
___________________________________________________________

(A retired Judge of the High Court to be appointed
by the Central Government)
(2)

The Secretary, Government of Tamil Nadu
Department of Environment, Chennai

Member

(3)

The Member Secretary
Central Pollution Control Board
Delhi

Member

(4)

__________________________________
(a person to be appointed by the Central
Government)

Member- Secretary

2. The Authority shall exercise the following powers and perform the following
functions, namely :(i)

exercise of powers under section 5 of the said Act, for issuing directions and
for taking measures with respect to matters referred to in Clauses (v), (vi),
(vii), (viii), (ix), (x) and (xii) of sub-section 2 of section 3 of section 3 of the
said Act;

(ii)

to assess the loss to the ecology and environment in the affected areas and
also identify the individuals and families who have suffered because of the
pollution and assess the compensation to be paid to the said individuals and
families;

<!-- page 19 -->

Notifications under the Environment (Protection) Act, 1986

315

(iii)

to determine the compensation to be recovered from the polluters as cost of
reversing the damaged environment;

(iv)

to lay down the procedure for actions to be taken under (i) to (iii) above;

(v)

to compute the compensation under two heads, namely, for reversing the
ecology and for payment to individuals;

(vi)

to direct the closure of any industry or class of industries owned or managed
by a polluter in case of evasion or refusal to pay the compensation awarded
against the polluter. This shall be in addition to the recovery from the
polluter as arrears of land revenue;

(vii)

to frame scheme or schemes for reversing the damage caused to the ecology
and environment by pollution in the State of Tamil Nadu in consultation with
expert bodies like National Environment Engineering Research Institute,
Central Pollution Control Board, etc. These schemes shall be executed by the
State Government of Tamil Nadu under the supervision of the Central
Government. The expenditure shall be met from the “Environment Protection
Fund” and from other sources provided by the State Government and the
Central Government;

(viii)

to view the cases of all the industries which are already operating in the
prohibited area and direct the relocation of any of such industries;

(ix)

to close the tanneries permanently or direct their relocation, which have not
provided adequate treatment facilities and not having valid certificate from
the Tamil Nadu State Pollution Control Board;

(x)

to comply with the orders issued by the Madras High Court and the Supreme
Court from time to time;

(xi)

to deal with any other relevant environment issues pertaining to the State of
Tamil Nadu, including those which may be referred to it by the Central
Government in the Ministry of Environment & Forest.

3. In exercise of its powers as defined in paragraph 2 above, the Authority shall
prepare a statement showing the total amount to be recovered, from the polluters
mentioning therein the names of the polluters from whom the amount is to be recovered,
the amount to be recovered from each polluter, the persons to whom the compensation is
to be paid and the amount payable to each of them. The statement shall be forwarded to
the Collector/District Magistrates of the area concerned who shall recover the amount
from the polluters, if necessary, as arrears of land revenue and shall disburse the
compensation awarded by the Authority to the affected persons and families.

<!-- page 20 -->

316

Notifications under the Environment (Protection) Act, 1986

4. The Authority shall furnish a progress report about its activities atleast once in
two months to the Central Government in the Ministry of Environment & Forests.
5. The Authority shall have its Headquarters at Chennai, Tamil Nadu.
6. The terms and conditions of appointment of the Chairperson and Members
shall be as determined by the Central Government from time to time.

[File No.Q-17012/63/91-CPW]
VISHWANATH ANANAD, Addl. Secretary

<!-- page 21 -->

Notifications under the Environment (Protection) Act, 1986

317

DELEGATION OF POWERS TO THE CHAIRMAN, CENTRAL
POLLUTION CONTROL BOARD UNDER SECTION 20 OF THE
ENVIRONMENT (PROTECTION) ACT, 1986
MINISTRY OF ENVIRONMENT AND FORESTS
NOTIFICATION
New Delhi, the 10th July, 2002
S.O. 729(E): In exercise of the powers conferred by Section 23 of the Environment
(Protection) Act, 1986 (29 of 1986), the Central Government hereby delegates the powers
vested in it under Section 20 of the said Act to the Chairman, Central Pollution Control
Board subject to the condition that the Central Government may revoke such delegation
of powers or may itself invoke the provisions of the said Section 20, if in the opinion of
that Government, such a course of action is necessary in public interest.
[F. No. 1(5)/95-PL]
K.C. MISRA, Spl. Secy.

DELEGATION OF POWERS TO THE CHAIRMAN, CENTRAL
POLLUTION CONTROL BOARD UNDER SECTION 5 OF THE
ENVIRONMENT (PROTECTION) ACT, 1986
MINISTRY OF ENVIRONMENT AND FORESTS
NOTIFICATION
New Delhi, the 10th July, 2002
S.O. 730(E): In exercise of the powers conferred by Section 23 of the Environment
(Protection) Act, 1986 (29 of 1986), the Central Government hereby delegates the powers
vested in it under Section 5 of the said Act to the Chairman, Central Pollution Control
Board to issue directions to any industry or any local or other authority for the violation
of the standards and rules relating to hazardous waste, bio-medical waste, hazardous
chemicals, industrial solid waste, municipal solid waste including plastic waste notified
under the Environment (Protection) Act, 1986 subject to the condition that the Central
Government may revoke such delegation of powers in respect of all the State
Governments or any one of them or may itself invoke the provisions of Section 5 of the
Act, if in the opinion of the Central Government such a course of action is necessary in
public interest.
[F.No. 1(5)/95-PL]
K.C. MISRA, Spl. Secy.

<!-- page 22 -->

Notifications under the Environment (Protection) Act, 1986

318

DELEGATION OF POWERS TO THE STATE POLLUTION
CONTROL BOARDS/POLLUTION CONTROL COMMITTEES
MINISTRY OF ENVIRONMENT AND FORESTS
NOTIFICATION
New Delhi, the 8th January, 1997
S.O. 23(E).- In exercise of the powers conferred by Section 23 of the Environment
(Protection) Act, 1986 (29 of 1986), the Central Government hereby delegates the powers
vested in it under Section 5 of the said Act to the Chairman, State Pollution Control
Boards/Committees as given in the Table below, to issue directions to any industry or any
local or other authority for the violations of the standards and rules relating to hazardous
wastes notified under the Environment (Protection) Act, 1986, subject to the conditions
that the Central Government may revoke such delegation of powers or may itself invoke
the provisions of Section 5 of the said Act, if in the opinion of the Central Government
such a course of action is necessary in the public interest:TABLE
Sl. No.

Name of Board/Committee

Jurisdiction

1

2

3

1.

Andhra Pradesh State Pollution Control Board

Whole of State

2.

Arunanchal Pradesh State Pollution Control

Whole of State

Board
3.

Assam State Pollution Control Board

Whole of State

4.

Bihar State Pollution Control Board

Whole of State

5.

Goa State Pollution Control Board

Whole of State

6.

Gujarat State Pollution Control Board

Whole of State

7.

Haryana State Pollution Control Board

Whole of State

8.

Himachal Pradesh State Pollution Control Board

Whole of State

9.

Jammu & Kashmir State Pollution Control

Whole of State

Board
10.

Karnataka State Pollution Control Board

Whole of State

11.

Kerala State Pollution Control Board

Whole of State

12.

Maharashtra State Pollution Control Board

Whole of State

<!-- page 23 -->

Notifications under the Environment (Protection) Act, 1986

13.

Madhya Pradesh State Pollution Control Board

Whole of State

14.

Manipur State Pollution Control Board

Whole of State

15.

Meghalaya State Pollution Control Board

Whole of State

16.

Mizoram State Pollution Control Board

Whole of State

17.

Nagaland State Pollution Control Board

Whole of State

18.

Orissa State Pollution Control Board

Whole of State

19.

Punjab State Pollution Control Board

Whole of State

20.

Rajasthan State Pollution Control Board

Whole of State

21.

Sikkim State Pollution Control Board

Whole of State

22.

Tamil Nadu State Pollution Control Board

Whole of State

23.

Tripura State Pollution Control Board

Whole of State

24.

Uttar Pradesh State Pollution Control Board

Whole of State

25.

West Bengal State Pollution Control Board

Whole of State

26.

Committee, Andaman & Nicobar Union

Whole of U.T.

319

Territory
27.

Committee, Chandigarh Union Territory

Whole of U.T.

28.

Committee, Dadra & Nagar Haveli Union

Whole of U.T.

Territory
29.

Committee, Daman & Diu Union Territory

Whole of U.T.

30.

Committee, National Capital Territory of Delhi

Whole of N.C.T.

31.

Committee, Lakshadweep Union Territory

Whole of U.T.

32.

Committee, Pondicherry Union Territory

Whole of U.T.

[No.1(35)/96-PL]
VIJAY SHARMA, Jt. Secy.

<!-- page 24 -->

Notifications under the Environment (Protection) Act, 1986

320

DELEGATION OF POWERS TO THE STATE POLLUTION CONTROL
BOARDS/POLLUTION CONTROL COMMITTEES
MINISTRY OF ENVIRONMENT AND FORESTS
NOTIFICATION
New Delhi, the 10th April, 2001
S.O. 327(E).- In exercise of the powers conferred by Section 23 of the Environment
(Protection) Act, 1986 (29 of 1986), the Central Government hereby delegates the powers
vested in it under Section 5 of the said Act to the Chairman, State Pollution Control
Boards/Committees as given in the Table below, to issue directions to any industry or any
local or other authority for the violations of the standards and rules relating to Bio
Medical Waste, Hazardous Chemicals, Industrial Solid Waste and Municipal Solid Waste
including Plastic Waste notified under the Environment (Protection) Act, 1986, subject to
the conditions that the Central Government may revoke such delegation of powers or
may itself invoke the provisions of Section 5 of the said Act, if in the opinion of the
Central Government such a course of action is necessary in the public interest:TABLE
Sl. No.

Name of Board/Committee

Jurisdiction

(1)

(2)

(3)

1.

Andhra Pradesh State Pollution Control Board

Whole of State

2.

Arunanchal Pradesh State Pollution Control

Whole of State

Board
3.

Assam State Pollution Control Board

Whole of State

4.

Bihar State Pollution Control Board

Whole of State

5.

Goa State Pollution Control Board

Whole of State

6.

Gujarat State Pollution Control Board

Whole of State

7.

Haryana State Pollution Control Board

Whole of State

8.

Himachal Pradesh State Pollution Control Board

Whole of State

9.

Jammu & Kashmir State Pollution Control

Whole of State

Board
10.

Karnataka State Pollution Control Board

Whole of State

11.

Kerala State Pollution Control Board

Whole of State

<!-- page 25 -->

Notifications under the Environment (Protection) Act, 1986

12.

Maharashtra State Pollution Control Board

Whole of State

13.

Madhya Pradesh State Pollution Control Board

Whole of State

14.

Manipur State Pollution Control Board

Whole of State

15.

Meghalaya State Pollution Control Board

Whole of State

16.

Mizoram State Pollution Control Board

Whole of State

17.

Nagaland State Pollution Control Board

Whole of State

18.

Orissa State Pollution Control Board

Whole of State

19.

Punjab State Pollution Control Board

Whole of State

20.

Rajasthan State Pollution Control Board

Whole of State

21.

Sikkim State Pollution Control Board

Whole of State

22.

Tamil Nadu State Pollution Control Board

Whole of State

23.

Tripura State Pollution Control Board

Whole of State

24.

Uttar Pradesh State Pollution Control Board

Whole of State

25.

West Bengal State Pollution Control Board

Whole of State

26.

Committee, Andaman & Nicobar Union

Whole of U.T.

321

Territory
27.

Committee, Chandigarh Union Territory

Whole of U.T.

28.

Committee, Dadra & Nagar Haveli Union

Whole of U.T.

Territory
29.

Committee, Daman & Diu Union Territory

Whole of U.T.

30.

Committee, National Capital Territory of Delhi

Whole of N.C.T.

31.

Committee, Lakshadweep Union Territory

Whole of U.T.

32.

Committee, Pondicherry Union Territory

Whole of U.T.

[No.1(35)/96-PL]
VIJAY SHARMA, Jt. Secy.

<!-- page 26 -->

322

Notifications under the Environment (Protection) Act, 1986

UTILISATION OF FLYASH FROM COAL OR LIGNITE BASED
THERMAL POWER PLANTS
MINISTRY OF ENVIRONMENT AND FORESTS
NOTIFICATION
New Delhi, the 14th September, 1999

S.O.763(E).- Whereas a draft notification containing rule (3) of rule 5 of the
Environment (Protection) Rules, 1986 under the notification of the Government of India
in the Ministry of Environment and Forests number S.O. 453(E) dated 22nd May, 1998
inviting objections and suggestions from all persons likely to be affected thereby, before
the expiry of the period of sixty days from the date on which the copies of the Gazette of
India containing the said notification are made available to the public;
And, whereas, copies of the said Gazette were made available to the public on the
same date;
And, whereas, the objections and suggestions received from the public in respect of
the said draft notification have been duly considered by the Central Government;
Whereas it is necessary to protect the environment, conserve top soil and prevent the
dumping and disposal of fly ash discharged from coal or lignite based thermal power
plants on land;
And, whereas, there is a need for restricting the excavation of top soil for
manufacture of bricks and promoting the utilisation of fly ash in the manufacture of
building materials and in construction activity within a specified radius of 1[one hundred
kilometers] from coal or lignite based thermal power plants;
And, Whereas, the Hon'ble High Court of Judicature, Delhi vide its order dated
25th August, 1999 in CWP No. 2145/99: Centre for Public Interest Litigation, Delhi v/s
Union of India directed that the Central Government to publish the final notification in
respect of fly ash on or before 26th October, 1999;
Now, therefore, in exercise of the powers conferred by sub-section (1), read with
clause (v) of sub-section (2) of section 3 and section 5 of the Environment (Protection)
Act, 1986 (29 of 1986); and in pursuance of the orders of the Hon'ble High Court, Delhi
stated above, the Central Government hereby issues the following directions which shall
come into force on the date of the publication of this notification, namely:-

1

Substituted by para 1 of the Notification S.O.979 (E), dated 27.8.2003 .

<!-- page 27 -->

Notifications under the Environment (Protection) Act, 1986

323

1. Use of fly ash, bottom ash or pond ash in the manufacture of bricks and
other construction activities.(1) No person shall within a radius of 1[one hundred kilometers] from coal or
lignite based thermal power plants, manufacture clay bricks or tiles or blocks
for use in construction activities without mixing at least 25 per cent of ash
(fly ash, bottom ash or pond ash) with soil on weight to weight basis.
2

[(1A) Every construction agency engaged in the construction of buildings within a
radius of fifty to one hundred kilometres from a coal or lignite based thermal
power plant shall use fly ash bricks or blocks or tiles or clay fly ash bricks or
cement fly ash bricks or blocks or similar products or a combination or
aggregate of them in such construction as per the following minimum
percentage (by volume) of the total bricks, blocks and tiles, as the case may
be, used in each construction project, namely:(i) 25 per cent by 31st August 2004;
(ii) 50 per cent by 31st August 2005;
(iii) 75 per cent by 31st August, 2006; and
(iv) 100 per cent by 31st August 2007.

In respect of construction of buildings within a radius of 50 kilometres from a coal
or lignite based thermal power plant the following minimum percentage (by
volume) of use of bricks, blocks and tiles shall apply: (i)
(ii)

50 per cent by 31st August 2004;
100 per cent by 31st August 2005.

(1B) The provisions of sub-paragraph (1A) shall be applicable to all construction
agencies such as Housing Boards and those in the private sector builders of
apartments, hotels, resorts and cottages and the like. It shall be the
responsibility of the construction agencies either undertaking the construction
or approving the design or both to ensure compliance of the provisions of
sub-paragraph (1A) and to submit such returns as may be called for and
compliance reports to the State Government or Union territory
Administration]
3

[(2) The authority for ensuring the use of specified quantity of ash as per subparagraph (1) shall be the concerned Regional Officer of the State Pollution
Control Board or the Pollution Control Committee, as the case may be.

1
2

3

Substituted by para 2 (a) of the Notification S.O.979(E), dated 27.8.2003.
Inserted by para 2 (b), ibid.
Substituted by para 2(c), ibid.

<!-- page 28 -->

Notifications under the Environment (Protection) Act, 1986

324

(2A)The concerned State Government shall be the enforcing and monitoring authority
for ensuring compliance of the provisions of sub- paragraph (lA)].
(3) In case of non-availability of ash from thermal power plant in sufficient
quantities as certified by the said power plant, the stipulation 1[under subparagraph (1)] shall be suitably modified (waived/ relaxed) by the concerned
State/Union Territory Government.
2

[(3A) A decision on the application for manufacture of fly ash bricks, block, and
tiles and similar other fly ash based products shall be taken within thirty days
from the date of receipt of the application by the competent authority. A
decision on consent to establish the brick kiln shall be taken by the Pollution
Control Board or the Pollution Control Committee, as the case may be,
within a period of thirty days from the date of receipt of application by it.
(3B) In case of non-compliance of the provisions of sub-paragraph (1) of
paragraph 1, the competent authority, in addition to cancellation of consent
order issued to establish the brick kiln, shall move the district administration
for cancellation of the mining lease.
(3C) All authorities sanctioning or renewing any land, soil or clay mining lease
shall not grant such lease or extension of lease or renewal to clay brick,
block or tile manufacturing unit within a radius of one hundred kilometres of
the coal or lignite based thermal power plant in cases where the manufacturer
does not mix a minimum of 25 per cent by weight of fly ash or pond ash in
the manufacture of bricks or blocks or tiles. The cancellation of mining lease
shall be decided by the district administration after giving the holder of such
lease an opportunity of being heard. To enable the competent authority to
verify the actual use of ash, the thermal power plant shall maintain monthwise records of ash made available to each brick kiln.
(3D) It shall be sufficient compliance of this notification if within twelve months
from the date of issue of this notification, manufacturers of clay bricks,
blocks and tiles located within a radius of 50 to 100 kilometres of a coal or
lignite based thermal power plant comply with the provisions of subparagraphs (1) and (2).]

1
2

Substituted by para 2(d) of Notification S.O.No. 979(E), dated 27.8.2003.
Inserted by para 2(e), ibid.

<!-- page 29 -->

Notifications under the Environment (Protection) Act, 1986

325

(4) Each coal or lignite based thermal power plant shall constitute a dispute
settlement committee which shall include the General Manager of the thermal
power plant and a representative of All India Brick and Tile Manufacture's
Federation (AIBTMF) 1[or a representative of brick kiln owner association,
federation, group]. Such a committee shall ensure unhindered loading and
transport of ash without any undue loss of time. Any unresolved dispute shall
be dealt with by a State/Union Territory level committee to be set up by
State/Union Territory Government comprising Member Secretary of the State
Pollution Control Board/Pollution Control Committee, representatives of
Ministry of Power in the State/Union Territory Government and a
representative of AIBTMF 2[or a representative of local brick kiln owners
association, federation, group.]
3

1
2
3

[(5)

No agency, person or organization shall, within a radius of 100 kilometres of
a thermal power plant undertake construction or approve design for
construction of roads or flyover embankments in contravention of the
guidelines/ specifications issued by the Indian Road Congress (IRC) as
contained in IRC specification No. SP: 58 of 2001. Any deviation from this
direction can only be agreed to on technical reasons if the same is approved
by Chief Engineer (Design) or Engineer-in-Chief of the concerned agency or
organization or on production of a certificate of "Pond ash not available”
from the thermal power plant(s) (TPPs) located within 100 kilometres of the
site of construction. This certificate shall be provided by the TPP within two
working days from the date of making a request for ash.

(6)

Soil required for top or side covers of embankments of roads or flyovers shall
be excavated from the embankment site and if it is not possible to do so, only
the minimum quantity of soil required for the purpose shall be excavated
from soil borrow area. In either case, the topsoil should be kept or stored
separately. Voids created due to soil borrow area shall be filled up with ash
with proper compaction and covered with topsoil kept separately as above.
This would be done as an integral part of embankment project within the
time schedule of the project.

(7)

No agency, person or organization shall within a radius of 100 kilometres of
a coal or lignite based thermal power plant allow reclamation and
compaction of low-lying areas with soil. Only pond ash shall be used for
compaction. They shall also ensure that such reclamation and compaction is
done in accordance with the bye-laws, regulations and specifications laid
down by the authorities mentioned in sub- paragraph (3) of paragraph 3.]

Inserted by para 2(f), of Notification S.O.No. 979(E), dated 27.8.2003.
Inserted by para 2(f) of Notification S.O.No.979(E), dated 27.8.2003.
Inserted by para 2(g) of Notification S.O.No.979(E), dated 27.8.2003.

<!-- page 30 -->

326

Notifications under the Environment (Protection) Act, 1986

2. 1[Responsibilities of Thermal Power Plants].
2

[Every coal or lignite based thermal power plant shall take the following steps to ensure
the utilisation of ash generated by it, namely: -]
(1) Every coal or lignite based thermal power plant shall make available ash, for at
least ten years from the date of publication of this notification, without any
payment or any other consideration, for the purpose of manufacturing ash-based
products such as cement, concrete blocks, bricks, panels 3[or any other material
or a combination thereof] for construction of roads, embankments, dams, dykes
or for any other construction activity. 4[The thermal power plants have to ensure
availability of fair quantity of ash to each user including brick kilns.]
(2) Every coal or lignite based thermal power plant commissioned subject to
environmental clearance conditions stipulating the submission of an action plan
for full utilisation of fly ash shall, within a period of nine years from the
publication of this notification, phase out the dumping and disposal of fly ash on
land in accordance with the plan. Such an action plan shall provide for thirty per
cent of the fly ash utilisation, within three years from the publication of this
notification with further increase in utilisation by atleast ten per cent points every
year progressively for the next six years to enable utilisation of the entire fly ash
generated in the power plant atleast by the end of ninth year. Progress in this
regard shall be reviewed after five years.
(3) Every coal or lignite based thermal power plant not covered by para (2) above
shall, within a period of fifteen years from the date of publication of this
notification, phase out the utilisation of fly ash in accordance with an action plan
to be drawn up by the power plants. Such action plan shall provide for twenty per
cent of fly ash utilisation within three years from the date of publication of this
notification, with further increase in utilisation every year progressively for the
next twelve years to enable utilisation of the entire fly ash generated in the power
plant.
(4) All action plans prepared by coal or lignite based thermal power plants in
accordance with sub-para (2) and (3) of para 2 of this notification, shall be
submitted to the Central Pollution Control Board, concerned State Pollution
Control Board/Committee and concerned regional office of the Ministry of
Environment and Forests within a period of six months from the date of
publication of this notification.

1
2
3
4

Substituted by para 3(a), of Notification S.O.No.979(E), dated 27.8.2003.
Substituted by para 3(b), ibid.
Inserted by para 3 (c) (i), ibid.
Added by para 3(c) (ii), ibid.

<!-- page 31 -->

Notifications under the Environment (Protection) Act, 1986

327

(5) The Central and State Government Agencies, the State Electricity Boards, the
National Thermal Power Corporation and the management of the thermal power
plants shall facilitate in making available land, electricity and water for
manufacturing activities and provide access to the ash lifting area for promoting
and setting up of ash-based production units in the proximity of the area where
ash is generated by the power plant.
(6) Annual implementation report providing information about the compliance of
provisions in this notification shall be submitted by the 30th day of April every
year to the Central Pollution Control Board, concerned State Pollution Control
Board/Committee and the concerned Regional Office of the Ministry of
Environment and Forests by the coal or lignite based thermal power plants.
1

[2A. Utilization of fly ash for reclamation of sea.

Subject to the rules made under the Environment (Protection) Act, 1986, (29 of 1986)
reclamation of sea shall be a permissible method of utilization of fly ash.]
3. Specifications for use of ash-based products.(1) Manufacture of ash-based products such as cement, concrete blocks, bricks,
panels or any other material or the use of ash in construction activity such as in
road laying, embankments or use as landfill to reclaim low lying areas including
back filling in abandoned mines or pitheads or for any other use shall be carried
out in accordance with specifications and guidelines laid down by the Bureau of
Indian Standards, Indian Bureau of Mines, Indian Road Congress, Central
Building Research institute, Roorkee, Central Road Research Institute, New
Delhi, Building Materials and Technology Promotion Council, New Delhi,
Central Public Works Department, State Public Works Departments and other
Central and State Government agencies.
(2) The Central Public Works Department, Public Works Departments in the
State/Union Territory Governments, Development Authorities, Housing Boards,
National Highway Authority of India and other construction agencies including
those in the private sector shall also prescribe the use of ash and ash-based
products in their respective schedules of specifications and construction
applications, including appropriate standards and codes of practice, within a
period of four months from the publication of this notification.
2

[(2A)All agencies including the Central Public Works Department and State
Government agencies concerned with utilization of fly ash for construction
purposes shall, within three months from the 1st day of September, 2003 make

1
2

Inserted by para 4 of the Notification S.O.No. 979(E), dated 27.8.2003.
Inserted by para 5 of the Notification S.O.979(E), dated 27.8.2003..

<!-- page 32 -->

Notifications under the Environment (Protection) Act, 1986

328

provisions for the use of fly ash and fly ash based bricks, blocks or tiles or
aggregates of them in the schedule of approved materials and rates.

(2B) All agencies undertaking construction of roads or fly over bridges including
Ministry of Road Transport and Highways (MORTH), National Highways
Authority of India (NHAI), Central Public Works Department (CPWD), State
Public Works Departments and other State Government Agencies, shall, within
three months from the 1st day of September, 2003 –
a.

make provisions in their tender documents, schedules of approved
materials and rates as well as technical documents, including those
relating to soil borrow area or pit as per sub-paragraph (7) of paragraph
1; and

b.

make necessary specifications/guidelines for road or fly over
embankments that are not covered by the specifications laid down by the
Indian Road Congress (IRC).]

(3) All local authorities shall specify in their respective building bye-laws and
regulations the use of ash and ash-based products and construction techniques in
building materials, roads, embankments or for any other use within a period of
four months from the date of publication of this notification.

[F. No. 16-2/95-HSMD]
V RAJAGOPALAN, Jt. Secy.

Footnote. - The principal notification was published in the Gazette of India, Part II,
Section 3, sub-section (ii) vide S.O.763 (E) dated 14.9.1999.
