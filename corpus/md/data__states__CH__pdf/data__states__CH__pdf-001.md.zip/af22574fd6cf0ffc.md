---
doc_id: "af22574fd6cf0ffc"
source_url: "https://chandigarh.gov.in/cadmin//uploads/1777979309_95c62d259ed180fa70f7.pdf"
ministry: "Agriculture Department, Chandigarh"
title: "title_en'>2nd Amendments to the Chandigarh Electric Vehicle (EV) Policy, 2022"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0d8aa46526aac9ae"
---

<!-- page 1 -->

CHANDIGARH ADMINISTRATION
DEPARTMENT OF SCIENCE &TECHNOLOGY & RENEWABLE ENERGY
Notification

Chandigarh, dated the. J&/le..l2023

No. S&T&RE/2023/. )9

2"" Amendments to the Chandigarh Electric Vehicle (EV) Policy, 2022
WHEREAS, the earlier notification vide no. S&T&RE/2022/893 dated 20.09.2022 &

S&T&RE/2023/504 dated 07.07.2023 was issued by the Department of Science and Technology
&Renewable Energy, Chandigarh Administration vide which the "Electric Vehicle Policy,
2022 tramed to build UT Chandigarh as a 'Model EV City' by achieving one of the
highest penetration of zero emission vehicles amongst all Indian cities by the end of
the Policy (19" Sep, 2027) period was notified.

AND WHEREAS, as per the provisions of the policy, UT Electric Vehicle
Advisory Committee conducted 2nd Mid-Term meeting to review the implementation
and effectiveness of the UT Electric Vehicle policy and undertook necessary

amendments to achieve the objectives of the policy.
NOW, THEREFORE, the Administrator U.T., Chandigarh has approved the

Amendments proposed to the Chandigarh EV Policy-2022 which is annexed herewith
as Annexure-1 and the Amendments will come into force with immediate effect.

These Amendments are available on official website of the department;

solar.chd.gov.in under News & Updates Section as well as on Chandigarh

Administration's website; chandigarh.gOv.in.
Chandigarh dated:

the 18" Oct 2023

Dr. DHARAM PAL, IAS

Adviser to the Administrator

Chandigarh Administration
Endst. No. 1/2

A copy is forwarded to

Administration for information.

Chandigarh, dated the../P|/e 2023

all HODs/ Boards/ Corporations, Chandigarh

(T.C Nautiyal), *Fs
Secretary (S&T&RE)

Chandigarh Administration

Page 1 of 2

<!-- page 2 -->

Endst.No. 021 - )29

Chandigarh, dated the.. J2/.le.]2023

1. PS to Hon'ble Administrator,UT Chandigarh, for kind information please.
2. PS to Adviser to the Administrator, for kind information please.

(T.C Nautyàl, s
Secretary (S&T&RE)
Chandigarh Administration

Endst.No. I|22- 125

Chandigarh, datedthe. le.!.2023

1. The Director Public Relation, Chandigarh Administration with the request that the

above notification may kindly be given wide publicity.
2. The Director Information Technology, Chandigarh Administration, Chandigarh, for
information with a request to get it uploaded on the website of Chandigarh
Administration.

3. The Nodal Officer of e-Gazette Notification, Department of Science & Tech. & RE, UT

Chandigarh for uploading this notification on the Chandigarh Administration e
Gazette portal.

(T.C Nautiyal), IFS

Secretary (S&T&RE)
Chandigarh Administration

<!-- page 3 -->

ANNEXURE-I

Chandigarh Administration

Department of Science and Technology & Renewable Energy
Amendments tothe Chandigarh ElectricVehicle (EV) Policy, 2022
A.

The proposed amendment to Clause 2.3 of policy dated 20.09.2022 will read as:
To accelerate adoption of EVs in the UT, new and flexible targets have been fixed
under different categories of electric vehicles in order to achieve highest penetration
of new vehicle registration by the end of policy period and the revised targets are as
below:

Revised Targets 2n Year onwards

Category

(Share of EVs in new vehicle registrations by the end of
policy period)

Year-2

Year-3

Year-4

Year-5

15%

30%

50%

100%

(Passenger Autos)
e-3W (Goods)

100%

100%

100%

100%

35%

60%

80%

100%

e-4W Goods

15%

30%

60%

100%

e-Cars - Personal

12%

25%

35%

55%

e Cars -Commercial

40%

60%

80%

e-2W
e-3W

100%
100%

e Buses
25%

50%

75%

Electric/Altern
ate Fuel

*It is to be noted that the internal combustion engine vehicles of each category as

specified above will have only leftover percentage of quota of the target table above on
YOY basis for registration in Chandigarh. Once the target set for EV's (Applicable for all
the above categories) is achieved, the ICE Vehicles registration will again be allowed
beyond its capping in the said Financial Year.
B.

New point No. 8 &9 are inserted in Clause 4.1.2: Provisions applicable across vehicle
segments in the Chandigarh EV Policy 2022:

The registration of CNG (Compress Natural Gas) Vehicles will not be barred under
targets set in EV Policy and will be accounted separately.
9.

Parking (Public Parking Area) willfree for all EVs across UT Chandigarh.

Page 1 of 1
