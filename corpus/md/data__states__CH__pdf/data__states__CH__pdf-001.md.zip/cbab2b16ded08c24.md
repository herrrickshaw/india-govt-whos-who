---
doc_id: "cbab2b16ded08c24"
source_url: "https://geology.puchd.ac.in/includes/tenders/2018/20181008142528-geology.pdf"
ministry: "Department of Geology, Panjab University, Chandigarh"
title: "Supply,Installation and Commissioning of Atomic Absorption Spectrophotometer (AAS) (e - Procurement)"
date: ""
pages: 55
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4063109f4ef0e46a"
---

<!-- page 1 -->

DEPARTMENT OF GEOLOGY
PANJAB UNIVERSITY, SECTOR-14,
CHANDIGARH-160014

E-TENDER DOCUMENT
For

Supply, Installation and Commissioning of
Atomic Absorption Spectrophotometer (AAS)
(e-Procurement)

Installation Site: Department of Geology, Panjab University,
Chandigarh (U.T), India.

E-Tender Number: 1866/G DATED: 04.10.2018

<!-- page 2 -->

IMPORTANT DATE& TENDER DETAILS

E-TENDER REF. NO.

1866/GDATED: 04.10.2018

NIT ISSUE DATE
LAST DATE AND TIME FOR
SUBMISSION OF TENDER (ONLINE)

05.10.2018

DATE & TIME OF OPENING OF
TTECHNICAL BID

29.10.2018 AT15.00 HRS, AT OFFICE
OF CHAIRPERSON, DEPARTMENT
OF GEOLOGY, PANJAB
UNIVERSITY, CHANDIGARH,.

DATE &TIME OF OPENING OF
FINANCIAL BID

Date and time will be intimated and displayed
on the website notice Board, Geology
Department, Panjab University, Chandigarh at
http://geology.puchd.ac.in/shownoticeboard.php

PRICE OF TENDER DOCUMENT
TENDER FEE

NIL
NIL

EARNEST MONEY (EMD)

RS. 35,000/-

EMD PAYABLE TO

Registrar, Panjab University, Chandigarh

PAYMENT MODE
BOQ Document Type

OFFLINE
.PDF

28.10.2018 by 18:00 Hrs. (IST)

<!-- page 3 -->

NOTICE INVITING E-TENDER (e-Procurement)
Panjab University, Chandigarh, an Educational Institute of National Importance,
invites e-tenders from the authorized distributors/dealers for Supply, Installation
and Commissioning of Atomic Absorption Spectrophotometer (AAS). This bid is
invited for “Supply, Installation, Implementation and Commissioning AAS with
three (3) year onsite warranty at Department of Geology, Panjab University,
Chandigarh. You are requested to quote your best offer along with the complete
details of specifications, terms & conditions. The e-tender document can be
downloaded from website, at URL Link: http://geology.puchd.ac.in/showtenders.php,https://etenders.chd.nic.in/nicgep/app,
http://cc.puchd.ac.in/showtenders.php.
Sl. No.

Item

Description

and Quantity

Technical Specification
1.

As per Annexure-A

As per Annexure-A

(a)Bidders are advised to study the Bid document carefully. Online Submission of bids shall be
deemed to have been done after careful study and examination of the bid document with full
understanding of its implications. Offers prepared in accordance with the procedures enumerated
should be submitted online through e-Procurement System Chandigarh UT Administration
https://etenders.chd.nic.in/nicgep/appnot later than the date and time specified in the Schedule
for Invitation to Bid under General Terms and conditions. Prospective Bidders are advised to
follow the instructions provided in the “General Instruction to Bidders” for e-submission of the
bids online through e-Procurement System Chandigarh UT Administration for e-Procurement
athttps://etenders.chd.nic.in/nicgep/app. Bid documents may be scanned with 100 dpi with black
and white option which helps in reducing size of the scanned document.
Manual bids shall not be accepted.
(b)

Bidder who has downloaded the tender from e-Procurement System Chandigarh UT

Administration https://etenders.chd.nic.in/nicgep/app, shall not tamper/modify the tender form
including EMD and tender fee template in any manner. In case if the same is found to be

Page 1 of 53

<!-- page 4 -->

tampered/ modified in any manner, tender will be completely rejected and EMD would be
forfeited and bidder is liable to be banned from doing business with CDAC.
(c) Prospective bidders are advised to visit e-Procurement System Chandigarh UT
Administration https://etenders.chd.nic.in/nicgep/appat least 3 days prior to closing date of
submission of tender for any corrigendum / addendum/ amendment.
(d) The original instruments in respect of Earnest Money Deposit etc. must be delivered to the
address as mentioned in the General terms and condition by the last date and time of bid
submission as mentioned in Important Date section. No receipt of the same by Dr. Debabrata
Das, Principal Investigator (SERB-DST Project), Department of Geology, Panjab
University, Sector-14, Chandigarh-160014 (U.T) before the bid submission due date and time
shall lead to disqualification of the Bidder.
(e) All Bids must be accompanied by an EMD (Earnest Money Deposit) of Rs. 35000 (Rupees
Thirty Five Thousand).
The Bank Demand Draft should from a Nationalized Bank or Scheduled Bank registered with
Reserve Bank of India (RBI) in favour of “Registrar, Panjab University, Chandigarh” and
payable at Chandigarh. The Bid Document Fee is free of cost and Tender Participation fee is nil.
(f) Bids shall be submitted online only at e-Procurement System Chandigarh UT
Administration https://etenders.chd.nic.in/nicgep/app
Note: Panjab University shall not be responsible for non-receipt / non-delivery of bid
documents due to any reason whatsoever.

Page 2 of 53

<!-- page 5 -->

General Terms & Conditions:
Dr. Debabrata Das, Principal Investigator, SERB-DST project (Groundwater Uranium
Contamination in Barnala District and Adjoining areas of South-West Punjab: Genesis
and Characterization of Fundamental Hydrogeological and Hydrochemical Processes
that Control Uranium Mobilization and Transport in Groundwater) and Assistant
Professor, Department of Geology, Panjab University Chandigarh is interested in the
procurement, installation, commissioning and training of the use of Atomic Absorption
Spectrophotometer (AAS)as per the prescribed technical specifications (Annexure-as per
following e-procurement schedule:
(a) Last Date and Time for Submission of bids
(b) Date & Time of opening of technical bids
(c) Date & Time of opening of Price bids
(d) Date and Time of demonstration of product

:
:
:
:

28.10.2018, 6:00 PM.
29.10.2018, 3.00 PM.
Date & time will be intimated.
Date & time will be intimated.

Note-1: In case the date of opening of the bids fall on the day which is declared public
holiday, these shall be opened on the following day at the appointed time.

(i)

(ii)

(iii)
(iv)

(v)

Only manufacturers or their authorized distributors/agents are eligible to submit
the bids. All offers other than those from the manufacturers should be supported
by an authority letter from the manufacturers or attested copy thereof authorizing
the firm to tender on their behalf.
The tenderer must be a manufacturer or his authorized agent (specifically against
this tender for the subject goods) and should have successfully executed contracts
for similar and/or identical goods in the past.
The detailed technical specifications are available for each item in Annexure A.
Technical specifications are intended to be descriptive and not restrictive. The
bidder may substitute alternative standards, in its bids, provided they are
demonstrated to be equivalent or superior substitutes and are to the purchaser’s
satisfaction.
Clarifications, if any could be sought from Dr. Debabrata Das (Assistant
Professor, Department of Geology, Panjab University, Chandigarh) in writing
within the stipulated last date of submission of the tender (Emaildebabratadas@pu.ac.in., Mob: 7087097510.)

Page 3 of 53

<!-- page 6 -->

Eligibility Criteria
The following criteria must strictly be fulfilled by the bidder. The bidder must submit
documentary evidence in support of their claim for fulfilling the criteria and they should submit
an undertaking on their letterheads to the fairness of these documents while submitting the bid.
The bids received without the documentary evidence will be rejected out rightly. Incomplete bids
or bids deviating from minimum eligibility criteria defined below will be treated as unresponsive
and shall not be considered eligible for further evaluation.
Sr. No. Criteria
Supporting documents to be submitted
1
Bidder should be registered as
Certificate of Incorporation
Limited/
/Registration, Partnership Deed/TIN
Private Limited / Proprietorship/
Registration/registration of agency
Partnership/society etc. all types of
Registered firms.
2
Must have an average annual
Copy of Audited Balance sheets along
turnover of last three years for the
with Profit and loss statements with
financial years 2015-16, 2016-17 &
highlighted relevant figures (in case the
2017-18 not less than Rs.2 crore
audited financial statements do not
reflect the above, original Statutory
Auditors' certificate on the actual
relevant figures)
3
Must be registered with the Indian
Copy of PAN Card/valid Service Tax
Service Tax department
Registration Certificate in the name of
the company
4
Should not be blacklisted by the
As per Annexure-H signed by competent
Central/State Government and Public authority
sector
5
Bidder should have service/support
Location and Address of the service/support
center for AAS in India
centre.

Bid details and Check lists:
The two part bid system will be followed for this e-tender. In this system, bidder must submit
their offer - online as explained below:
Technical Bid: Technical bid shall contain the following information
a) EMD and Bidder Eligibility & Pre-qualification as per Table-1 below
b) Technical proposal as per Table-2

Commercial Bid: Commercial bid shall contain the information mentioned in Table-3
The technical bid should not contain any commercial information, in case contains any
commercial information, the bid will be disqualified
Note: Please check the checklists below for submitting the Technical Bid and Commercial Bid.

Page 4 of 53

<!-- page 7 -->

a) Check list (as in Table-1 and Table-2) should be duly filled, signed and scanned and should be
made as part of Technical Bid to be uploaded. The supporting documents specified in the
attachments shall also be uploaded.
b) Check-list (as in Table-3) should be duly filled, signed should be made as part of the
Commercial Bid to be uploaded along with supporting documents specified in the Attachment.

Table-1: Check List of Eligibility and Pre-qualification documents to be
uploaded in the Technical Bid (Bidder Eligibility & Pre-Qualification Criteria)
Sl. No.

Bidder Eligibility
&Prequalification criteria

1

Submission of EMD

2

Supporting
uploaded

Documents

to

be Whether
uploaded
(Yes/No)

1) Signed and Scanned Copy of details
of EMD as per format a given in
Details of EMD at Section 1.1
2) Signed and Scanned Copy of EMD
of the prescribed amount
General Information of the Signed and Scanned Copy of the format
Bidder
as per Section 1.2: General Information
of the Bidder

3

Bidder should be
registered in India

a firm Signed and Scanned Copy
Certificate of Incorporation

4

Must have an average annual
turnover of last three years for
the financial years 2015-16,
2016-17 & 2017-18 not less
than Rs.2 crore

of

Financial performance for last three
years as per Section 1.3: Financial
Information Format of Bidder
Eligibility Criteria

5

Bidder
should
not
be Signed and Scanned copies of
blacklisted / banned by any an undertaking by an authorized
government/semi government signatory of the company in this regard
authority in India for supply of
materials / carrying out
operations and maintenance
work
/
application
development.

6

Bidder should have
Location and Address of the
service/support center for AAS service/support centre.
in India

Page 5 of 53

<!-- page 8 -->

Table-2: Check List of documents as part of Technical Proposal to be uploaded in
Technical Bid (Technical Proposal Documents)
Sl. No.
Technical proposal documents
Whether uploaded (Yes/No)

3

Proposed Technical solution
(As per details in the Section:1.4- Proposed
Technical solution)
Signed and Scanned copy of OEM Certificate and
OEM commitment and authorization form for all
mandatory items as per Section 1.7 & Section 1.11
Compliance statement, Section-1.5

4

Non-compliance statement, Section-1.6

5

Details of Training, Section 1.8

6

BOQ as in the commercial bid with value/price
information masked, Section 1.9

7
8

Tender acceptance letter, Section-1.10
General Questionnaire (Annexure-B), Terms and
condition of the agreement (Annexure-C),
Performance
Bond/Guarantee(Annexure-D1),
MAF(Annexure-E1), (Annexure-G)

1

2

Table-3: Check List of documents to be uploaded in the Commercial Bid (Commercial Proposal)
Sl. No.

Commercial proposal documents

1

Signed and Scanned Copy of Commercial Bid Letter
(as per Section 2.1)

2

Commercial bid as per BOQ.pdf template (pdf
format) from https://etenders.chd.nic.in/nicgep/app
(as per Section 2.2)

Whether uploaded (Yes/No)

Delivery:
The selected bidder has to deliver the supplies within 30 days from the date of issue of purchase
orders/award of contract.

GUARANTEE / WARRANTY:
(a) The warranty period should be three years (with spares) from the date of
installation with satisfactory performance as per specifications.
Page 6 of 53

<!-- page 9 -->

(b) Minimum Five years of optics warranty must be quoted along with system.

BID, GUARANTEE AND SECURITY:
The tenderer is required to furnish Bid Guarantee and Security as per Annexure 'D'.

CONVERSION TO SINGLE CURRENCY:
To facilitate evaluation and comparison, the purchaser will convert all bid prices expressed in
the amount in various currencies in which the bid price is payable, to the Indian Rupees at
the RC selling market rate of exchange established by the State Bank of India, Chandigarh
for similar transactions as on the last date of submission of tenders.

MERGER / ACQUSITION OF FOREIGN PRINCIPAL:
In case of merger of Foreign Principal with another Firm or acquisition of Foreign Principals
by another firm, it shall be obligatory for the New Entity so formed after the merger or the
Acquiring Firm, as the case may be, to take over all the duties and obligations / liabilities of
the Foreign Principals and the New Entity / Acquiring Firm would ipso facto become liable
for all acts of commission or omission on the part of original Foreign Principals.

CHANGE OF INDIAN AGENT:
In case the Foreign Principal changes the Indian Agent then it shall be obligatory for Foreign
Principal to automatically transfer all the duties and obligations to the new Indian Agent,
failing which the Foreign Principal would ipso facto become liable for all acts of commission
or commission on the part of new Indian Agent.

DETAILED INSTRUCTIONS FOR SUBMISSION OF TENDER

1. Only Manufacturers or their Authorized Distributors/Agents are entitled to submit the
Proforma Invoices.

2. The tender shall be prepared and submitted as per Para 20 of the existing instructions.
3. A person signing the tender form or any other document forming part of the contract
on behalf of another shall be deemed to warranty that he has authority to bind such
others and if on enquiry it appears that the person so signing had no authority to do

Page 7 of 53

<!-- page 10 -->

so, the purchaser, may, without prejudice to other civil and criminal remedies against
the contract, hold the signatory liable for all costs and damages and forfeit Earnest
Money.
3.1. All pages of the Technical Bid/Price Bid shall be page numbered.

4. Tenders/Proforma Invoices not accompanied by detailed information as required, are
liable to be rejected.

5. EARNEST MONEY DEPOSIT AND PERFORMANCE BANK GUARANTEE
5.1.

5.2.
5.3.

5.4.

The tender must be accompanied with Earnest Money* of Rs. 35,000/-(Thirty
Five Thousand only) in a lump sum Amount, in the form of Demand Draft
(in favor of Registrar, Panjab University, Chandigarh)Earnest Money in
any other form will not be accepted.
Bids not accompanied by Earnest Money as stated above or less than the
amount stipulated above shall be summarily rejected.
The successful tenderer shall be required to furnish a Contract Performance
Guarantee Bond in the shape of Bank Guarantee (as per Annexure-D) or
FDR/TDR(pledged in favor of Dr. Debabrata Das (Assistant Professor,
Department of Geology, Panjab University, Chandigarh)along with the
undertaking as atAnnexure-D1), for an amount equivalent to 5% of the value
of the Atomic Absorption Spectrophotometer (AAS)towards the execution of
the agreement and the warranty. The Bank Guarantee or FDR/TDR should be
valid for a period 60 days beyond the warranty/guarantee expires. The Bank
Guarantee for 5% of the value shall be submitted immediately but not later
than 7 days after the placement of the Supply order failing which the order will
be liable to be cancelled and the earnest money forfeited.
The Purchaser would return the earnest money mentioned in Para 5 (1) above
to the successful tendering firm on the submission of the Bank Guarantee to
cover the period mentioned in Para 5 (3) above.

6. The Purchaser does not pledge itself to accept the lowest, or any tender, and reserves
to itself the right of acceptance of the whole or any part of the tender, or portion of the
quantity offered, and the tenderers shall be required to supply the same at the rate quoted.
The Purchaser reserves to itself the right to accept or reject any; or all the tenders without
assigning any reason thereof.

Page 8 of 53

<!-- page 11 -->

CUSTOM CLEARANCE:
The equipment requiring import from abroad will be imported/high sea sales under the OGL
(or relevant) scheme, for which tenderer will ensure before shipment takes place, that the
equipment, in question, can be imported under the said scheme.
I.

The equipment will be got cleared from the Custom by the tenderer at their own cost.
Demurrage charges, if any, will be borne by the tenderer.

II.

It will be the responsibility of the tenderer to pursue any claims with the customs
Authorities/Insurance company /cargo operators and transporters, as may arise, at any
stage.

III.

The N.M.I.C. (Not Manufactured in India Certificate), the CDEC (Custom Duty
Exemption Certificate) and all other documents required for custom clearance will be
provided by the Department.

7. INSURANCE
7.1 The manufacturers will ensure that the equipment is properly insured for the full C.I.F
value to cover the transit upto site of installation and the further period of storage etc. up
to end of the period of installation as agreed upon. If the installation is delayed beyond
the agreed date of satisfactory installation, commissioning and handing over of the
equipment, then in that event any transit and storage damages which come to light after
such delays, shall be at the risk and cost of the tenderers. The Tenderers/Indian Agent
shall provide to the Purchaser, after due inspection, a detailed list of any loss or damage
to the stores that may have occurred so as to enable the purchaser to file appropriate
claims with the Insurance company. However, it shall be the responsibility of the
Purchaser to prepare, lodge and pursue any claims that may arise with the Insurance
Company. The manufacturers shall provide all assistance in pursuing any such insurance
claims expeditiously. The manufacturers shall make free replacement, if required, in lieu
of damaged/lost items etc., regardless of the fact whether the claim is settled by the
underwriters or not. The manufacturers' liability shall be restricted to making free
replacements/rectifications and any local expenses such as custom duty/clearance, etc.
connected with such replacements.
7.2. It should be noted that if, in consideration of offer of earlier delivery, the contract is
placed with a higher tenderer in preference to the lowest acceptable offer, and in case of

Page 9 of 53

<!-- page 12 -->

failure to complete supplies in terms of such contract within the date of delivery specified
and incorporated in the contract, the tenderer will be liable to pay to the purchaser the
difference between the contract rate and that of the lowest acceptable tender on the basis
of the final prices FOB destination including all elements of freight, sales tax, local taxes,
duties and other incidentals. This is in addition to and without prejudice to other rights of
the purchaser to recover all other losses and damages resulting from delayed supplies,
cancellation of contract and risk purchases required to be made in case of failure to
supply the stores.

8. GUARANTEE/WARRANTY:
8.1The guarantee/warranty against defects of manufacture / workmanship and poor
quality of components for the entire equipment and the work conducted under the
contract must be for a period of 36 months from the date of satisfactory installation,
commissioning and handing over the equipment at site. Minimum 5 years of optics
warranty must be quoted along with system. The term satisfactory commissioning and
handing over wherever used in terms of tender and Agreement will mean satisfactory and
faultless functioning of the equipment for 30 days, and of works conducted therewith
covered under the contract in working order. During the guarantee/warranty period, the
replacement of any part of the equipment or rectification of defects of works will be free
of cost. Further, the defective parts/equipment shall be returned by the purchaser to the
Indian Agent after making replacement.
8.2. The tenderer will be required to furnish guarantee/warranty as under:
a. The tenderer should submit a written guarantee/warranty from the manufacturers
stating that the equipment being offered is the latest model as per specifications and
that spares for the equipment will be available for a period of at least 10 years after
the guarantee/warranty period. The manufacturer should also warranty/guarantee that
it will keep the Institute informed of any up-date of the equipment over a period of
next 5 years and undertake to provide the same to the Institute at no extra cost.
b. Guarantee/warranty that they will supply regularly any items of spare parts
requisitioned by the purchaser for satisfactory operation of the equipment till the life
span, to be decided mutually of the equipment, if and when required on agreed basis
for an agreed price. The agreed basis could be an agreed discount on the published
catalogue price or an agreed percentage of profit on the landed cost.
c. Guarantee/warranty the effect that before going out of production of spare parts, the
manufacturers and /or tenderers will give adequate advance notice to the purchaser of
Page 10 of 53

<!-- page 13 -->

the equipment so that the latter may undertake to procure the balance of the life time
requirements of spare parts.
d. The guarantee/warranty to the effect that the manufacturers will make available to
the Purchaser. The blue-prints and drawings of the spare parts if and when required in
connection with the equipment.
8.3 The tenderer shall furnish the following warranty/ guarantee in case the contract is
placed on him:a. The tenderer hereby declares that the instrument supplied to the buyer under this
contract shall be of the best quality and workmanship and shall be strictly in
accordance with the specifications and particulars contained/mentioned in the
clauses here of and the tenderer hereby guarantee/ warranty that the said
instrument conform to the description and quality aforesaid. The purchaser will be
entitled to reject the said instrument thereof as may be discovered not to conform
to the said description and quality. Such rejection of instrument will be at the
seller's risks and all the provisions herein contained relating to rejection of goods,
etc. shall apply. The contractor/seller, shall, if called upon to do so, replace within
a period of fourteen days or such further period as may be extended from time to
time by the purchaser at his discretion, on an application made thereof by the
tenderer, the instrument thereof as rejected by the purchaser. In such an event, the
above mentioned warranty/guarantee period of the entire equipment shall be
extended by the time taken for these replacements. Otherwise the tenderer shall
pay to the purchasers such damage as may arise by reason of breach of the
conditions herein contained. Nothing herein contained shall prejudice any other
right of the purchaser in that behalf.
b. Tenderers should state categorically whether they have fully trained technical staff
for installation/commissioning of the equipment and efficient after sales service.
c. Tenderers should categorically confirm that they will give free "After sales
services "during guarantee/ warranty period as stipulated above from the date of
installation, satisfactory commissioning and handing over of the
project/equipment. Warranty for a period less than as stipulated above or with
conditions may render the tender invalid.
d. It is required that the tenderer will supply all the operating and service manuals
along with blue-prints and drawings including circuit diagrams of the equipment
supplied as well as its components.

Page 11 of 53

<!-- page 14 -->

9. MODE OF DESPATCH, DELIVERY AND COMMISSIONING OF
EQUIPMENT:
The equipment, if imported, with all its accessories should be dispatched by Air to Delhi
(INDIA) duly insured, freight and insurance charges pre-paid. The tenderer is required to
undertake to deliver, install, commission and handover the equipment within the
stipulated period. The installation of the equipment shall be completed and handed over
within the time Schedule given in the tender. This stipulated period should be strictly
adhered to for implementation.

10.

SUBMISSION OF PBG/AGREEMENT AND DAMAGES FOR
DELAY IN SUPPLIES/ INSTALLATION:
10.1. The supplier shall ensure submission of duly executed agreement and the desired
Performance Bank Guarantee (PBG) immediately on issue of Supply Order but not
later than 7 days of issuing of supply order, failing which and without prejudice to its
remedy under the contract the Supply Order shall stand cancelled. If Agreement/PBG
is not supplied within the stipulated period, action under Para 5 above will be
applicable and EMD shall be forfeited.
10.2. If the supplier fails to deliver instrument or to perform the services within the time
period(s) specified in the contract, the purchaser shall, without prejudice to its other
remedies under the contract, deduct from the contract price, as liquidated damages, a
sum equivalent to 0.5 percent (0.5%) of the contract price for each week of delay or
part thereof until actual delivery or performance, up to a maximum deduction of ten
percent (10%) of the contract price. Once the maximum is reached, the purchaser may
consider termination of the contract. The acceptance of the equipment will be based
on demonstration of the satisfactory working of all modes of the equipment as tested
by the Purchaser. The Certificate will be issued by the Purchaser for the satisfactory
completion of the supply; installation and commissioning of the equipment in forma
tgiven in Annexure-‘F’. The suppliers will inform the purchaser in writing intimating
the reasons for delay in supplying and for installing the equipment. The purchaser in
his sole discretion may consider a reduction/waiver of the penalty for a period to be
stipulated in writing. The material, etc. required for demonstration of satisfactory
functioning of the equipment shall be arranged by the suppliers.

Page 12 of 53

<!-- page 15 -->

11.

CONTRACT:
The successful bidder will be required to enter into an Agreement (please
see Annexure-‘C’), with the Institute on a non-judicial paper of Rs.30.00 for
the supply and satisfactory installation of the equipment as defined above as
per specifications and terms and conditions listed in the document and
agreed upon.

12.

SUPPLY, INSTALLATION AND COMMISSIONING OF THE
EQUIPMENT:
The supply, installation and commissioning of the equipment shall be as per terms and
conditions given in this document and those given in the Agreement (Annexure-‘C’)to be
signed by the successful tenderer. The scope of work includes the installation and
satisfactory commissioning of the equipment by the firm.

13.

Tenderers are required to quote for C.I.F. up to New Delhi Airport for items to be
imported. CIF Chandigarh including insurance and freight from New Delhi Airport to the
Department of Geology, Panjab University, Chandigarh. For equipment produced in
India, cost including carriage, insurance etc. up to Department of Geology, Panjab
University, Chandigarh should be mentioned.

14.

PACKING AND MARKING:

Best trade packing suitable for safe Rail/Road/Air transit shall be used subject to packing
and marking being acceptable to the Inspecting Authority.

15.

ONLINE U.P. S. SYSTEMS:

15.1 Voltage stabilizers, or Isolation Transformer U.P.S. system, as may be required,
should form part of the equipment although quotations for the same from indigenous
sources shall also be submitted. The voltage range in the Department varies from175- 260
V. Any defect occurring in the equipment because of the defects in voltage stabilizers,
Isolation Transformer or U.P.S. system as the case may shall be attributable to the
suppliers and the cost of repairs and the replacement, if any, shall be borne by the
suppliers during the guarantee/warranty period as well as the service contract period.
15.2 If any part of the equipment goes defective on account of inherent fault in the
machine or in any component of the equipment and needed replacement shall be done by

Page 13 of 53

<!-- page 16 -->

the supplier during the contract period free of cost i.e. to say any defect caused in a part
of the machine on account of non-maintenance of the main machine during the contract
period shall be attributable to the supplier and the cost of replacement thereof shall be
borne by them.
15.3 The equipment supplied must be compatible with power supply system being
followed in India, viz. 240VAC, 50Hz.

16.

LATEST HOUR FOR SUBMISSION OF TENDERS:
Your e-tender must be submitted by 6.00 PM on 28.10.2018 through eProcurement
System
Chandigarh
UT
Administration
https://etenders.chd.nic.in/nicgep/app.

17.

OPENING OF TENDER:

The e-technical bids shall be opened at 15.00 Hrs on 29.10.2018.
You are at liberty to be present, in person or through your authorized representative, at
the opening of the tender at the time and date as specified in the tender notice. The name
and address of the representative who would be attending the opening of the tender on
behalf of tenderer should be indicated in statement to be furnished along with the
technical bids. The representative should carry due authorization from the tenderer. P.I. –
SERB-DST Project (Principal Investigator), Department of Geology, Chandigarh in its
discretion may not allow any representative, who does not earn authorization for being
present in bid opening. In the event of the day of receipt and opening of tender being a
holiday for the University, then due date of receipt/opening of the tender will be the
following working day at the same hour.

18.

PERIOD FOR WHICH THE OFFER WILL REMAIN OPEN:

The tendering firms should keep their offers valid for acceptance for a period of 90 days
from the date of opening of the technical bids. If the firms are unable to keep their offers
open for the above said period, they should specifically state the period for which their
offers would remain open but they must realize that such a provision may result in the
rejection of their offers, provided, however, that in the event that the day up to which the
offer is to remain the offer shall remain open for the following day.

Page 14 of 53

<!-- page 17 -->

19.

PAYMENT TERMS:

Given in the attached Annexure-C.

20.1 Contents of Bid:
The prospective bidders are required to submit their bids online through eTendering
system of Chandigarh Administration (http://etenders.chd.nic.in). Hard copies of the
same in two separate envelopes as under :Pre-Qualification:
Scanned copy of earnest money deposit. The EMD in original shall reach to Dr. Debabrata
Das, Principal Investigation, SERB Project, Department of Geology, Panjab University,
Chandigarh-160014 on or before the last date of bid submission along with following
documents as mentioned in the eligibility criteria.
1) Certificate of Incorporation/Registration/memorandum of Association/Partnership
Deed.
2) Copy of audited balance sheets along with profit & loss statements showing average
annual turnover of Rs.2 crores for the last three financial years 2015-16, 2016-17&201718 showing net positive worth of the Company with highlighted relevant figures(in case
the audited financial statements do not reflect the above, original statutory Auditors
certificate on the actual relevant figures)
3) Copy of PAN Card/valid Service Tax Registration Certificate in name of the Company
4) A declaration as per Annexure-H for non blacklisting on company’s letter head duly
signed by authorized signatory i.e Notary/Judicial Magistrate).
Note:
1. The bidders have to produce the original documents as & when asked for by the
purchaser. The failure of the bidder to furnish the said original documents will entail
summarily rejection of its bid.
2. The purchaser will not be responsible for any delay in online submission of the bids
due to any reason whatsoever.
3. Corrigendum/Addendum to this bid, if any, will be uploaded on the website

Page 15 of 53

<!-- page 18 -->

http://etenders.chd.nic.in. No separate communication will be sent to any bidder.
This may be noted by the bidder on its own.
4. The purchaser reserves the right to verify the particulars furnished by the bidder
Independently. If any information furnished by the bidder is found incorrect at a
Later stge. The bidder shall liable to be debarred for future bidding in Panjab
University for a period of 2 years.
5. For any technical issues related to electronic tendering portal, Bidders may contact
eProcurement cell, Department of Information Technology,5th floor, Additional
Deluxe Building, Sector-9/D,Chandigarh or email at etender-chd@nic.in. Phone
No.0172-2740641,0172-2740005 .

20.2 Evaluation Process:
1. Eligibility criteria and technical bids of only those bidders will be evaluated, whose valid
EMD instruments are found to be in order. Bid received without EMD will be summarily
rejected.
2. Samples must bearing complete description of the tendered items. Samples be submitted
by hand on or before specified date & time, if it seems that samples are bulky in nature. The
list of submitted samples must be attached along with the technical bid.
3. A duly constituted Evaluation Committee (EC) will first select bidders on the basis of
eligibility criteria defined for this tender. The bids conforming to the eligibility criterion only
will be considered for further evaluation. If there is any lack of clarity in the submitted
eligibility documents. EC may ask concerned bidder to prove their eligibility.
4. The EC shall evaluate the responses to the tender and all
documents/documentary evidence.
Inability
to
submit
requisite
documents/documentary evidence my lead to rejection.

supporting
supporting

5. The EC may ask for meetings with the Bidders any time during the evaluation process to
seek clarifications on their bids.
6. The EC reserves the right to reject any or all bids on the basis of any deviations. The
decision of the EC in the evaluation of responses to the tender shall be final.
7. Conditional bids would be liable for rejection.

Page 16 of 53

<!-- page 19 -->

8. Upon verification evaluation/assessment, if in case of any information furnished by the
bidder is found to be false/ incorrect, their bid shall be summarily rejected and no further
correspondence on the same shall be entertained.
9. No enquiry shall be made by the bidder(s) during the course of evaluation of the tender,
after opening of bid, till final decision is conveyed to the successful bidder(s).
10. The EC will shortlist the Technical bids on the basis of the minimum eligibility criteria.
The samples of only those short listed bidders will be considered and further checked and
selected by the EC.

20.3 Financial Evaluation:
The financial bids of only technically qualified bidders will be opened on the
prescribed date.
i. Financial bid in total value considered on L1 (lowest rate among all participants) basis item
wise of only those bidders who have qualified technically.
ii. Quoting incredibly low value of items with a view to subverting the tender process shall be
rejected straightway and EMD of such vendors will be forfeited.

20.4 Instructions to Bidders:
a.

Submission of Bids:
Online bids shall be received by the purchaser before the time and date specified in the
schedule of the bid notice. The purchaser may, at its discretion, extend this deadline for
submission of offers by issuing corrigendum.

b. Method of Submission of Bids:
The two bids system shall be followed. Pre-qualification, Technical and commercial

offers shall be submitted online in three separate envelopes one Procurement
system(http://etenders.chd.nic.in). The bidders shall submit their bids online in electronic
format only and with digital signatures for participation in the e-tendering process. The

Page 17 of 53

<!-- page 20 -->

bidders need to register themselves on the website http//etenders.chd.nic.in. For
clarification and necessary information on he process to obtain digital signatures, the
bidders are required to visitwww.cca.gov.in and http://etenders.chd.nic.in.Bids without
digital signatures will not be accepted by the electronic tendering system. Before
submission of online bids, bidders must ensure that scanned copies of all the necessary
documents including the scanned copy of EMD have been uploaded with the bid within
the time limit as specified in the bid document. The documents to be submitted by the
bidders, as specified in the bid document, could be scanned in low resolution (~100 DPI)
AND IN GREYSTYLE. The PDF so prepared by the bidders could be shrinked in size
and then uploaded by the bidders.BOQ must be uploaded in PDF format.

Late offers:
Late submission will not be entertained and will not be permitted by the e Procurement
system after due date & time.
c. Cost of Bidding & currency:

The price will remain fixed for the period of the work completion and no changes for any
reason what so ever will be allowed. The bidder shall bear all costs associated with the
preparation and submission of its bid.
d. Erasures or Alternations and Signing of Tenders Offers:

The bid shall be signed by the bidder or a person or persons duly authorized. The person
signing the bid shall initial all pages of the offer, except for un-amended printed
literature.
The bid should contain no interlineations, erasures or overwriting except as necessary to
correct errors made by the bidder, in that case such corrections shall be initialed by the
person signing the offer.
e. Fixed Price:

The commercial offer shall be on a fixed price basis. All the applicable taxes and levies
(all direct and indirect taxes including local duties, levies etc.) shall be clearly specified
by the Bidder in the financial bid perform.

Page 18 of 53

<!-- page 21 -->

f. Offer Validity Period:

The offer must be valid for minimum 90days from the date of submission of bids.
g. Clarifications of Offers:

To assist in the scrutiny, evaluation and comparison of offers, the purchaser may, at its
discretion, ask some or all the bidders for clarifications of their offers on any of the points
mentioned therein and the same may be sent through email, facsimile. Etc. However, in
such cases, original copy of the technical clarifications shall be sent to the Purchaser
through courier or in person.
h. Amendment of the Document:

i)

At any time prior to the deadline for submission of bids, the purchaser may, for
any reason, whether on its own initiative or in response to the request for
clarification by the prospective bidder, modify the RFP document.

ii)

Any amendments would be intimated to all the prospective bidders by issuing
corrigendum.

iii)

In order to allow prospective bidders reasonable time to take into the
consideration the amendments while preparing the bids, the purchaser at its
discretion may extend the deadline for the submission of bids.

i.

Language of Bid:
The bid, as well as all correspondence and documents relating to the offer exchanged by
the bidder and the purchaser, shall be in English language only. Supporting documents
and printed literature furnished by the bidder may be in another language provided they
are accompanied by an appropriate translation in English language and in such a case, for
purpose of interpretation of the bid, the translation shall govern.

j.

General Conditions:

1. This document and other Annexures comprising the Tender documents viz. Annexure
‘A’(Detailed technical specifications), Annexure ‘B’ (General Questionnaire), Annexure‘C’(Agreement containing terms and conditions), Annexure ‘D’ (format of Bank
Guarantee), Annexure D1 (Undertaking in case of Bank Guarantee is being submitted in
form of FDR/TDR), Annexure ‘E’ (authorization letter), and Annexure ‘F’ (certificate of

Page 19 of 53

<!-- page 22 -->

successful completion of equipment), Annexure ‘G’ (Proforma for Performance
Statement) should be returned intact along with the Technical bid. Each page of this
tender document and Annexures 'A to H’, duly signed by the tenderer, should be returned
intact along with the Technical bid.
2. Bidders must be single entity only. Consortium shall not be allowed in any case.
3. Bidders are required to fully understand the work and ascertain the requirements before
submitting the bid.
4. The award of the work will be communicated in writing at the address provided by the
organization. Any change of the address of the organization should therefore, be
promptly notified in writing to the Purchaser.
5. The scope of work shall include supply, delivery at site, unloading any other services
associated with the delivery of the equipment and materials.
6. Failure on the contract’s part to comply with any of the conditions above may result in
forfeiture of EMD/ balance payment to vendor and shall result in termination of the
contract.
7. Payment shall be made as per the actual quantity executed and quantities mentioned in
the RFP can be increased or decreased at the sole discretion of the purchaser.
8. Nothing extra shall be paid against the price quoted due to escalation of prices/ cost or
loss or damages caused by rain, flood war epidemic, strike or any other natural calamity.
9. Any dispute in connection with this contract shall be subject to the territorial jurisdiction
of the Local Courts at Chandigarh.
10. The quantity shown in the schedule are tentative and can be increased or decreased to any
extent during the contract period with the prior approval of the worthy Vice-Chancellor.

Force Majeure: A party shall not be liable for any failure of or delay in the performance of this
agreement for the period that such failure or delay is due to causes beyond its reasonable control
including but not limited to the acts of God, strike or labor disputes, embargoes, Government
orders or any other force Majeure event.

Page 20 of 53

<!-- page 23 -->

Annexure-A
Detailed Technical Specifications for Atomic Absorption
Spectrophotometer (AAS) with Accessories
AAS system must be fully computer controlled along with all
additional/required accessories.
1. Fully Automated Personal Computer controlled Integrated Atomic Absorption
Spectrometer System with Double Beam optics. Automatic Changeover
between–FLAME MODE, absorption and emission capability along with
Deuterium background correction.
2. Optics: Double beam optical design. Automatic Wavelength and Slit Selection
with automatic peaking.
3. Optical True Double-Beam system with Facility of future upgradability for
AUTOMATED changeover from Flame to Graphite Furnace (GF) to avoid any
mechanical movement of the set up while changing from flame to furnace mode
(Including Auto-sampler of GF).
4. Wavelength range: 185 to 900nm.
5. Variable band width with automatic wavelength adjustment (variable slit width 0.2
to 1.2nm)
6. Monochromator: Echelle monochromator and prism or Grating with 1800
lines/mm blazed at focal length of minimum above 250 mm and the Reciprocal
Linear Dispersion of 1.6 nm/mm or better.
7. Control via external PC and software.
8. Atomizer System:
a. The system must have software controlled automatic vertical and
horizontal alignment of the flame burner head for optimum light
transmission.
b. System must come with Standard 10 cm titanium burner head for Air –
Acetylene flame for better absorbance. For elements that need N2O –
Acetylene flame, 5 cm burner head must also be quoted.
c. System must have software controlled flame ignition.
d. A suitable air compressor must be offered with the system.
9. Lamps:
a. The system must have a minimum 8 lamps holder with a provision of
computer controlled automatic lamp selection, slit width selection,

Page 21 of 53

<!-- page 24 -->

wavelength selection. System must have independent power supply
for each lamp.
b. Branded Coded lamps with minimum life of 8000 mAH or one year
warranty must be offered.
c. Built-in power supplies for both the Coded Hollow Cathode Lamps and
eighteen single elements lamp must be quoted. The list of eighteen (18)
elements will be given at the time of delivery of instrument.
10. Detector:
a. Wide range Photomultiplier Tubes (PMT) or Solid State with highest
quantum efficiency.
b. Wavelength range: 185 – 900 nm or better
c. Operator selectable Read time from 0.1 to 120 seconds.
11. Flame System:
a. Burner: Universal Titanium finned burner with corrosion free Titanium
material or separate burner for Acetylene and Nitrous Oxide flame and
fully inert spray chamber. Burner height automatically adjustable and
automatic gas controlled for optimization. The changeover must be
automatic between Air/Acetylene & Acetylene/Nitrous Oxide.
b. The Nebulizer must be resistant to all types of Acids, Solvents.
12. Background Correction Methodology:
a. Deuterium Lamp Background Correction.
13. Gas Flows system:
a. Software controlled flame ignition and automatic changeover of oxidant
flow from acetylene to nitrous oxide when switching to or from airacetylene to nitrous oxide - acetylene flame.
b. Fully software controlled oxidant and fuel gas flow monitoring.
14. Sensitivity: Vendor must provide report of the quoted system demonstrating
>0.9 absorbance with the precision of <0.5% RSD from 5 second integrations for
5 ppm Cu standard.
15. The atomic absorption spectrometer system must be able to be incorporated
with the accessories like:
a. Vapor/hydride analysis for flame to gain an extra mileage of accessing
ppb and ppt levels respectively.
16. All safety interlocks built-in and additional feature like Burner Head Interlock,
Nebulizer/End Cap Interlock and Drain Interlock to be built-in.
17. Optical System:

Page 22 of 53

<!-- page 25 -->

a. A real time true double beam spectrometer system with high light
throughput.
b. A focal length of minimum above 250 mm and the Reciprocal Linear
Dispersion of 1.6 nm/mm.
c. System must have the maximum light transmission for the best detection
limits with least maintenance.
d. System should automatically adjusts to changes in lamp intensity for
stable baselines and compensates for drift multiple times per second.
e. System must have fast start-up and exceptional long-term stability without
recalibration.
18. Accessories must be included:
a. Vapor Generation/ Hydride Assembly must be quoted for the analysis of
elements like As, Hg, Se etc.
b. Desktop Computer- A branded computer- Minimum Configuration-Intel
DUAL CORE 3.0 GHZ, 4GB RAM, 500GB HDD, 1 PCI SLOT, USB Ports,
Keyboard, Optical Mouse, With minimum 19” Wide TFT Monitor with
WINDOWS software.
ii. Licensed Software for Data acquisition & Data Processing of AAS
system with Backup Copy in C. D., with provision of future up-gradation.
c. Printer-HP/Canon/brothers/Xerox Color Ink Jet Printer.
d. Software feature –
i.
Software package with extensive functions for controlling the
device.
ii.
Monitors and regulates all important system parameters - plug and
start technology.
iii.
Intuitive user guidance including cookbook library for numerous
standard applications.
e. Branded Air Compressor: Oil Free, Noiseless Air Compressor, with Air
Purifiers and moisture trap compatible with quoted A. A. S. Unit.
f. Acetylene, Nitrous Oxide and Argon Filled Cylinders for AAS analysis
(UHP Grade) with necessary Tubings & Connectors.
g. Double Stage Gas Regulators for Acetylene Gas, Argon Gas, Nitrous
Oxide (with heater) Cylinders.
h. Stainless Steel Hood with Exhaust Fan including necessary fitting and
Ducting Facility.
i. Gas Distribution Line for Nitrous Oxide, Acetylene and Argon with
filter/purifier
j. Branded online 5 KVA UPS with isolation transformer for minimum 30
minutes back up.
k. Certified Standard solution for AAS (1000 PPM) for all elements as
mentioned against Hollow Cathode Lamps (each bottle of 200 ml).

Page 23 of 53

<!-- page 26 -->

l. One Window Air Conditioner-One and Half (1.5) Ton- Minimum 3 star
must be quoted along with system.

19. Additional requirement:
a. 3 years on-site warranty from date of installation.
b. Optics warranty: Minimum 5 years of optics warranty must be quoted
along with system.
c. System must have option to upgrade with graphite furnace and must
have Zeeman background correction with option to have 21 CFR
audit trail feature with software up gradation. Conform to all relevant
standards(ASTM, ISO etc.).
d. Training: 5 days extensive training for 3or more persons at installation site
or other reputed institute.
e. Site preparation including gas line: by bidders.
f. Compliance certificate should be provided.
g. The offer needs to be accompanied with all required supporting
technical literatures, ISO Certificate of the manufacturing works, at
least details of four users in North India with contact nos, email id
other than performance certificates from the users, Authorization
certificate of the Principal Companies, details of service facilities
available with the contact numbers of the service persons
responsible for the product in North India along with their experience
on the servicing of the instrument (AAS).
h. Ensure the break up prices of all components

Page 24 of 53

<!-- page 27 -->

ANNEXURE-B
(To be returned, fully complete, with the Technical
Bid) GENERAL QUESTIONNAIRE
i. This Annexure must accompany the Technical Bid.
ii. The tenderers must give specific answers against each of the following questions.
iii. Equivocal or evasive replies will render the tender liable to be ignored.
QUESTIONS:
1) Name and address of manufacturer:
2) Station/Place of manufacturer:
3) Whether the tendering firm is/are:
a. Manufacturer
b. Manufacturer’s authorized agents
c. Holders of stock of the stores tendered for
4) If stores offered are manufactured in India, please state whether all the raw materials,
components etc. used in their manufacture are also produced in India. If not, give details of
materials, components etc. that are imported and their break-up of the indigenous and imported
components together with their value and proportion it bears to the total value of the stores.
5) State whether raw materials are held in stock in India sufficient for the manufacture in the
stores.
6) Please state specifically whether the price tendered by you is to the best of your knowledge
and belief, not more than the price permissible for you to charge a private purchaser for the same
class and description of goods under the provisions of any law for the time being in force and not
more than the prices you would charge from other Govt. Depts. /Institutions in India. If not, state
the reasons as well as the margin of profit included.
7) Please indicate the following:a. The precise relationship between the Foreign Manufacturers/Principals and their Indian
Agents/Associates.
b. The mutual interest which the Manufacturer/Principals and their Indian Agents/Associates
have in the business of each other.
8) Business name and construction of tendering firm is the firm registered under:
a. The Indian Companies Act, 1956.
b. The Indian Partnership Act, 1932 (please give the name of partner).

Page 25 of 53

<!-- page 28 -->

c. Any other act.
d. If the firm is not registered please give the name(s) and address of the owner(s)
9) a) Do you agree to various clauses of Para of the Agreement (Annexure ‘C’) regarding
arbitration.
b) i. In case of partnership firms, whether registered under Indian partnership Act, 1932.
ii. In case the answer to question at 9(a) by the partnership firms be in the affirmative please state
further:iii. Whether in the partnership Agreement, authority to refer disputes concerning the business of
the partnership to arbitration has been conferred on the partner who has signed the tender.
iv. If the answer(s) to question 9(b) (iii) is in the negative, whether there is any general power of
attorney executed by all the partners of the firm authorizing the partner who has signed the
tender to refer disputes concerning business of the partnership to arbitration.
c. If the answers to either 9(b) (iii) or 9(b) (iv) is in the affirmative, please, furnish a copy of
either the partnership Agreement or the general power of attorney, as the case may be.
NOTE: Please attach to the technical bid a copy of the Partnership Agreement or the General
Power of Attorney on either of which reliance is placed for authority of partner or the partner
signing the tender to refer disputes to arbitration. The copy should be attested by a NOTARY
PUBLIC or its execution should be admitted by an affidavit drawn on properly stamped paper by
all the partners.
10) Indicate clearly the guaranteed delivery/commissioning and handing over period.
11) Please state clearly the period for which your offer will be valid for acceptance beyond the
date of opening of the Technical Bids (please see note below):
IMPORTANT NOTE: Tendering firms are requested to keep their offers valid for acceptance
for a period of 90 days from the date of opening of the Technical Bids. If the firm is unable to
keep its offer open for the specified period of 90 days, then they should specifically state the
period for which their offers would remain open but they must realize that such a provision may
result in the rejection of their offers.
12) Please furnish the following details:
1. Indian Agent (If any)
2. Income Tax Return
3. Permanent Account Number:

Page 26 of 53

<!-- page 29 -->

ANNEXURE-C
(To be returned with the Technical Bid)
Terms and Conditions of the Agreement, to be executed by successful Tenderer.

1. This Agreement regarding the supply and maintenance of Atomic Absorption
Spectrophotometer
(AAS)
made
this
day
…………………………………………………. by and between Dr. Debabrata Das
(Assistant Professor, Department of Geology, Panjab University, Chandigarh)
(hereinafter
referred
to
as
the
First
Party)
and
M/s_________________________________________________________________
____and
their
agents_______________________________________________________
(Hereinafter referred to as the Second /Third Party respectively) which expression
shall unless specifically excluded by or repugnant to the context include their Heirs,
Executors. Administrator, Legal representatives and Assignees. The second partymay nominate their agent if they so desire and inform the First Party in writing about
such appointment. It is further stipulated that notwithstanding anything else in this
Agreement, the Second Party shall inform the First party in writing about the change
of such agency. Further, the new agency shall remain bound by the present
Agreement irrespective of any arrangement written or otherwise between the Second
Party and its agents to which agreed that this Agreement will be binding on all parties
collectively and separately.
2. THE AGREEMENT:
2.1. This Agreement concerns the supply installation and commissioning of Atomic
Absorption Spectrometer (AAS) on turnkey basis to be supplied by the Second Party /
Third Party according to Supply Order No.___________Dated_________ and their
Proforma Invoice No _____________________________dated______________ a
copy of which his appended (Annexure___). Further, the equipment is to be installed
by the Second Party / Third Party at the designated premises of the first party
according to the schedule agreed upon as stated below.
2.2. The Second Party / Third Party agree to supply, install and commission the entire
equipment within the period of 50 days in case of imported items and 30 days in other
cases after placing the supply order.
2.3. MODE OF DISPATCH
The equipment if imported, with all its accessories should be dispatched by air to
Delhi (India) duly insured up to Chandigarh, freight and insurance charges prepaid.

Page 27 of 53

<!-- page 30 -->

2.4. The Second / Third Party shall ensure submission of performance Bank
Guarantee and duly executed Agreement immediately but not later than seven days
after issue of Supply Order failing which and without prejudice to its remedy under
the contract, the Supply Order shall stand cancelled, except when specific extension is
granted by the head of the department. If the PBG and Agreement is not supplied, as
called for within the stipulated period, the Supply Order shall be liable to be cancelled
and EMD forfeited.
a. Further, the equipment will be supplied, installed, commissioned and handed over
to the First Party in complete working order within a total period as specified above.
If the supplier fails to deliver any or all of the goods or perform the services within
the time period(s) specified in the contract, the purchaser shall, without prejudice to
its.
Other remedies under the contract, deduct from the contract price, as liquidated
damages, a sum equivalent to 0.5 % of the contract price for each week of delay or
part thereof until actual delivery or performance, up to a maximum deduction
of10%(ten percent) of the contract price. Once the maximum is reached, the purchaser
may consider termination of the contract by which the supplies or their satisfactory
installation, commissioning and handing over is delayed. The Second Party / Thirdparty will inform the First Party in writing, intimating the reasons for delay in
supplying, commissioning and handing over of the equipment in satisfactory working
order. The First Party at its sole discretion may consider a reduction or waiving of the
penalty for a period to be stipulated in writing.
2.5. The system operational efficiency and concepts would be fully demonstrated
after job completion by the Second/Third Party for which nothing extra shall be
payable by the Institute. The materials etc. required for demonstration of satisfactory
functioning of the equipment shall be arranged by the Second /Third-party.
2.6. Thorough inspection of the equipment system will be carried out by the First
Party only on completion of the entire job of installation and commissioning of the
equipment. The acceptance of the equipment will be based on demonstration of the
satisfactory working of all modes of the equipment as tested by the Inspecting
Authority.
2.7. This Agreement comes into effect from the date of issue of supply order in favor
of Second/Third Party. The Agreement will remain valid for a period till the rights
and liabilities of the parties are finally disposed of.

Page 28 of 53

<!-- page 31 -->

2.8. On expiry of the initial period of 1 year, this Agreement may be renewed for a
further period by mutual Agreement between the parties in writing. However, not
withstanding anything else stated here, the Second Party undertakes to continue to
provide service and required spare parts at an agreed price for the entire life of the
equipment. Further, the Second Party undertakes to provide all the circuit diagrams of
the entire equipment, including all its accessories, in the event the particular model is
phased out of production. It further agrees to provide and sell to the First Party all
spare parts that maybe needed for the remaining life of the equipment.
3. PRICES:
3.1. Prices of the equipment(s) is/are ________________________________ with the
break-up for freight & insurance, agency commission, installation charges payable at
actual as below
4. PAYMENT TERMS:
4.1. For imported items, FOB value may be paid through irrevocable Letter of Credit
established in favor of the foreign supplier through State Bank of India, Panjab
University, Chandigarh on a bank in the supplier’s country, on submission to the bank
of the documents specified in the Letter of Credit and further following documents
a. Foreign supplier's certificate that the amounts shown in the invoice are correct in
terms of the contract and that all the terms and conditions of the contract have been
complied with.
b. Foreign supplier's certificate confirming that the original documents have been
Dispatched to the port consignee in accordance with the contract, and
c. Any other document specified in the notification of award or the contract.
Or
The payment shall be released on the basis of certificate by the respective user
department of successful installation of the equipment.
4.2. The Indian Agency Commission of Rs._________________________________
will be paid to the Third Party and has been included in the total value of the
equipment.
4.3. The Purchaser shall make all reasonable and due efforts to pay the Indian Agency
Commission to the Third Party at the earliest possible after satisfactory
installation/commissioning and handing over of the system in good working condition
and meeting any other requirements for payment of the Agency Commission. The rate
of exchange applicable for covering Agency commission into equivalent Indian

Page 29 of 53

<!-- page 32 -->

Rupee shall be the TT selling rate prevalent on the date of releasing the documents at
the time of shipment by the bankers. The Indian Agency Commission will be paid in
Indian Currency (Rupees) to the Third Party.
4.4. The equipment will be installed by the Second Party or the Third Party; at the
designated premises of the First Party.
4.5. The octroi exemption certificate, if required, shall be provided by the First Party.
4.6. It is agreed that increase in price on account of any statutory increase or fresh
imposition of customs duty, sales tax or on account of any other tax or duty leviable
in respect of the stores specified in the accepted tender which takes place after the
date of delivery installation, commissioning and handing over period stipulated in the
contract, shall not be admissible on such of the said stores as are delivered after the
stipulated date of delivery and completion. This is subject to Force Majeure clause.
4.7. It is agreed that notwithstanding anything stipulated in the contract for increase in
price on any other grounds, such increase which takes place after the date of the
delivery and completion stipulated in the contract shall not be admissible on such of
the said stores as are delivered alter the expiry of the delivery and completion period
stipulated in the contract.
4.8. But, nevertheless, the Institute shall be entitled to the benefit of any decrease in
price on account of reduction in or remission of custom duty, excise duty or sales tax
or any other tax or duty or on accounts of any other grounds, which takes place before
the date of actual delivery of the goods.
5. IMPORT FORMALITIES AND CUSTOMS CLEARANCE:
5.1. The equipment requiring import from abroad will be imported/High sea sales
under the OGL scheme, for which Second Party / Third Party will ensure, before
shipment takes place, that the equipment in question can be imported under the said
scheme.
5.2 It will be the responsibility of the Third Party to get the customs clearance of the
equipment duty free where this dispensation is available. It will also be the
responsibility of the Third Party to pursue any claims with the customs
authorities/insurance company, cargo operators and transporters as may arise at any
stage.

Page 30 of 53

<!-- page 33 -->

5.3 The N.M.I.C. (Not Manufactured in India Certificate) and the C.D.E.C. (Custom
Duty Exemption Certificate) will be provided by the First Party. However, the Second
Party/Third Party will affect the shipment only after seeking confirmation regarding
availability of the above from the First Party. Delays on this account will not count
towards any penalty clauses in this Agreement.
5.4 The First Party shall indicate in the Supply Order whether any custom duty/excise
duty exemption is available. The First Party shall make available such custom/ excise
duty exemption certificate. However, it shall be the responsibility of the Second/
Third Party, before dispatching the consignment to ensure that such exemption
certificates have become available with the First Party. Failure on this part of Second/
Third party; will render them liable to pay all demurrage charges which become
payable.
6. INSURANCE
6.1 Second Party will ensure that the equipment is properly insured for the full C. I. F.
value to cover the transit up to site of installation (At user's premises) and to cover the
further storage period etc. up to and of the period of satisfactory installation as agreed
upon. If the installation is delayed beyond the agreed date of satisfactory installation,
commissioning and handing over of the unit then in that event any transit and storage
damages which come to light after such delays shall be at the risks and cost of the
Second/Third Party. The Second Party/Third Party will provide to the First Party,
after due inspection, a detailed list of any loss or damage that may have occurred so
as to enable the First Party to file the appropriate claims that may arise with the
insurance company(ies). The second/Third Party undertakes to provide all assistance
in pursuing any such insurance claims expeditiously. In lieu of damaged/lost items
etc. regardless of the fact whether the claim is settled by the underwriters or not, the
Second Party's liability is restricted to making free replacement/rectifications and any
local expenses such as Customs Duty Clearance etc. connected with such
replacements shall be borne by the First Party.
7. It should be noted that if, in consideration of offer of earlier delivery, the contract is
placed with a higher tenderer in preference to the lowest acceptable offer, the tenderer
will be liable to pay to the Institute the difference between the contract rate and that of
the lowest acceptable tender on the basis of the final price for destination, including
all elements of freight, sales tax. Local taxes, duties and other incidentals, in case of
failure to complete supplies in terms of such contract within the date of delivery

Page 31 of 53

<!-- page 34 -->

specified and incorporated in the contract. This is in addition to and without prejudice
to other rights of the Institute to recover all other losses and damages resulting from
delayed supplies and of cancellation and risk purchase in case of failure to supply the
stores.
8. GUARANTEE/WARRANTY
8.1. Guarantee/warranty of instrument shall be for a period of 36 months and
minimum 5 years optics warranty.
8.2. The foreign suppliers and the tenderer should guarantee the entire equipment
against defects of manufacture, workmanship and poor quality of components.
8.3. The guarantee/warranty against defects of manufactures workmanship and poor
quality of components; shall be for the entire equipment and work conducted under
the contract. During the guarantee period the replacement of any part(s) of the
equipment or rectification of defect of works shall be free of cost.
8.4. The Second Party/Third Party guarantee that the equipment being offered is the
latest model and that spares for the equipment will be available for a period of at least
10years (life span).The Second Party/Third Party also guarantee that they will keep
the Institute informed of any up-date of the equipment over a period of next 5 years
and undertake to provide the same to the Institute at no extra cost.
8.5.The Second/Third Party guarantee/warranty that they will supply regularly any
items of spare parts requisitioned by the purchaser for satisfactory operation of the
equipment till the life span (to be mutually decided) of the equipment if and when
required on agreed basis for an agreed price. The agreed basis could be an agreed
discount on the published catalogue price or an agreed percentage of profit on the
landed cost.
8.6.The Second/Third Party guarantee that before going out of production of spare
parts, the Second Party/Third Party will give adequate advance notice of at least six
months to the First Party so that the First Party may undertake to procure the balance
of the lifetime requirements of spare parts.
8.7. The Second/Third Party guarantee that they will make available to the First Party
the blueprints and drawings of the spare parts as and when required in connection
with the equipment. The Second/Third Party guarantee that the goods/articles
supplied to the First Party under this contract shall be of the best quality and

Page 32 of 53

<!-- page 35 -->

workmanship and shall be strictly in accordance with the specifications and
particulars contained/ mentioned in the clauses here of and the Second/Third-party
hereby guarantee that the said goods/stores/articles on form to the description and
quality aforesaid. The First Party will be entitled to reject the said
goods/stores/articles or such portion thereof as may be discovered not to conform to
the said description and quality. On such rejection, the goods/ stores/articles will be at
the seller's risk and all the provisions herein contained relating to rejection of goods
etc. shall apply. The Second Party / Third Party shall, if called upon to do so, replace
within a period of fourteen days or such further period as may be extended from time
to time by the First Party at his discretion, on an application made thereof by the
Second Party/Third Party, the goods/stores/articles or such portion thereof as rejected
by the first Party. In such an event, the above mentioned warranty /guarantee period
of the entire equipment shall be extended by the time taken for these replacements.
Otherwise, the second/Third Party shall pay to the First Party such demurrages as may
arise by reason of breach of the conditions herein contained. Nothing herein contained
shall prejudice any other right of the First Party in that behalf.
8.8. The Second Party / Third Party will submit a Performance Bond / Bank
Guarantee (PBG)for 5% of the value of the equipment amounting to Rs.
___________ towards the execution of the Agreement and the warranty valid till the
expiry of the warranty period of 36 months, or extended period of warranty of months
as the case may be. The PBG should however be valid for at least 60 days beyond
expiry of Guarantee/Warranty period. After receipt of said bank guarantee, the First
Party will return the EMD already submitted by the Second Party / Third Party as
earnest money. On expiry of the warranty period, the PBG will be returned by the
First Party to the Second Party / Third Party.
9. INSTALLATION AND SATISFACTORY COMMISSIONING OF THE
EQUIPMENT:
9.1. The scope of work includes the satisfactory installation and satisfactory
commissioning of the equipment by the Second / Third Party. The term satisfactory
installation and commissioning and handing over wherever used in this
contract/Agreement will mean satisfactory and faultless functioning of the equipment
for 30 days and of works conducted there under covered under the contract in
working order. The Second Party/ Third Party shall in consultation with the first
Party, furnish at no extra cost to the First Party within 15 days of the Supply Order,
the full details of all works required to be carried out by the Institute in connection
with the completion of the work within the stipulated period.

Page 33 of 53

<!-- page 36 -->

9.2. In case the equipment is not installed and/or put in working condition to the full
satisfaction of First Party within the period stipulated in the Agreement or within such
time as may be extended in writing by the First Party, or the equipment does not
function properly during the period of one year from the date of its installation the
First Party shall be entitled to return the equipment and seek the refund of the amount
paid and the interest accrued thereon/demurrages borne by it from the Second/Third
Party jointly and severally.

10. SPARES
10.1. SPARES PARTS DURING GUARANTEE/WARRANTY PERIOD:
All spare parts required during the guarantee/warranty period of the equipment as
defined in Clause 8 for the satisfactory maintenance, running and upkeep of the
equipment shall be provided by the Second/Third Party at its cost, expenses and care.
All such defective parts/components replaced by the Second/Third Party during the
guarantee period shall be the property of the Second/Third Party.
11. FORCE MAJEURE:
Any failure of omission or commission to carry out the provisions of this contract by
the supplier shall not give rise to any claim by any party, one against the other, if such
failure of omission or commission arises from an act of God, which shall include all
acts of natural calamities such as fire, flood, earthquake, hurricane, or any pestilence
or from civil strikes, compliance with any statute and/or regulations of the
Government, lockouts and strikes, riots, embargoes or from any political or other
reasons beyond the supplier's control including war (whether declared or not), Civil
War or state of insurrection, provided that notice of the occurrence of any event by
either party to the other shall be given within two weeks from the date of occurrence
of such an event which could be attributed to Force Majeure conditions.
12. ARBITRATION:
12.1. If at any time, any question, dispute or difference whatever shall arise between
the two parties upon or in relation to or in connection with this Agreement, either of
the parties may give notice to the other in writing of the existence of such a question,
dispute or difference and the same shall be referred to two Arbitrators, one to be
nominated by the First Party and the other to be nominated by the Second Party/Third
Party. Such notice of the existence of any question, dispute or difference in
connection with the Agreement shall be served by either party within one year of the

Page 34 of 53

<!-- page 37 -->

beginning of such dispute failing which all rights and claims under this Agreement
shall he deemed to have been forfeited and absolutely barred. Before proceeding with
the reference, the Arbitrators shall appoint/nominate an Umpire. In the event of the
Arbitrators not agreeing in their award, the Umpire appointed by them shall enter
upon the reference and his award shall be binding on the parties. The venue of the
arbitration shall be at Chandigarh (India). The Arbitrators/Umpire shall give a
reasoned award.
12.2. The provisions of the Indian Arbitration Act in force and of rules framed there
under and any statutory modifications thereof shall be deemed to apply and be
incorporated in this Agreement.16.3. Upon even or any such reference, the cost of any
incidentals to the reference and award(s) respectively shall be at the discretion of the
Arbitrators or in the event of their not agreeing, of the Umpire appointed by them who
may determine the amount thereof or direct the same to be fixed as between solicitors
and client or as between parties and shall direct by whom and in what manner the
same shall be borne and paid.
13. JURISDICTION:
The courts at Chandigarh alone will have the jurisdiction to try any matter, dispute or
reference between the parties arising out of this Agreement/Contract. It is specifically
agreed that no court outside and other than Chandigarh court shall have jurisdiction in
the matter.

Page 35 of 53

<!-- page 38 -->

ANNEXURE-D1
(Undertaking from the Supplier on a Non-Judicial Stamp Paper of Rs. 5/-duly attested
by Notary) (To be returned with the Technical Bids)
PERFORMANCE BOND/ GUARANTEE
In consideration for Dr. Debabrata Das (Assistant Professor, Department of Geology, Panjab
University, Chandigarh) (hereinafter called the purchaser) having agreed to release the 100%
payment of net price as per terms and conditions of a concluded Contract
No._______________________________________________dated____________________
(Hereinafter called ‘the contract’) for
Supply of Atomic Absorption Spectrometer (hereinafter called the goods) to us i.e. Messrs.
_____________________________________________ (hereinafter called ‘the supplier') on
submission of a Performance Bond to the satisfaction of the purchaser for the due
performance of the said contract.
We, Messrs _________________________________________________ (hereinafter called
the Supplier) hereby submit the FDR/TDR
No._________________________________________________issued by_______________
___________________(Name of the Bank) for Rs 5% of value of item pledged in favour of
Dr. Debabrata Das (Assistant Professor, Department of Geology, Panjab University,
Chandigarh) as Performance Guarantee amount and hereby irrevocably, unconditionally and
absolutely undertake against any loss or damage caused or suffered by the purchaser by
reason of any failure of the supplier to perform or omission or negligence to perform any part
of its obligations to the satisfaction of the purchaser in terms of the contract.
We, the Supplier, do hereby authorize Dr. Debabrata Das (Assistant Professor, Department
of Geology, Panjab University, Chandigarh) to forfeit this Performance Guarantee
amount/undertake to pay the amount due and payable under this guarantee without any
demur merely on a demand from the purchaser stating that the amount claimed is due by way
of loss or damage caused to or would be caused to or suffered by the purchaser by reason of
any breach buys of any of the terms and conditions contained in a said contract or by reason
of our failure or omission or negligence to perform the said contract or any part thereof.
We, the Supplier, undertake to pay to the purchaser any amount so demanded by the
purchaser, notwithstanding,
a) any dispute or difference between the purchaser and the supplier or any other person or
between the supplier or any person or any suit or proceeding pending before any court or
tribunal or arbitrator relating thereto, or

Page 36 of 53

<!-- page 39 -->

b) The invalidity, irregularity or unenforceability of the contract, or
c) Any other circumstances which might otherwise constitute discharge of this guarantee,
including any act or omission or commission on the part of the purchaser to enforce the
obligations by the supplier or any other person for any reason whatsoever.
We, the Supplier, further agree that the Performance Bond/Guarantee herein contained shall
be continued one and remain in full force and effect during the period that would be taken for
the performance of the said contract and that it shall continue to be enforceable till all the
dues of the purchaser under or by virtue of the said contract have been fully paid and its
claims satisfied or discharged or till the office of the Chairperson/Director/Coordinator of the
respective Department/Centre/Institute, Panjab University, Chandigarh certifies that the
terms and conditions of the said contract have been fully and promptly carried out by us and
accordingly discharges this Performance Bond / Guarantee.
We, the Supplier, further agree with the purchaser that the purchaser shall have the fullest
liberty without our consent and without affecting in any manner out obligations hereunder to
vary any of the terms and conditions of the said contract or to extend time of performance by
us from time to time or to postpone for any time or from time to time and of the powers
exercisable by the purchaser against us and forbear or enforce any of the terms and
conditions relating to the said contract and we shall not be relieved from our liability by
reason of any such variation or extension being granted to us or for any forbearance, act or
omission on the part of the purchaser or any indulgence by the purchaser to us or by any such
matter or thing whatsoever which under the law relating to sureties would, but for this
provision, have effect of so relieving us.
This Performance Bond / Guarantee will not be discharged due to the change in the
constitution of the Supplier.
We, the Supplier, lastly undertakes not to revoke this Performance Bond / Guarantee except
with the previous consent of the purchaser in writing.
The disputes relating to this Bank Performance Bond / Guarantee shall be resolved as per the
terms and conditions of the contract.

Place:
Date:

Signature and seal of
the Supplier

Page 37 of 53

<!-- page 40 -->

ANNEXURE-E
MANUFACTURERS AUTHORIZATION FORM
To

Dr. Debabrata Das
Assistant Professor,
Department of Geology,
Panjab University,
Chandigarh-160014.

Dear Sir,
Tender No.
We, __________________________________ who are established and reputable
manufacturers of Atomic Absorption Spectrometer (AAS), having factories
at__________________
and__________________,
hereby
authorize
Messrs._________________________________________ [name and address of agents] to
bid,
negotiate
and
conclude
the
contract
with
you
against
Tender
No.__________________for the above goods manufactured by us.
We shall remain responsible for the tender / Agreement negotiated by the said
M/s_________________________________________, jointly and severely. No company or
firm or individual other than M/s _________________________,are authorized to bid,
negotiate and conclude the contract in regard to this business against this specific IFB as also
for all business in the entire territory or India.
An agency commission of________% included in the gross ex-works price is payable toM/s
_________________________________________.
We hereby extend our full guarantee and warranty as per general terms and conditions of
contract for the goods offered for supply against this invitation for bid by the above firm. Our
other responsibilities include:
i. _________________________________________
ii. _________________________________________
(Here specify in detail manufacturer's responsibilities)

Page 38 of 53

<!-- page 41 -->

The services to be rendered by Messrs. _________________________________________
are as under:
i. _________________________________________
ii. _________________________________________
(Here specify the services to be rendered by the agent)

In case duties of the agent are changed or agent is changed it shall be obligatory on us to
automatically transfer all the duties and obligations to the new Indian Agent failing which we
will ipso-facto become liable for all acts of commission or omission on the part of new
Indian agent.
Yours faithfully,
[Name] for and on behalf of Messrs.______________________
[Name of manufacturers].
Note: This letter of authorization should be on the letter head of the manufacturing concern
and should be signed by a person competent and having the power of attorney to bind the
Manufacturer. A copy of notarized power of attorney should also be furnished.

Page 39 of 53

<!-- page 42 -->

ANNEXURE-F
PROFORMA OF CERTIFICATE FOR ISSUE
BY THE PURCHASER AFTER SUCCESSFUL COMMISSIONING OF EQUIPMENT

No. ___________________ Date___________________
To
Messrs., ___________________
__________________________
---------------------------------------Subject: Certificate of installation/commissioning of equipment/plant and its satisfactory and
faultless functioning for 30 days after installation/ commissioning.
1) This is to certify that the equipment as detailed below has been received in good condition
along with all the standard and special accessories and a set of spares (subject to remarks in
para no. 2 below) in accordance with the contract/technical specifications.
The same has been installed and commissioned.
a. Contract No. /Supply Order No. __________________________ dated____________
b. Description of the equipment(s)/plant(s)
c. Name of equipment.
d. Bill of lading/air way bill/railway receipt/woods consignment note no._____________
______________________________dated_____________________
e. Date of installation/commissioning
f. Date of completion of 30 days satisfactory and faultless functioning of equipment.
2) Details of accessories/spares not yet supplied and recoveries to be made on that
account: SI. No. Description of item Quantity Amount to be recovered
__________________________________________________________________________
3) The proving test has been done to our entire satisfaction and operators have been trained
to operate the equipment(s)/plant(s).
4) This will be without prejudice to the recoveries/penalties/LD which becomes payable
due to omission or commission on the part of the Second and Third Party as per the
Agreement, Supply Order and LOC.

Page 40 of 53

<!-- page 43 -->

Signature
Name
Designation with stamp
### Explanatory notes for filling up the certificate:
a. He has supervised the commissioning of the equipment in time, i.e. within the time
specified in the contract.
b. It should always be kept in mind that satisfactory installation and commissioning means
satisfactory and faultless functioning of the equipment for 30 days and of works conducted
there under covered under the contract in working order.

Page 41 of 53

<!-- page 44 -->

ANNEXURE-G
Proforma for performance statement
(for the period of last three years)
Tender No.
Date and time of opening

:
:

Name and address of the tendererOrder placed Order No. & Description of
by
(address of
Purchaser)

1

Date

Atomic
Absorption
Spectrometer

2

3

Value of
Order
(Rs.)

4

Page 42 of 53

Date of
completion
Of Contract

Remarks
indicating
reasons for
delay if any

Have the goods
been
functioning
satisfactorily
(attach
documentary
proof)

5

6

7

<!-- page 45 -->

ANNEXURE-H
(To be executed on stamp paper) worth Rs.5/I______________________ son of _______________________________
______________Resident of ___________________________________________________
Police
Station___________ Distt._____________________________ Contractor/Partner or Sole
Proprietor (Strike out word which is not applicable) of Firm of
Contractor_________________________ do hereby declare on solemn affirmation that the
individual/ companies, black-listed by the Union or the State Government or any partner or
shareholder thereof are not directly or indirectly connected with or has any subsisting interest
in business of my/our firm.
In case the information is found to be incorrect or false, an appropriate action may be taken
against me by the authorities. I shall also be liable to indemnify the University in case any
claim arises out of information given by me.
Deponent______________
Address _______________
______________________
______________________
Dated________________

Verification:I do hereby solemnly declare and affirm that the above declaration is true and correct to the
best of my knowledge and belief. No part of it is false and nothing has been concealed
therein.
Deponent__________

Page 43 of 53

<!-- page 46 -->

Section-1: TECHNICAL BID
Technical Bid shall be submitted online as described in General Instruction to the Bidders.
a. Earnest Money Deposit.
b. Pre-qualification criteria supporting documents
c. Technical proposal
d. Technical support documents in CD/Pen drive (Brochures, data sheets etc)
(Before the date and time of technical bid opening)
1.1 Details of EMD:
Earnest Money Deposit Details
Demand Draft/ BG
Amount (in Rs.)
no. & date

Name of the Bank &
Branch

Page 44 of 53

<!-- page 47 -->

1.2: General Information of the Bidder:

Page 45 of 53

<!-- page 48 -->

1.3 Format of Bidder Eligibility Criteria

1.4 Format of Technical Proposal:
(Proposed Technical solution)
The attachment broadly contain the following details:
The attachment broadly contain the following details:
 List of successful implementation along with user performance certificate
 Installation diagram and procedure document
 OEM certificate
 Manufactures Authorization Form (MAF – if not OEM)
 Mode and process of support
 Plan document for support and preventive maintenance of the system
 Training & handholding
 Support and Maintenance
It should also include
I. Make, model and part no. of items and sub-items quoted.
II. Detailed Description of Technical specifications
III. Detailed brochure with specifications for the offered items with model & part numbers
highlighted.
IV. Details of licenses offered for software if any
1.5: Compliance statement:
Compliance statement as per the template provided shall be provided along with tender.
Technical
Complied
Remarks
In case of deviation,
Documentary
Sl. No.
Specification
Yes/No
SL. No of the item in
Evidence
non-compliance
statement

Note : Relevant portions of the referred documents to be highlighted.

Page 46 of 53

<!-- page 49 -->

1.6: Non-Compliance Statement
Any proposed deliverable/ functional aspects/ technical aspects/ terms/ conditions or any other
item NOT IN compliance to RFP Requirement.

1.7: OEM Certificate:
OEM Certificate
(to be submitted by manufacturers )
To,
Dr. Debabrata Das,
Principal Investigator, SERB Project
Department of Geology, Panjab University
Chandigarh-160014.
Sub: Product Compliance with the tender specifications for “Supply, Installation, Implementation
and Commissioning of AAS with 3 year onsite warranty and 5 years optic warranty.
Ref. No.
Dated:
Dear Sir
Tender No
Equipment Name
1. We …………………………………… (name of the OEM) declare that we are the are the original
manufacturers of the above equipment having registered office at
………….. (full address with telephone number/fax number & email ID and website), and having
factories at ______________
2. We hereby declare that we are willing to provide guarantee/warranty and after sales service
during the period of warranty/CMC/AMC as per the above tender.
3. We also hereby declare that we have the capacity to manufacture and supply, install and
commission the quantity of the equipment’s tendered within the stipulated time.
(Name) for and on behalf of
M/s.____________
(Name of manufacturers)
Date: Place:

Page 47 of 53

<!-- page 50 -->

Note: This letter of authority should be on the letterhead of the manufacturing concern and should
be signed by a person competent and having the power of attorney to bind the manufacturer.
1.7: MAF Certificate:
MANUFACTURER’S AUTHORISATION FORM
(to be submitted by authorized dealers/representatives/importers)
To,
Dr. Debabrata Das,
Principal Investigator, SERB Project
Department of Geology, Panjab University
Chandigarh-160014.
Sub: Product Compliance with the tender specifications for “Supply, Installation, Implementation
and Commissioning of Full Field Digital Mammography Unit with 5 year onsite warranty" in mobile
telemedicine unit.
Ref. No.
Dated:
Dear Sir,
Tender No Equipment Name
1. We …………………………………… (name of the OEM) are the original manufacturers of the above
equipment having registered office at ………….. (full address with telephone number/fax number &
email ID and website), having factories at ______________ and ______________ , do hereby
authorize M/s._________________ (Name and address of tenderer) to submit tenders, and
subsequently negotiate and sign the contract with you against the above tender no..
2. No company or firm or individual other than M/s.___________________ are authorized to bid,
negotiate and conclude the contract in regard to this business against this specific tender.
3. We also hereby undertake to provide full guarantee/warrantee /CMC/AMC as agreed by the
tenderer in the event the tenderer is changed as the dealers or the tenderer fails to provide
satisfactory after sales and service during such period of Comprehensive warranty/CMC/AMC and
to supply all the spares/reagents during the said period.
4. We also hereby declare that we have the capacity to manufacture and supply, install and
commission the quantity of the equipments tendered within the stipulated time.
(Name)
for and on behalf of M/s.____________
(Name of manufacturers)
Date:
Place:
Note: This letter of authority should be on the letterhead of the manufacturing concern and should
be signed by a person competent and having the power of attorney to bind the manufacturer.

Page 48 of 53

<!-- page 51 -->

1.8: Training:
Details of training planned & handholding

1.9Commercial Bid:
Commercial bid with value/price information masked as per BoQ.pdf (with mention of make,
model, part no./sub part nos., item description, unit and quantity quoted)

1.10: Tender Acceptance Letter
TENDER ACCEPTANCE LETTER
(To be given on Company Letter Head)
To,
Dr. Debabrata Das,
Principal Investigator, SERB Project
Department of Geology, Panjab University
Chandigarh-160014.
SUB: Acceptance of Terms & Conditions of Tender.
Tender Reference No:
Name of Tender / Work:
Dear Sir,
1. I/We have downloaded / obtained the tender document(s) for the above mentioned
`Tender/Work’ from the web site(s) namely: eprocure.gov.in as per your NIT /
advertisement, given in the above mentioned website.
2. I/We hereby certify that I / We have read the entire terms and conditions of the tender
documents (including all documents like annexure(s), schedules(s), etc.), which form part of the
contract agreement and I / We shall abide hereby by the terms / conditions/ clauses contained
therein.
3. The corrigendum(s) issued from time to time by your department / organization too has also
been taken into consideration, while submitting this acceptance letter.
4. I/We hereby unconditionally accept the tender conditions of above mentioned tender
document(s) / corrigendum(s) in its totality / entirety.
5. I/We do hereby declare that I / We have read and understood the entire technical specification
laid down in the tender document and has prepared the technical bid in compliance with the
technical requirements specified in the document.
6. I / We certify that all information furnished by the our Firm is true & correct and in the event that
the information is found to be incorrect/untrue or found violated, then your department/
organization shall without giving any notice or reason therefore or summarily reject the bid or
terminate the contract, without prejudice to any other rights or remedy including the forfeiture of
the full earnest money deposit absolutely.
Yours Faithfully,
Authorized Signatory.
(Signature of the Bidder, with Official Seal)

Page 49 of 53

<!-- page 52 -->

1.11 : OEM Support & Commitment through Bidder:
OEM Support & Commitment through Bidder
[On the Letter head of the OEM]
To,
Dr. Debabrata Das,
Principal Investigator, SERB Project
Department of Geology, Panjab University
Chandigarh-160014.
SUB: Product Compliance with the tender specifications for Supply, Installation, Implementation
and Commissioning of AAS with 3 years onsite warranty and 5 years optic warranty.
Ref: Tender No.:
This is to certify that the bidder M/s ___________________ (name of bidder) is representing us,
M/s _______________ (name of OEM) for ___________ solution (name of product category) for
the above referred tender no., for Supply, Installation, Implementation and Commissioning of AAS
with 3 years onsite warranty and 5 years optic warranty.
We confirm that we have understood the delivery & installation timelines defined in the tender. We
confirm that we have worked out all necessary logistics and pricing agreement with<Bidder Name>
and there won’t be any delay in delivery, installation and support due to any delay from our side.
Our full support is extended in all respects for supply, warranty and maintenance of our products.
We also assure to provide the required spares and service support for the supplied equipment for a
period of minimum 5 years from date of installation of the equipment.
M/s ___________________ (name of OEM) hereby certify that the products offered for this tender
are not declared end of sale and if any of the product is declared end of sale during the installation
and commissioning phase, it will be replaced with suitable equivalent or higher rollover product.
We also undertake that in case of default in execution of this tender by ___________________
(name of bidder),M/s _______________ (name of OEM) will provide necessary support to Geology
Department, PU in identifying another authorized OEM partner with similar
certifications/capabilities and extend support to the new partner in accordance with OEM’s
agreement with the new partner. In case Bidder is unable to fulfill the obligations given under this
tender, M/s _______________ (name of OEM) will be responsible to replace the Bidder with an
alternate Indian Authorized agent to facilitate Geology Department, PU to get the requisite work
done. M/s _______________ (name of OEM) shall also ensure that the alternate Indian Authorized
Agent in this case shall abide by all the terms and conditions mentioned in the purchase order
released to M/s ___________________ (name of bidder).
We declare that the following details provided below are correct and submitted to ensure that the
tender requirements are fully met by the bidder without any non-compliance through the offered
solution:

Page 50 of 53

<!-- page 53 -->

Page 51 of 53

<!-- page 54 -->

Section 2:COMMERCIAL BID
Commercial Bid shall be submitted online as described in General Instruction to Bidders.



Commercial Bid covering letter
Price bid as per BoQ.pdf duly filled

2.1: Commercial Bid Covering Letter Template< In Bidders letter head >
Date: [Insert: date of bid]
From
(Registered name and address of the bidder)
To,
Dr. Debabrata Das,
Principal Investigator, SERB Project
Department of Geology, Panjab University
Chandigarh-160014.
Dear Sir,
Having examined Request For Proposal (RFP) number ------------------- ------------- ----------------------dated ------------------------------ the receipt of which is hereby acknowledged, we, the undersigned,
offer for Supply, Installation, Implementation and Commissioning of AAS with 3 year onsite
warranty and 5 years optic warranty, in full conformity with the said RFP, for a total project cost of
Rs …………… (Rupees …………………………………… only). The above amount is in accordance with the
Price Schedules herewith made part of this bid as per the Commercial bid template.
We undertake that we shall successfully Supply, Installation, Implementation and Commissioning of
AAS with 3 year onsite warranty and 5 years optic warranty in conformity with the bidding
documents (and as amended from time to time) for a total cost as provided in the Commercial bid if
the contract is awarded to us.
We declare that we have studied RFP and are making this proposal with a stipulation that you shall
award us Contracts, either in part or whole, Supply, Installation, Implementation and
Commissioning of Full Field Digital Mammography Unit with 5 year onsite warranty in mobile
telemedicine unit, identifying separately including all other services specified in the Contract
Documents.
We have read the provisions of RFP and confirm that these are acceptable to us. All necessary
clarifications, if any, have been sought for by us and duly clarified in writing, by Geology
Department, Panjab University, Chandigarh. We understand that any other ambiguous clauses in
the RFP, if any, are subject to interpretation of Geology Department.
3. We further declare that additional conditions, variations, deviations if any, found in the proposal
other than those listed in Attachment pertaining to any rebates offered, shall not be given effect to.

Page 52 of 53

<!-- page 55 -->

4. We undertake, if our bid is accepted, to commence the work on the project immediately upon
your Notification of Award to us, and to achieve Completion within the time stated in the Bidding
Documents.
5. If our bid is accepted, we undertake to execute all contractual documents and provide all
securities & guarantees as required in the bid document (and as amended from time to time).
6. We undertake that, in competing for (and, if the award is made to us, in executing) the above
contract, we will strictly observe the laws against fraud and corruption in force in India namely
“Prevention of Corruption Act”.
7. We agree to abide by this bid, consisting of this letter, the tender fee, EMD, Technical bid and
Commercial bid, for a period of bid validity from the date fixed for submission of bids as stipulated
in the RFP, and it shall remain binding upon us and may be accepted by you at any time before the
expiration of that period.
8. Until the formal order is placed and final Contract is prepared and executed between us, this bid,
together with your written acceptance of the bid and your notification of award, shall constitute a
binding contract between us.
Dated this [number], Day of [month], [year]
Signed: ………….
In the Capacity of [title of position]
Duly authorized to sign this bid for and on behalf of [name of the Bidder]
Witness:
Address:

2.2: BOQ TemplateSl.
No.

Item
Description

Quantity

Spec.

1
2
3

Page 53 of 53

Unit Cost

Total Cost
