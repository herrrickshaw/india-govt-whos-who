---
doc_id: "676fb8ad4fbe81ae"
source_url: "https://cdnbbsr.s3waas.gov.in/s3dd28e50635038e9cf3a648c2dd17ad0a/uploads/2024/04/2024042941.pdf"
ministry: "Joint Admission Committee, Chandigarh"
title: "Border Area Certificate"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "762cb633315fa0ec"
---

<!-- page 1 -->

Certificate by the Candidate from Border Area School
(For institutes of Panjab University only)

No.

Dated:

Certified that Mr./Ms./Mx. ______________________ son / daughter of Sh. ______________________
______________________________ and Smt. ________________________________ resident of
_________________________________________ has passed the Matriculation from school situated in
border area.
It is further certified that Mr./ Ms./ Mx. __________________ has studied in the institution(s) that is
situated within 20 kms from the International Border, as per date of joining and leaving school is given
below:-

Name of School

Date of joining

Date of leaving

1

__________________

______________________

_______________________

2

__________________

______________________

_______________________

3

__________________

______________________

_______________________

4

_______________________

______________________

_______________________

Place:

Seal and Signature

Date:

(Tehsildar / Principal / Headmaster)

*This certificate is only for those students, who have passed their Matric from school situated in Border
Area and +2 from school situated in any other area.
