---
doc_id: "c0ebb96fae8bcf3b"
source_url: "https://www.library.puchd.ac.in/includes/tenders/2022/20220620095305-tender.pdf"
ministry: "A. C. Joshi Library, Panjab University, Chandigarh"
title: "Supply & Erection of Split type Air-Conditioners at Controller of Examination Office in Administrati"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "474798547343d69a"
---

<!-- page 1 -->

PANJAB UNIVERSITY
CONSTRUCTION OFFICE, CHANDIGARH
ELECTRICAL WING
NOTICE INVITING TENDER
Sealed tenders on percentage rate basis are invited from the Contractors on the approved list of P.W.D.
Building and Roads Branch/Central P.W.D. M.E.S. Boards, Corporation, HUDA, PUDA Institutions, C.H.B. for
the following work.
Sr.
No
1.

Name of work

Estimated
Cost

Earnest
Money

Time
Limit

Supply & Erection of Split type Air-Conditioners at
Controller of Examination Office in Administrative
Block P.U. Campus, Sector -14, Chandigarh.

Chargeable Head:- Rs. 14,00,000/- out of
“Development Fund”
Rs. 4,79,609/Rs. 9,600/10 days
NOTES:
1.
Tender form will be issued to only eligible tenderers and for this:
a.
Application for issue of tender form will be accepted upto 29.06.2022 at 5.00 p.m. only.
b.
Bank receipt of tender fee and Bank draft of earnest money in favour of Registrar, P.U. Chandigarh
will be deposited by the eligible firms for issue of tender upto 30.06.2022 at 1.00 p.m. only. Tender
shall be issued upto 5.00 p.m. 30.06.2022.
c.
The tender form will be received by the undersigned in his office on 01.07.2022 upto 3:30 p.m and
opened at the same time in the presence of the tenderers or their representatives who may like to be
present at that time. In case of holiday, tender will be opened on next working day.
2.
The detailed Notice Inviting Tender can be seen in the office of the undersigned at any time
during working hours.
3.
Tender form can be had from this office.
4.
Rates should be quoted both in words and figures in tender.
5
The firm that have completed three works with equal cost of 40% value of the similar nature of work
with one work in Govt. Deptt. OR two works with equal cost of 60% value of the work OR one work
with equal cost of 80% value of the work, during the last seven years and furnishes the performance
certificate for the same shall be eligible for issue of the Tender form.
6.
The Contractor/Firm will submit tender application along with copies of GST, Pan Card,
Partnership Deed (if applicable).
7
Conditional tender will not be accepted.
8.
The undersigned has right to accept or reject any or all the tender without assigning any reason.
9.
The tenderer shall have to furnish an affidavit as under:a.
I/We hereby declare that
b.
I/We have not been black listed, debarred/ suspended by any Govt., Semi-Govt./ Corporation/
Private Organization during the last 7 years.
c.
I/We have not been panelized for non performance of contract agreement during the last 7 years.
Sub-Divisional Engineer (Elect.)
Panjab University
