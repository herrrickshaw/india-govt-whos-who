---
doc_id: "b0d67fedc6aef235"
source_url: "https://maths.puchd.ac.in/includes/noticeboard/2020/20200920003101-nescircular2020-21.pdf?2026"
ministry: "Mathematics Department, Panjab University, Chandigarh"
title: "Circular regrading scholarship scheme under E-Scholarship portal for year 2020-21"
date: ""
pages: 1
method: "tesseract:pan+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "9c6180eabc3b0bdc"
---

<!-- page 1 -->

ਇੱ en
प्‌
PANJAB UNIVERSITY, CHANDIGARH
From To
Nodal Officer (National E-Scholarship) The Chairpersons/ Principals/ HODs
Panjab University All Teaching Departments, of PU
Chandigarh Regional Centres, PU
Constitutional College, PU
Chandigarh
No. 08 ly £5 2 lw E.G) 44119 ०
Subject: CIRCULAR regarding Scholarship schemes under National E-Scholarship Portal for the

year 2020-21. ४
Sir/Madam,

Govt.of India, has launched various online scholarship schemes for the year 2020-21 at the
National E-Scholarship portal. Various scholarship schemes along with guidelines, rules, eligibility criteria, amount
of scholarship etc., is available at the site address http://scholarships.gov.in.

Students from departments/Institutions/Centres/Constituent Colleges of Panjab University has to
register themselves at this site to apply for any scholarship scheme. After registration, they will get the Application
ID from the site and will upload the required data and their supporting documents with the help of their own L
Application ID and password. After submission of online scholarship application, students will submit the hard copy
of the scholarship application along with its supporting documents to their respective
departments/Institutions/Centres/Constituent Colleges, the detail of which is given below:

¢ — Printout of Scholarship Application, complete in all respect

¢ Passport size photo of the student

e Institutional Verification Form alongwith Annual fee detail for both the semesters of current

academic year

¢ — Self attested copy of fee receipt of current course, deposited by the student in the department at the
6 time of admission

¢  Self-attested photocopy of Residential Certificate

e¢ Annual Family Income Certificate

¢ In case of Fresh Scholarship Applicant: copy of self attested certificate of ‘Previous Academic

Marksheet’ as filled in the form

In case, of Renewal Scholarship Applicant: copy of self attested certificate of ‘Previous year

Marksheet’ as filled in the form

¢ Self attested photocopy of AADHAR Card
e Self attested photocopy of Bank Account passbook in the name of student linked with Aadhar

Card

Respective teaching departments/ Institutions/ Centres/ Constituent Colleges are required to verify
the student’s Scholarship Application along with supporting documents i.e. (Institutional Verification form along
with fee detail, Previous Class percentage and all other supporting documents etc.) and forward the same to National
E-Scholarship Section of SC/ST Cell, Aruna Ranjit Chandra Hall, Ist Floor, Room No.216 for approval, online
verification and further processing.

It is also suggested to kindly visit regularly on the website http://scholarships.gov.in for updates of
various scholarship schemes and for new scholarships introduced by the Govt. of India from time to time, so that
maximum number of students of the university can avail the benefit by applying for scholarships, according to their
eligibility. . nN

| ਵਾ
National E-Scholarship Section
SC/ST Cell, Panjab University, Chandigarh
