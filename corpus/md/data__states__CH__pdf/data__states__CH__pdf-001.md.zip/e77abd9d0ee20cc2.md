---
doc_id: "e77abd9d0ee20cc2"
source_url: "https://gandhianstudies.puchd.ac.in/includes/noticeboard/2021/20210713121931-jaacrac1.7.21.pdf?2026"
ministry: "Department of Gandhian and Peace Studies, Panjab University, Chandigarh"
title: "Minutes of Meeting, Joint Academic Administrative Committee (JAAC) and Research Advisory Committee (RAC) held on 01/07/2021"
date: ""
pages: 2
method: "tesseract:pan+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "edf87804766c247b"
---

<!-- page 1 -->

- ४
DEPARTMENT OF GANDHIAN AND PEACE STUDIES
PANJAB UNIVERSITY, CHANDIGARH
Minutes of the meeting of the Joint Academic and Administrative Committees and Research
Advisory Committees of the Department of Gandhian and Peace Studies held on 01/07/2021 at
11:00 am via online google meet Meeting Id https://meet.google.com/cnz-umzv-mmm.
The Following members attended the mecting:
Academic and Administrative Committees
1. Dr. Namita Gupta, Centre for Human Rights & Duties, P.U., Chandigarh
2. Dr. Sucha Singh, Deptt. of Geography, U.S.O.L, P.U., Chandigarh
3. Dr. Ashu Pasricha, Deptt. of Gandhian & Peace Studies, P.U., Chandigarh
4. Dr. Manish Sharma, Chairperson, Deptt. of Gandhian & Peace Studies, P.U. Chandigarh
Research Advisory Committee
1. Prof. Emanual Nahar, Deptt. of Political Science, USOL, P.U., Chandigarh
2. Prof. Trithankar Bhattacharya, Deptt. of Art History and Visual Art, P.U., Chandigarh ਇੰ
3. Dr. Ameer Sultana, Deptt. cum Centre for Women’s Studies, P.U., Chandigarh
4. Dr. Namita Gupta, Centre for Human Rights & Duties, P.U., Chandigarh
5. Dr. Ashu Pasricha, Department of Gandhian and Peace Studies
6. Dr. Manish Sharma, Chairperson, Department of Gandhian and Peace Studies
The following members could not attend the meeting:
1. Prof. Anuradha Sharma, Deptt. of Community Education & Disability Studies,
P.U., Chandigarh
2. Prof. Manvinder Kaur, Deptt.-cum-Centre for Women Studies and Development

3. Prof. Navjot, Deptt. of Political Science, P.U., Chandigarh

4, Prof. Monica Munjial Singh, Centre for Social Work, P.U., Chandigarh

After detailed discussion on the agenda item, the following decisions were taken:

Agenda1: Application for consideration for the admission to Ph.D, Programme of
Virender Kumar under the supervision of Dr. Ashu Pasricha and Award of
P.U. Ph.D. Fellowship for Research (2020)

Resolved: The Committee members afier looking into the guidelines for registration to Ph.D.
with regard to M.Phil/Ph.D./UGC/NET examinations, the members after looking
into the guidelines as the candidate has cleared his M.Phil/Ph.D, Entrance Test,
2020, conducted by the University on March 07, 2021 and his other required
documents, recommended the case of Mr. Virender Kumar (General Category |
Candidate) for registration to Ph.D, under the supervision of Dr, Ashu Pasricha,
P.U., Chandigarh and also approved his Research proposal which Mr. Virender
Kumar was able to defend without any difficulty and the members also authorized

<!-- page 2 -->

कै
the concerned supervisor and the candidate to finalize the topic and other details
as per their requirements.
Besides, the members also considered the application of the candidate for the Award of
P.U. Fellowship for Ph.D. (2020) and forwarded to the concern authorities for further
necessary action after process of Registration of the Candidate as per PU Rules.
Agenda 2: Application for consideration for the admission to Ph.D. Programme of Mr.
Dev Raj
Resolved: The Committee members afier looking into the Application for consideration for
the admission to Ph.D. of Mr. Dev Raj, the Chairperson informed the members
that as Mr. Dev Raj has not cleared his UGC NET in the concerned subject, so he
' can’t be allowed for the enrolment as per the Panjab University rules and of the
previous cases in the past and the same message has already been conveyed to the
candidate, so the application of Mr. Dev Raj is rejected by the members.
The meeting ended with vote of thanks from the Chairperson.
ਇਤ” Clo Namita Gupta eel Prof. Trithankar
੦੬੫੦ recotusd mee 21908 ਗਲ L
0 ५8 €%<<-<- by
“ry ੭੧੬44) ce 9. ਲੀ ५८)
Cullanc Ars है re g
Callanody. पा fur (8934८ है
Dr. Ameer Sultana Dr. Sucha Singh Dr. Ashu Pasricha
Dr. Manish Sharma
(Chairperson)
