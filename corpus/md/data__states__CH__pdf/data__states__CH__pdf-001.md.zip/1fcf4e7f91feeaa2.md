---
doc_id: "1fcf4e7f91feeaa2"
source_url: "https://online.chdeducation.gov.in/rte/downloads/ADVT202627.pdf"
ministry: "Centralized Online Admission Portal, Chandigarh"
title: "Admission Notification"
date: ""
pages: 8
method: "tesseract:pan+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "3eb1ff12c5fa9cff"
---

<!-- page 1 -->

From हू
The District Education Officer, है
UT, Chandigarh.
; To ਰ੍‌
he Heads of all Unaided Private Recognized Schools. (Non-Minority)
੨ In U.T., Chandigarh. ,
है Memo No. DEO/UT/CA/2025/" 24 4.4.9. 9 y
Dated Chandigarh, the (੪ ॥ 2202s
Subject; Centralised Online Admission for children belonging to Economically Weaker Section
. and Disadvantaged groups (EWS & DG) for the academic session 2026-27 in Unaided
‘ ੪ * Recognised Private Schools (Non-Minority) of UT Chandigarh as per the provisions of
ਹੂ the Right Of Children to Free and Compulsory Education (RTE) Act, 2009 / The Capital
of Punjab (Development & Regulation)Act, 1952 as applicable to Chandigarh, the
Chandigarh Lease Hold of sites and building Rules, 1973 and other guidelines
ਲੇ framed/issued there under, includingeunder the allotment of land to Educational
Institutions (Schools), etc on lease hold basis i Chandigarh Scheme 1996 (As amended
my from time to time, (1996 Scheme).
& Please refer to the subject cited above.
੪ 1. Find enclosed herewith-the detailed instructions regarding Centralised Online admission for
é children belonging to Economically Weaker Section and Disadvantaged Groups (EWS & DG) for
the academic session 2026-27 in Unaided Recognized Private Schools of UT Chandigarh.

5 2. As detailed at Point no. 22 of the instructions, all the Private Unaided Recognized Schoois (Non-
Minority) of UT Chandigarh are directed to register for online admission to the EWS/DG category
in the Entry Level Classes by not later than 16.12.2025, failing to do, the action will be taken as
per rules. न

"3. You are requested to follow the instructions and take necessary action as mentioned therein.
4. This issued with the approval of Competent Authority. 3 i
District Suan ee Officer, Ps
UT, Chandigarh. ( oe ੧2 “
. ; ੧੪੧
Endst No. Even हि Dated: °
A copy is forwarded to the Director School Education, Chandigarh Administration for
information please,
— ੧--
੬ ` ` 0501੮ Education Officer,
UT, Chandigarh.
i

<!-- page 2 -->

ਭਾ है 7
CENTRALISED ONLINE ADMISSION FOR CHILDREN BELONGING TO ECONOMICALLY WEAKER SECTION
AND DISADVANTAGED GROUPS (EWS & DG) FOR THE ACADEMIC SESSION 2026-27 IN UNAIDED
RECOGNISED PRIVATE (NON-MINORITY) SCHOOLS OF UT CHANDIGARH AS PER THE PROVISIONS OF
THE RIGHT OF CHILDREN TO FREE AND COMPULSORY EDUCATION (RTE) ACT, 2009 AND THE CAPITAL
OF PUNJAB (DEVELOPMENT & TEGULATION) ACT, 1952 AND RULES/SCHEMES/GUIDELINES/POLICY
ISSUED THERE UNDER AND AS AMMENDED FORM TIME TO TIME.
Schedule & Guidelines
1. As per section 12 (1) (c) of the Right of Children to Free and Compulsory Education Act 2009 (RTE Act
2009) all the private unaided recognized schools (except the minorities schools) are under obligation
to admit, at the entry level classes, to the extent of at least 25% of the strength of that class, children
belonging to Economically Weaker Section/Disadvantage Group (EWS/D6) in the neighbourhood and
provided fee and compulsory elementary education till its completion.
2. In terms of the Allotment of Land to Educational Institutions (Schools), etc on Lease-hold Basis in
Chandigarh Scheme 1996, as amended from time to time, (Scheme of 1996) made under the provisions
. of the Capital of Punjab (Development and Regulatien) Act, 1952 (1952 Act), as a condition of the
school land allotments every private unaided recognized school in UT Chandigarh whether minority
a and non-minority is bound to reserve 15% of their seats for the EWS of the society upto Sr. Secondary
1 level. Such reservation to the extent of 15% (under Scheme of 1996) is saved under.the RTE Act, 2009
੬ and no reimbursement of the cost of education to the said extent is to be made to the schools under
५ the second proviso to section 12 (2) of the RTE Act, 2009. कि

3. As done in Academic Year 2025-26, Education Department, Chandigarh, for the academic year 2026- 9

27, is undertaking EWS/DG admissions in entry class of Unaided Recognised Private (Non-Minority)
u Schools of UT Chandigarh through the Department's Centralised EWS/DG Admission Online Portal

+. 2026-27 wherein atleast 25% of seats of Unaided Recognized Private (Non-Minority) Schools of UT
Chandigarh (here in after referred to as the ‘School') have been reserved, as per Section 12(1) (C) of
the Right of Children to Free and Compulsory Education Act 2009. The reservation to the extent of 15%
(under Scheme of 1996) is saved under the RTE Act, 2009 and no reimbursement of the cost of
education to the said extent shall be made to the schools under the second proviso to section 12 (2)
of thé RTE Act, 2009.

4, The Centralized Online Admission Process for EWS/DG students to the 25% of seats of Unaided
Recognized Private (Non- Minority) Schools of UT Chandigarh shall be undertaken as per the under .
mentioned schedule: : ਘਈ“. i A =
: Details tes 777

(a)_| Issuance of Calendar of events for admissions 1 06;22085 7
(6) | Registration of all Private Un-aided School (Non-Minority) | Before 16.12.2025
on the Portal nae gg gy
() Registration of candidates on the portal 18.12.2025 to ਰਹ
1 --.2/.01.2026
‘| (@)_] Checking of provisional eligibility of students 01.02.2026 to
. । 21.02.2026 ___ ਰ:
(e)_| Release of st of selected candidates through draw | 25.02.2026 —
{f)__| Confirmation of student admission by schools 16903.2026 7
. | (8) Release of 2" list of selected candidates though draw (if | 17.03.2026
|__| required) _ at wey -< |
(h) | Confirmation of students admission by schools ______124.03.2026
2. The EWS/DG children shall be ੩੦॥॥੧੦੦, ੩5 per the Area of Neighbourhood detailed in the Right of
Children to Free and Compulsory Education (RTE) Act, and 2009 and RTE rules 2010 including guidelines
issued there under. The Area of Neighbourhood (0 to 1 KM, 1+ to 3 KM and beyond 3 KM), for

<!-- page 3 -->

a . Say ४
ae ਲੇ ~
admission in EWS/DG category in the Entry Level Classes of the Schools, have been demarcated and
uploaded on the website of the department ie, www.chdeducation.gov.in
(http://www.chdeducation.gov.in/). The admission shall be as per the following order of priority:
(i) Children residing in the vicinity of 1 Km of the Government School
(ii) Children residing in the vicinity of 3 Kms of the Government School
(0) Children residing beyond 3 Kms of the Government School with the undertaking from the
Parent/s regarding safe transportation of the child.
6. Age criteria to be followed for in the Centralized Online Admission Process for admission (as per
NEP 2020) for EWS/DG students in the Entry Level Classes 2026-27 in the schools shall be (Age as
on 31.03.2026):
- soe Child Born b/w (Date as on —
fa | es Level -I__ | 1.4.2022 to 31.3.2023 (3 to4 years) SS
1 Pre-Primary Level -Il 1.4,2021 to 31.3.2022 (4+ to S years) SS
: 3__| Pre:Primary Level-lIl_. | 1.4.2020 to 38,3.2021 (5+ to 6 years), | है

7. Admissions for EWS/DG students at Entry Class Level in the Unaided Recognised Private (Non-
Minority) Schools of UT Chandigarh for the Academic Session 2026-27 shall be conducted only
through the Department's Centralized Online Admission Module accessible only at any of the
Government/ Unaided Recognised Private (Non-Minority) Schools of UT Chandigarh.

No Unaided recognized private (Non-Minority) Schools of UT, Chandigarh Schools shall admit child
in the EWS/DG seat in the Entry Level Class through offline mode.

8. The online forms can only be filled from any Government/ Unaided Recognised Private (Non-
Minority) Schools of UT Chandigarh for which these schools will put up atieast two help
desks/school to facilitate the process. Because of this restricted access, the Parents may visit any
Government/Unaided Recognised Private (Non-Minority) Schools of UT Chandigarh to fill up for
their ward the common online admission’ form where the teachers will guide and help them
complete online form at Rs 0/- cost. Each such school will designate atleast the following staff and

- Make available of the following infrastructure for facilitating the filling up the Online Admission

9 form:
a) Atleast 02 Computers with internet facility ਨ
9) 02 Computer Teachers OR any other teacher Teachers of the school for verification of
ਰਹ documents and filling the online form

9. Adequate publicity vide advt. and press note shall be issued by the Department. However, the
Schools must reach out to the interested and eligible candidates to make use of this Opportunity
for admission. *

10. The Entry Level Class in each such School will be notified in the online form. : रन
. 11. 8 00159।। ।€0ਡ 3੧੦ 1੩੪੧8 ੩ ।€90੬੦੬ proof of UT Chandigarh is eligible for applying for
admission of their ward under EWS/DG category in School, subject to the following conditions: - _
SN] Details —=SS*=*«=CSS*”d* ceptable evidence
~ | Child belonging toa parent c or = = i
{i) | guardian whose total annual family Deputy Commissioner, Chandigarh
income is Less than 1.50 lacs Or
Income Certificate in r/o Mother / guardian (in
special cases) issued by DC, Chandigarh.
(i) "| Child betonging to disadvantaged group (Section 2 (d) of the RTE Act 2008) Le, ee
Scheduled Caste _ SC Certificate issued by DC/SDM/Tehsildar

<!-- page 4 -->

*
ਦੇ :
(b) Children of disabled persons Certificate issued by the Medical Board of:
ਨ Certificate issued by the a!
Medical Board of: e General Hospital Sector 16 | »
having minimum 60% disability Chandigarh;
for either of the parents ° Government Medical College
Hospital Sector-32, Chandigarh; or
(c) ‘Children suffering from cancer, | ੪ PGIMER, Chandigarh
acquired immunodeficiency
syndrome (AIDS) and
—jthalassemia
(d) | children living with or affected
| 4. cement x sc |
(e) | Children of war widows SS
0 Children of defence personnel, Certificate issued by District Sainik Welfare
ते Officer or concerned Defence Authorities
Paramilitary. personnel and
. police personnel died while in| ®
___| service _ a
(g) Orphan children as defined in Documents/Certificate issued by Competent
Juvenile Authority.
Justice Act residing in Union
Territory
(h) | Children of families who lost
their sole earning member
0
ਰਹ (iii) | Age Proof Child’s Aadhar Card or passport or Birth certificate
issued by the Registrar of Births and Deaths or the
Municipal Corporation or any other prescribed
authority, whosoever has been empowered under
. हु the Registration of Birth and Deaths Act 1969 to
_ register the birth of a child born in India.
. Residence Proof (Parents residence (i) Ration Card issued in the name of Parents
proof in case child’s residence proof is having name of child in Ration Card.
. not available) (ii) Domicile certificate of child or of her/his*
parents.
(iii) Residence certificate issued by the Deputy
है Commissioner, UT Chandigarh in the name of
child/parents,
: हि (iv) Voter ੮ (EPIC) of any of the parents,
(v) Electricity bill/BSNL telephone bill/Water bill *
. in the name of parents. .
है (vi) Unique Identity Card (Aadhaar) of
| . mother/father/child issued by Government of
india. हि
ध ਰ੍‌ (vii) Passport in the name of any of the parents or
child.
(viii) Property Ownership Document issued by the
Estate Office, Chandigarh Housing Board,
Municipal Corporation Chandigarh. However,
Rent Agreement (registered or un-
registered) will not be considered as proof of
residence

<!-- page 5 -->

% .
12. The Candidates/applicants will be required to upload online the following documents attested by
parents/guardian.
SN | Document Wed Evidence/proof —
(i) Proof of date of birth Child's Aadhar Card or passport or Birth certificate
issued by the Registrar of Births and Deaths or the
Municipal Corporation or any other prescribed
authority, whosoever has been empowered under the
Registration of Birth and Deaths Act 1969 to register
ਦਰ :मत+तलतत ___| the birth of a child born in india. (either one)
(0) | Residence Proof (Parents | (i) Ration Card issued in the name of Parents having
residence proof in case child's name of child in Ration Card.
residence proof is not available) (ii) Domicile certificate of child or of her/his parents.
(any two documents) (iii) Residence certificate issued by the Deputy
Commissioner, UT Chandigarh in the name of
child/parents.
(iv) Veter |-Card (EPIC) of any of the parents.
(v) Electricity bill/BSNL telephone bill/Water bill in
the name of parents.
(vi) Unique identity Card (Aadhaar) of
mother/father/child issued by Government of
india.
(vii) Passport in the name of any of the parents or
child.
(viii)Property Ownership. Document issued by the
है Estate Office.
However, Rent Agreement {registered or un-
है registered) will not be considered as proof. of
residence __
(ili) | Proof for EWS or DG category, | As per para (10) above
Whichever applicable. _ _ —. st
13. The Eligible applicants are given an option to complete in the admission form options for: ४
= Preference of the eligible applicants for admission 8 Option for Schools on the « |
children under EWS/ DG Category at Entry Level | module in Preference mode
Classes in private unaided recognized schools pe ੩]
1 1 Category/Preference (0to1KM) __-__| In total 10
|2 | 2% Category/Preference(1to3KM) | ||
3__| 3" Category/Preference (E Beyond3KM) | |

14. The computerized draw of lots for Online Applications received from EWS/DG Category
students/applicants for admission at the Entry Level Classes of the Schools will be conducted based
on the school preference criteria of the applicant.

15. Admission granted vide online allotment of school to a child will be on provisional basis, to be
confirmed only after the documents are verified by the allotted School.

16. The successful candidates/applicants of the computerized draw of lots shall be informed about the
school allotted for admission under EWS/DG category by uploading list on the department website.
However, SMS will be sent on their registered mobile number on completion of draw of lots.

17. The successful candidates/applicants will be able to check the name of the school allotted through
‘Computerized Draw of Lots' using Registration ID and Date of Birth available at the home page of
the departmental website www.chdeducation.gov.in. (http://www.chdeducation.gov.in/) *

<!-- page 6 -->

ਫ਼
੯ % :

18. Cancellation of admission: If the successful applicant fails to approach/report the allotted School
within 10 days (details to be communicated through SMS/by school to successful candidates) for
completing the formalities for admission under EWS/DG category, his/her candidature shall be
cancelled,

19. In case of the rejection of admission by the school, the school shall cléarly specify, in detail, the
reason of rejection. The category of the reasons may be selected from the following grounds: -

# a) Non-submission of valid residence proof

b) Non-submission of valid EWS/DG & CWSN proof.

c) For EWS, the Income Certificate does not show annual income as less than one lakh fifty
thousand per annum.

d) Duplicateentry.

e) Candidate did not report for document checking/admission in spite of repeated
reminders,

f) Other reason - specify

20. The admission of the child shall be cancelled in case the documents submitted by the applicant at

~ _ the time of admission or at later stage are found te be forged/fake/incorrect/manipulated etc. and
strict penal action shall follow on the parents/guardian of the child.

21. RTE - Admission Monitoring Committee: To redress the queries and grievances, a monitoring cell `
shall be constituted under the Chairmanship of the Deputy Director of the Department of
Education, which is as under: -

है a) Dy. Director-IV, O/O DSE, UT, Chandigarh-Chairperson
b) District Education Officer, UT, Chandigarh —- Member
੮ DA 0/0 DEO, UT, Chandigarh-Member
d) Two Representatives from the Private Schools -To be nominated by DSE, UT, Chandigarh. न

22. All the Non-Monitory Schools, be directed to register for online admission to the EWS/DG category
in the Entry Level Classes by no later than 16.12.2025, failing to do, the action will be taken as per
rules without further reference to the school.

23. Any grievance/ complaints or queries relating to admission process in EWS/DG category may be
registered at the link ewsgrievancescell@gmail.com or at helpline numbers 0172-2780398
. (between 10.00 AM to 5.00PM (except lunch time 1.00 pm to 1.30 pm) on all working days
हु (Monday to Friday).
24. The schools must regularly check the website for updates: www.chdeducation.gov.in.
(http://www.chdeducation.gov.in/)
a) If the parent of the child to whom seat has been allotted is not traceable by the school for
10 days, this may be treated as a dispute and referred to RTE EWS/DG Admission Monitoring
Committee. After the decision of Committee, the seat may be released for admission of
हे -_ €010€।। 1੧ ੧੧੬ 2" draw lots.
b) In case the aggrieved party is not satisfied by the decision of Committee, the Director School 3
: Education, UT Chandigarh shall be the final appellate authority
੮) In case any dispute is noted against a specific school, the Committee may take Suo moto
cognizance and initiate inquiry, .
d) Any issues with regard to documents shall be taken up by the Committee, .
e) Even after the completion of above stated process, if there is any seat vacant in any private
school from the earmarked quota of 25 % seats, Education Department will be competent
to decide on the procedure to allot the EWS/DG vacant seats.
25. Inthis connection, the respective Unaided Recognized Private Schools of UT Chandigarh are hereby
requested to do the following (after computerized draw for admission is undertaken): - .

(a) Place an printout of the list of students granted admission vide the computerise draw outside

the school gates for the information and ease of parents.

<!-- page 7 -->

ਚੇ :

(b) To help and facilitate the parents of EWS/DG category children, the concerned schools must
set up Help Desks within the school premises to explain to the parents the formalities regarding
paper work etc. required for admission.

(c) Admission to EWS/DG category successful candidates shall not be denied on frivolous ground
€.8. one or two letters are different in any name in sorne document.

(d) Schools shall not unnecessarily sends the parents to the Department, for making
amendments/correction in the online application forms. Rather, they should be taking a
decision based on genuineness/merit of the specific cases and must not deny admission on
unjustified frivolous ground.

(e) Admission is to be granted from the start of the Academic Session 2026-27 or.as soon as
possible so that children can join the'academic session on the very first day itself, हे

(f) The school shall not charge tuition fee from the students admitted under EWS/DG category.

(g) Schools are advised to hold introductory session for all parents together including the parents
of EWS/DG category children.

(h) The school must confirm details of the EWS/DG category successful candidates from the
supportive documents produced bythem. ੪ .

() Income certificate issued by the Competent Authority declaring the total annual family income

ਰਹ less than Rs.1,50,000/-is a valid document for admission under EWS category whether it is in
the name of mother or father or guardian of the child,

0) The school shall not ask for any income Certificate from the parents/ applicants who have been
selected under DG category.

(k) The school shall not impose the condition for the copies of the documents produced at the
time of admission to be attested by a Gazetted Officer. Self-Attested documents must be
accepted by the school.

(I) The school shall issué proper acknowledgement against the request of the parents/guardian
seeking admission in the school as declared in the computerized draw of lots.

(m) The school shall call all candidates allotted through computerized draw of lots on their
registered mobile number informing about the selection in the school and last date of
admission.

. _ (n) The school shall not refuse to grant admission to EWS/DG & CWSN category children on the
ground of distance range.

(0) The school shall give admission to the selected candidates in order of the Serial Number |
allotted to the candidate through computerized draw of lots and as available on the online
module.

(p) The school at the earliest shall update the correct admission gtatus as per the options available
on the web page of the respective schools (Admitted/provisionally Admitted/Not Reported/
Rejected/In waiting) in respect of the applicants allotted through computerized draw of lots.

26. Additional Instructions for all concerned: - ੨

(a) The school once allotted to the applicant through the computerized draw of lots shall not be
changed under any circumstances.

(b) The admission of the child shall be cancelled in case the documents submitted by the applicant
at the time of admission are found to be forged/fake or not supportive at any stage.

(c) Reimbursement of per child cost to the school will be made as per the provisions of RTE Act,
2009 and instructions issued by Chandigarh Administration from time to time.

27. List of Private Unaided Non-Minority Schools of UT Chandigarh that are required to take part in
the EWS/DG admission under this process is enclosed.

<!-- page 8 -->

‘ List of Unaided Recognized (Non-Minority) Schools for Admissions under
* EWS/DG Category for the session 2026-27
[੯ , Name of School
\Aanchal International School, Sector 41-D, Chandigarh

(Adarsh Bal Vidyapeeth, Behind Ayyappa Temple, Sector 47-C, Chandigarh
3 [Adarsh Public School, Near jama Masjid, Sector 20, Chandigarh
4 [Ankur School, Ankur School, PU Campus, Sector-14 Chandigarh है ਨ

__5 |Ashiana Public School, Sector 46 Chandigarh _ _ __

6 Bal Niketan Model Sr Sec School, Sector 37 -A, Chandigarh ee हि

7 Banyan Tree School, Sec-48-B, Chandigarh हि _

. 9 ___ [Bhavan Vidyalaya Junior, Sector 33 D, Chandigarh _ _ __ _ .

9 __|BMD Public School, Sector 63, Chandigarh ਦਾ ਦਾ ਦਾ? .

10 __|Chitkara Intemational School, Udyog Path, Sector 25 West, Chandigarh ___ _
[__i1 ICL Aggarwal DAV Model School, Sector 7B, Chandigarh || "
७12 एरए7फा०50100॥ 3600०7-8, छाशावक्ए0._............हफह़झ&£. SC~—<“CS~sSsSCS
| 13 __|D C Montessori Sr Sec School, Housing Board Complex, Sector 1 3, Chandigarh _ of

_14 [DAV Model School, Sector 15, Chandigarh __ के |

15 IDAV Public School, Sector 8 C, Chandigarh . ਗੱ

16 [00५ 70016 School, Sector-39d Chandigarh के _ है

_17 ___ [Delhi Public School, Sector 40-C, Chandigarh . है _

18 ___ [Divya Public School, Sector 44 D, Chandigath ੪ _

19 First Steps School, Sector-26, Chandigarh
Green Castle Public School, Sector 47-C, Chandigarh
Gurukul Global School, Sector-13, Manimajra-Chandigarh
(Gyandeep Model High School, Sector -20C Chandigarh है
Joyland Montessori S.D.S Public School Sector 38-C, Chandigarh .

KB DAV Centenary Public School, Sector 7-B, Chandigarh
25 Kundan International School, Sector 46 B, Chandigarh

‘
Modernways Model School, Sector 29, Chandigarh |
Northridge international school, sec 46 A, Chandigarh,
Paragon convent school, sector 24 B, chandigarh,

: Playway Smart School, Sector 37-A, Chandigarh,

P.M.L.S.D Public School, Sector 32 C, Chandigarh

36 IP.M.L.S.D Public School, Sector 19°C, Chandigarh

37 Police Public School, Sector-48 D, Chandigarh _ I

38 IRIMT World School, Sector 13, Manimajra, Chandigarh __ _

39 Saint Soldier International School, Sector 28 B, Chandigarh 3

40 Sanawar Montessori School, Sector -11 B, पक्ष _ __
| 41 Sharda sarvhitkari Model Sr Sec School, Sector 40D Chandigarh _ _ ___
42 |Shishu Niketan Model Sr Sec School, Sector 22-D, Chandigarh _ _
43 (Shishu Niketan Public School, Sector 43 A, Chandigarh _ _ ____
।___ 44 __ 80੪80 7੫00੦ 56੦01, 9੬੦ 41-9, Chandigarh _ ਸੀ __ _ 4
45 ___|ShKulwant Rai Sarvhitkari Vidya Mandir, Sec43B, Chandigarh हि
46° Sri Aurobindo School of Integral Education, sation, Sector 27 A Chandigarh _ ee
47 __|Sri Guru Gobind Singh Collegiate Public School, Sector 26, Chandigarh _
48 ~ (sti Guru Gobind Singh Public School, Sector 35-B, Chandigarh ___ - है
_49 St Kabir Public School, Sector-26, Chandigarh __ co
50 St Peters Sr. Sec. School, Sector 37 B, Chandigarh _ . ४०७०
51 Stepping Stones School, Sector 37-D, Chandigarh |
52 [Stepping Stones School, Sector 38 A, Chandigarh _
53 Strawberry Fields High School, Sector 26, Chandigarh
54 (Tender Heart High School, Sector 33 - B, Chandigarh ०
55 Sri Chaitanya Techno School, Sec 44-B Chandigarh (The British School, Sector- 44) gy “
[The Tribune School, Sector 29 D Chandigarh i Io |
ler
“U.T., Chandigarh on
- ae et
