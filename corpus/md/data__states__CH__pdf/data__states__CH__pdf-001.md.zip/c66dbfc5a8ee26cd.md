---
doc_id: "c66dbfc5a8ee26cd"
source_url: "https://griid.edu.in/sites/default/files/ORDER_1.pdf"
ministry: "Government Rehabilitation Institute for Intellectual Disabilities (GRIID), Chandigarh"
title: "ORDER- Liaison Officer SCs/STs, PwD & OBCs)."
date: ""
pages: 1
method: "tesseract:pan+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "5ec61e00ac09be18"
---

<!-- page 1 -->

GOVERNMENT REHABILITATION INSTITUTE FOR INTELLECTUAL
DISABILITIES (GRIID), SECTOR -31, CHANDIGARH
(0172-2637361, 2637349)
ORDER
In pursuance of Department of Personnel & Training O.M. No. ੫
43011/153/2010-Estt.(Res.) Dated 04.01.2013 and No. 36012/1/2020-Estt. (Res-Il)
dated 17.05.2022 issued by the Govt. of India, Ministry of Personnel, Public
Grievances & Pensions, Department of Personnel & Training, duly adopted by the
Department of Personnel, Chandigarh Administration vide Letter No. 28/22-1H(7)-
2022/8520 dated 01.06.2022 regarding nomination of a Liaison Officer for
enforcement of orders of reservation in posts and services of the Govt., and also
ensure compliance of Instructions, as contained in the Department of Personnel &
Training O.M. dated 04.01.2013, the Competent Authority has decided to designate
the following officers as Liaison Officer of this Institute to look after the matters or
reservations and other related issues for Scheduled Castes (SCs) Scheduled Tribes
(STs), Other Backward Classes (OBCs) and persons with Disability (PwD), as the
case may be with immediate effect:
Sr.No. | Name, Designation and contacts Category of persons
details of Liaison Officer
1. Sh. Anil Kumar, Special Educator (BMR) Scheduled Castes (SCs)
(Mobile 9803100924) Scheduled Tribes (STs),
and persons with
Disability (PwD;
2. Dr. M. Karuppasamy, Asst. Prof. in Special | Other Backward Classes ਹੇ
Education (MR/ID), Course Coordinator (OBCs) ੩
(HRD). ce
(Mobile 9865407772)
Dr. G. P. Thami, -
Dated, Chandigarh the Director,
08.10.2025 GRIID, Sector -31, a
Chandigarh. |
Endst. No. GRIID/Estt/229/2025/ S973 ~ $ Sate: 7 9 | hor 4
A copy is forwarded to the following for information & ne essary
action: vas
1) PS to Director, GRIID, Chandigarh. J
2h Steno to Joint Director, GRIID, Chandigarh. | ao
3. The Course Coordinator (HRD), GRIID-31, Chandigarh. —
4. The In charge, Clinic, GRIID-31, Chandigarh,
5, The Principal (School), GRIID-31, Chi garh. _
6. The Section Officer, GRIID-31, Chandigarh.
7 Superintendent (Estt.), P & A St RIID-31, Cl
8. Hostel Superintendent, 6010-33, na
भर Ms Mamta, Craft Instructor (Vocati
the request to upload the same on
Chd, ¢
10. Warden Aashreya Home, S
11. Officer/Official cone rned.
12. Master File. ic
————— ਆ.
