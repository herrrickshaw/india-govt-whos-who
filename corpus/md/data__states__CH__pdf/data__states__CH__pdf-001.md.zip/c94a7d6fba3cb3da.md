---
doc_id: "c94a7d6fba3cb3da"
source_url: "https://www.ccetdiploma.edu.in/assets/order/APF%20SUBMISSION%20DATE%20EXTENSION.PDF"
ministry: "Chandigarh College of Engineering and Technology (Diploma Wing)"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a8bc8d5df8a29bb8"
---

<!-- page 1 -->

THE PUNJAB STATE BOARD OF TECHNICAL
EDUCATION AND INDUSTRIAL TRAINING
ILOT N0. 1-A, SEC.36-A, CHANDIGARH PH. : 2615385, 2622584-85 FAX : 2660734

No:PSBlExaml2020l

Dated: o 8'0 6' )-e To

6q4

*
frirfrrruHLfs

fw:

ffiHaE )fl-3: grd)llfr tffi'

{tftrlr"{S/1rr$ zozo g }r$q fdsr

Srdd-r f# ItEqt b easd e Lfrd d pseruxaml2020t660 flrS 18.0s.2020 fi
6?rg..Egr f{s qfrfl?t'6EH dil6 fi n{S f{g t6 hOHd e-qr 6ifs f,i€r i n1
:

Dates for submission of
Examination forms and Fees
by the students to the
Institute and further online
submission of the data by the
institutes to the Board.

Without Late f'ee (All semester
courses and Annual courses)
With alate f'ee of * Rs. 1000/is per sem. / per year.
Very Late fee * Rs. 1500/- is per
sem/ per year.

Dates for deposition of fee by
the institute through online to
the Board's account at'Punjab

National Bank

to 11.06,202A

17.06.202A

12.06.2020 to 16,06.2020

18.06.2020

17 .06.2020 to 22.A6.2020

23.06.2020

19.05 .2020

--&r
EIHE-cfls

@

I

e-rids s g3r-dr td fuftrrz'd F€6r )?{3 }?ffr&et dEeEl p* 3ftzp fis t nt:
1.

2.
1

4.
5.

rra-:ertnrshs
u1.g /F{rd
$qr p-rn

tffia

3 )?.Rrfu {s6 fos)
a.n$?-d Hnil
r,frftpr1'Hrlil-t nfo Tilr Fil-fE-d
