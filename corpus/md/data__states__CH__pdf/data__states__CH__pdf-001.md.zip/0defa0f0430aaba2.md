---
doc_id: "0defa0f0430aaba2"
source_url: "https://www.library.puchd.ac.in/includes/tenders/2015/20150901123519-rewiringoffoundryworkshopinuietpanj.pdf"
ministry: "A. C. Joshi Library, Panjab University, Chandigarh"
title: "Rewiring of Foundry Workshop in UIET Panjab University South Campus, Sector -25 Chandigarh."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b9a202d924a30b3"
---

<!-- page 1 -->

P.U. CONSTRUCTION OFFICE, CHANDIGARH
(Electricity-Wing)
NOTICE INVITING QUOTATION
Sealed quotations on item rate basis are invited from the Contractors on the
approved list of P.W.D. Building and Roads Branch/Central P.W.D., M.E.S., Boards,
Corporations, HUDA, PUDA Institutions for the following works.
Sr.
No.

1

Estimated
Cost

Time
Limit

Rewiring of Foundry Workshop in UIET Panjab
Rs.49100/University South Campus, Sector -25 Chandigarh.

10 days

Name of work
C/H: “Running Repair & Maintenance etc.”

Conditions :1.
2.
3.
4.
5.
6.
7.

8.
9.
10.

The detailed Notice Inviting Quotation can be seen in the office of the
undersigned at any time during working hours.
Conditional Quotation will not be accepted.
Over-writing should be avoided.
No payment will be made for running bill amounting to less than Rs.1000/All applicable taxes as per Government norms will be deducted from the bill.
The quotations will be received in the office of S.D.E. (Elect.) till due date
08.09.2015 upto 05.00 p.m through Registered/Speed Post.
Panjab University does not take any responsibility for any postal delay in
delivery by Registered/ Speed Post or lost in transit of the quotation form. No
quotation will be entertained by hand.
Please mention Name of work and due date on the Envelope.
An ambiguous, conditional, telegraphic and telephonic Quotation shall be
liable to rejection.
The undersigned has right to reject any or all the quotations, without
assigning any reasons.

S.D.E. (Electrical)
P.U, Chandigarh.
