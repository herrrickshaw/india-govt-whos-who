---
doc_id: "a23c131b6adc7fdf"
source_url: "https://gandhianstudies.puchd.ac.in/includes/noticeboard/2025/20250818160441-guidelinesforfreshscstudentspmsschemeofpunjabstateforthesession2025-26.pdf?2026"
ministry: "Department of Gandhian and Peace Studies, Panjab University, Chandigarh"
title: "Guidelines for (Fresh) SC Students PMS Scheme of Punjab State,for the session 2025-26"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "94077e7ce5c80e9e"
---

<!-- page 1 -->

2025-2026
(FOR FRESH STUDENTS)
1. Eligibility Criteria:
1. The student must belong to SC category
2. He/she belong to Punjab state
3. The income of the family is not above 2.50 lac per annum.
2. Following points need to be taken care by SC student(s) at the time
of applying Post Matric Scholarship Scheme:
1.

The bank account of the student must be in active mode.
Dormant bank or parent bank account should not be used.

2.

Bank account number of the student must be linked with the
Aadhaar Number.

3.

Correct mobile number of the student must be quoted and
should not be used or attached with another bank account.

3. Required Documents:1.
2.
3.
4.
5.
6.
7.
8.
9.

PMS application form
Freeship card
Income Certificate in the name of parents/guardian (Photo-copy)
Residence Certificate (Photo-copy)
Caste Certificate in the name of the concerned student
(Photo-copy)
Student and parent’s aadhar card (Photo-copy)
10th class mark-sheet (Photo-copy)
Previous class mark-sheet (Photo-copy)
Undertaking/affidavit (Annexure-I)

4. Steps for applying PMS on Dr. Ambedkar Portal (Punjab)
(i) The fresh (newly admitted) eligible SC students of Punjab state
have to apply on the Dr. Ambedkar Scholarship Portal
(www.scholarships.punjab.gov.in) for free ship Card.
(ii) After approving the freeship card from the District Nodal Officer
of the concerned candidate has to fill online Post Matric
Scholarship form before the due date on the above said Portal,
which is mandatory for students who wish to avail the benefit
of reimbursement of claim.
Contd…p/2

<!-- page 2 -->

(FOR FRESH STUDENTS)
-2(iii) After filling the PMS, the eligible SC students have to submit the
copy of freeship card, Post Matric Scholarship form and required
documents mentioned above, in the department.
5. One Time Registration (OTR) Guidelines for Scholarships Hosted
on NSP:(i)

Mandatory Requirement: One Time Registration (OTR) is
mandatory for applying for various scholarship schemes on
National Scholarship Portal/other portals.

(ii)

Essential Requirement for OTR: Active mobile number is
mandatory for OTR.

(iii)

No payment of fee is required for OTR.

(iv)

Steps for Registration:



Once allotted an OTR, students can apply for scholarship later
when the portal is open for application submission.



Upon successful registration, a reference number will be sent on
the registered mobile number.



Download and install NSP OTR app and Aadhaar Face RD
services on android based devices.



Perform the Face-Authentication using the generated reference
number for OTR sent on your mobile no.



After successful Face-Authentication OTR will be generated.

(v)

Please apply for Scholarship using OTR. Merely generation of OTR
does not tantamount to application for scholarship.

(vi)

Aadhaar Requirement: Aadhaar is required for OTR. If Aadhaar
is not assigned, registration can be done using Enrolment ID
(EID) for Aadhaar. If a minor student has not been assigned
Aadhaar yet, registration can be done using Aadhaar of her
parent or legal guardian.

(vii) It is advised to update other relevant demographic records
(name, dob, gender) to match with Aadhaar/EID.

Contd…p/3

<!-- page 3 -->

(FOR FRESH STUDENTS)
-3(viii) Parents/legal guardians of minors applying with their Aadhaar
must ensure that while making an application for Aadhaar
enrolment of minors shall use the same demographic details (of
minor) as used in the OTR.
(ix) One OTR ID is allowed per student. However, parent/legal
guardian
can generate upto a maximum of two OTRs (for two
minor children).
(x)

In case more than one OTR is found for a student, she would be
liable for debarment from scholarships.

IMPORTANT NOTE:The fee would be reimbursed by the Social Welfare Department of
Punjab State directly into the bank account numbers of the eligible SC
students. It is the duty of the student to deposit receipt of the fee to
their respective department within a stipulated time as per undertaking
given by the candidate, failing which late fee would be charged as per
University norms

SC/ST Cell
Panjab University
Chandigarh
