---
doc_id: "aea598d63e3fddbd"
source_url: "https://chdanimalhusbandry.gov.in/pdf/Animaltransportrules.pdf"
ministry: "Animal Husbandry and Fisheries Department, Chandigarh"
title: "Animal transport Rules"
date: ""
pages: 26
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9faf196830f08039"
---

<!-- page 1 -->

The Transport of Animals Rules, 1978
the Transport of Animals Rules, 19781

1. Short title.—These rules may be called the Transport of Animals Rules, 1978.
2. Definitions.—In these rules, unless the context otherwise requires,—
(a) qualified veterinary surgeon means one who holds a diploma or a degree
of a recognised veterinary college;
(b) “Schedule” means a Schedule appended to these rules.

3. Rules 4 to 14 shall apply to the transport of dogs and cats of all
breeds whether by rail, road, inland waterway, sea or air.
4
(a) A valid health certificate by a qualified veterinary surgeon to the effect
that the dogs and cats are in a fit condition to travel by a rail, road, inland
waterway, sea or air and are not showing any sign of infectious or contagious
disease including rabies, shall accompany each consignment and the
certificate shall be in the form specified in Schedule A.
(b) In the absence of such a certificate, the carrier shall refuse to accept the
consignment for transport.
5 No dog or cat in an advanced stage of pregnancy shall be transported. --------(1) Vide Government of India, Ministry of Agriculture and Irrigation
(Department of Agriculture), Notification No. 18-6/70 LDI, dated 23rd March,
1978.
6
(a) Dogs or cats to be transported in the same container shall be of the same
species and breed.
(b) Unweaned puppies or kittens shall not be transported with adult dogs or
cats other than their dams.

<!-- page 2 -->

(c) No female dog or cat in season (cestrus) shall be transported with any
male.
7
(a) Any dog or cat reported to be vicious or exhibiting a vicious disposition
shall be transported individually in a cage, muzzeled and labelled to give
warning to handlers.
(b) In extreme cases, the dogs or cats shall be administered with sedative
drugs by a qualified veterinary surgeon.
8
(1) When dogs or cats are to be transported for long distances—
(a) they shall be fed and given water atleast two hours prior to their
transport and shall not be packed for transport if they are hungry or
thirsty;
(b) they should be exercised as late as possible before despatch;
(c) they shall be given adequate water for drinking every four hours in
summer or every six hours during winter;
(d) they shall be fed once in twelve hours in the case of adult dogs or cats
and they shall be fed once in four hours in the case of puppies and kittens
in accordance with the instructions of the consignors, if any;
(e) adequate arrangements shall be made for their care and management
during the journey.
(2) When the dogs or cats are to be transported by rail involving a journey of
more than six hours, an attendant shall accompany the dogs or cats to supply
them with food and water on the way and the attendant shall have access to
the dogs or cats for this purpose at all stations and no dog or cat shall be
exposed to the direct blast of air during such journey.
9 Where dogs or cats are to be transported for short distance by road in a
public vehicle, the following precautions are to be taken, namely:—
(a) They shall be put in a cage and the cage containing the dogs or cats shall
not be put on the roof of the vehicle but shall be put inside the vehicle
preferably near the end of the vehicle;

<!-- page 3 -->

(b) the vehicle transporting the dogs or cats shall as far as possible maintain
constant speed, avoiding sudden stops and reducing effects of shocks and
jolts to the minimum;
(c) atleast one attendant shall be present at all times during transit who shall
ensure that proper transit conditions are observed and shall also replenish
food and water whenever necessary.
10 Where dogs or cats are to be transported by air:—
(a) The cages shall be properly cleaned and disinfected before the dogs or
cats are put in the cages;
(b) sufficient paddy straw or saw dust or paper cuttings shall be provided for
cats in the cages as resting materials;
(c) for international transport, the dogs or cats shall be kept in a pressurized
compartment with regulated temperature.
11 The size and type of crates for transport of dogs and cats shall conform as
clearly as may be to the size and type specified in Schedule B and Schedule C
respectively.
12 All containers of dogs or cats shall be clearly labelled showing the names,
address and telephone number (if any) of the consignor.
13 The consignee shall be informed about the train or transport arrival or flight
number and its time of arrival in advance.
14 Consignment of dogs or cats to be transported by rail or road shall be
booked by the next passenger or mail train or bus and should not be detained
after accepting the consignment for booking.

15 Rules 16 to 23 shall apply to the transport of all types of
monkeys from the trapping area to the nearest rail-head.
16
(a) A valid health certificate by a qualified veterinary surgeon to the effect
that the monkeys are in a fit condition to travel from the trapping area to the

<!-- page 4 -->

nearest unit-head and are not showing any sign of infections or contagious
disease shall accompany each consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the
consignment for transport.
(c) The certificate shall be in a form specified in Schedule D.
17
(1) Monkeys from one trapping area shall not be allowed to mix with
monkeys from any other trapping area for preventing the dangers of
crossinfection.
(2) The time in transit from trapping area to the nearest rail-head shall be as
short as possible and factors causing stress to monkeys shall be reduced to
the minimum.
(3) If the travel time is longer than six hours provision shall be made to feed
and to give water to the monkeys enroute.
(4) During transit, precautions shall be taken to protect the monkeys from
extreme weather conditions and monkeys that die en route shall be removed
at the earliest available opportunity.
18 Monkeys that are not completely weaned, that is, under 1.8 kilogram in
weight, shall not be transported except when specifically permitted by the
Central Government.
19
(a) Pregnant and nursing monkeys shall not be transported except when
specifically permitted by the Central Government.
(b) Pregnant and nursing monkeys as well as monkeys weighing more than 5
kilograms shall be transported in compartmented cages.
20 All monkeys in the same cage shall be of the same species and of
approximately the same weight and size.
21 Monkeys captured within their natural habitat shall be placed in new,
sterilized or thoroughly cleaned cages and subsequent transfer, if any, shall
also be new, disinfected or thoroughly cleaned cages.

<!-- page 5 -->

22 Monkeys shall be transported from trapping area to the nearest rail-head
by the fastest means of transport available and the monkeys should not be left
un-attended at any time during the journey.
23
(1)
(a) Monkeys shall be transported in suitable wooden or bamboo cages so
constructed as not to allow the escape of the monkeys but permit
sufficient passage of air ventilation.
(b) No nails, metallic projections or sharp edges shall be exposed on the
exterior or in the interior of the cages.
(c) Each cage shall be equipped with appropriate water and feed
receptacles which are leak proof and capable of being cleaned and refilled
during transit.
(2) The floor of the cages shall be made of bamboo reapers and the space
between each reaper shall range between 20 mm and 30 mm.
(3) To facilitate carriage of these cages, provision may be made for rope loops
at the four top ends.
(4) The weight of any one loaded cage shall not exceed 45 kilograms.
(5) The following two sizes of cages shall be used.—
(a) 910 × 760 × 510 mm—to contain not more than twelve monkeys,
weighing between 1.8 and 3.00 kilograms each or ten monkeys weighing
between 3.1 and 5.0 kilograms each.
(b) 710 × 710 × 510 mm—to contain not more than ten monkeys weighing
between 1.8 and 3.00 kilograms each or eight monkeys weighing between
3.1 and 5.00 kilograms each:
Provided that wooden cages as specified in Schedule F to these rules may also
be used for carrying monkeys from the trapping area to the nearest rail-head.
(6) The construction details of two types of cages shall be given in Schedule E.

24 Rules 25 to 32 shall apply to transport of monkeys from a railhead to another rail-head or from a rail-head to nearest airport.

<!-- page 6 -->

25
(a) Loading and unloading shall be carried out quickly and efficiently.
(b) Cages shall be stored in such a manner that ventilation is adequate and
the monkeys are not exposed to draught and direct heat or cold.
(c) Monkeys found dead shall be removed as quickly as possible for suitable
disposal.
26 The transport cages shall be in accordance with specifications given in rule
28.
27
(1) Due provision shall be made by the sender for a sufficient supply or food
and water for the journey.
(2) In case the journey is over six hours an attendant shall accompany the
monkeys to supply them food, water, and such other things, on route and he
shall have access to the monkeys for feeding, giving water and attention at all
stations en route.
(3) The food and water containers shall be checked atleast every six hours
and refilled, if necessary.
(4) Monkeys shall not be disturbed during the night hours.
28 Not more than one cage shall be placed over the other and gunny packing
shall be placed between two cages, when one is placed over the other.
29 Monkeys shall be brought to the airport sufficiently early.
30 Monkeys shall be provided with food and water immediately before loading
on the aircraft.
31
(a) The cages shall be clearly labelled showing the name, address and
telephone number (if any) of the consignor and the consignee in bold red
letters.
(b) The consignee shall be informed about the train in which the consignment
of monkeys is being sent and its arrival time in advance.

<!-- page 7 -->

(c) The consignment of monkeys to be transported shall be booked by the
next passenger or mail train and should not be detained after the
consignment is accepted for booking.
32
(a) A valid health certificate by a qualified veterinary surgeon to the effect
that the monkeys are in a fit condition to travel from the nearest rail-head to
another rail-head or from a rail-head to the nearest airport and are not
showing any signs of infectious or contagious disease shall accompany each
consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the
consignment for transport.
(c) The certificate shall be in a form specified in Schedule D.

33 Rules 34 to 45 shall apply in relation to the transport of monkeys
by air.
34 The time in transit shall be as short as possible and factors causing stress to
monkeys shall be reduced to the minimum.
35 Monkeys that are not completely weaned, that is, under 1.8 kilograms in
weight, shall not be transported except when specifically permitted by the
Central Government.
36 Pregnant and nursing monkeys shall not be transported except when
specifically permitted by the Central Government. Pregnant and nursing
monkeys and monkeys weighing over 5 kilograms shall be transported in
specially designed individual cages.
37 All monkeys in the same cage shall be of the same species and of
approximately the same weight and size.
38
(1) In view of the danger of infection, only monkeys of the same species shall
be transported in the same cabin or compartment of the aircraft.

<!-- page 8 -->

(2) Apparently sick or disabled monkeys exhibiting external injuries or
infested with parasites shall not be transported.
(3) Transport of other species of animals, birds, fish, food stuff or poisonous
materials, such as pesticides and insecticides, in the same cabin or
compartment shall not be permitted.
39
(1) At no time during transit shall the monkeys be left unattended when
carried in a freighter aircraft.
(2) At least one attendant shall be present at all times when the aircraft is on
the ground
40
(1) Monkeys shall be transported in suitable wooden cages, so constructed as
not to allow the escape of the monkeys and shall allow sufficient passage of
air for ventilation; no nails, metallic projections or sharp edges shall be
exposed in the interior or on the exterior of such cages. Each cage shall be
equipped with water and food receptacles which shall be leak-proof and be
capable of being cleaned and refilled during transit. A suitable absorbent
material such as saw dust shall be kept in the dropping trays.
(2) The weight of any one loaded cage shall not exceed 45 kilograms in any
case.
(3) The following two sizes of cages shall be used:—
(a) 460 × 460 × 460 mm — to contain not more than ten monkeys weighing
from 1.8 to 3,0 kilograms each or four monkeys weighing from 3.1 to 5.0
kilograms each; and
(b) 760 × 530 × 460 mm to contain not more than ten monkeys weighing
from 1.8 to 3.0 kilograms each or eight monkeys weighing from 3.1 to 5.0
kilograms each.
(4) The construction details of the two types of cages shall be as given in
Schedule F.
(5) The construction details of the two types of cages used for the transport
of pregnant and nursing monkeys shall be as given in Schedule G.

<!-- page 9 -->

41
(a) The cages shall be clearly labelled showing the name, address and
telephone number (if any) of the consignor and the consignee in bold red
letters.
(b) The consignee shall be informed in advance about the flight number of the
freighter aircraft in which the consignment of monkeys is being sent and its
arrival time.
(c) The consignment of monkeys to be transported shall be booked by the
next flight of the freighter aircraft and should not be detained after the
consignment is accepted for booking.
42
(1) A valid health certificate by a qualified veterinary surgeon to the effect
that the monkeys are fit to travel by air and are not showing any signs of
infectious or contagious disease shall accompany each consignment of
monkeys.
(2) In the absence of such a certificate, the carrier shall refuse to accept the
consignment for shipment.
(3) The form of a certificate under sub-rule (1) be as given in Schedule D.
43
(1) The air shall be changed not less than twelve times per hour and draughts
shall be avoided and there shall be no dead pockets of air.
(2) Except when the monkeys are being fed and given water, they shall travel
in semi-darkness to make them quieter and less inclined to fight and thus
given them better opportunities of resting.
44 The food and water containers shall be checked at every stop and refilled; if
necessary, and a sufficient stock of food shall be available on the aircraft and at
likely stopping places. Note. —About 85 grams of food per monkey is required
daily. Suitable foods are dry cereal grains or gram. It is recommended that
whole gram made into biscuits or wheat meal bread should be fed. A minimum
of 140 ml. of water shall be allowed for each monkey per day.

<!-- page 10 -->

45 An empty cage of the usual dimensions with its sides covered except 50 mm
at the top to allow for ventilation shall be provided in the freighter aircraft for
housing the monkeys which fall sick or are injured during the journey.

46 Rules 47 to 56 shall apply to the transport by rail or of cows,
bulls, bullocks buffaloes, yaks and calves (hereinafter in these rules
referred to as ‘cattle’.
47
(a) A valid certificate by a qualified veterinary surgeon to the effect that the
cattle are in a fit condition to travel by rail or road and are not suffering from
any infectious or contagious or parasitic diseases and that they have been
vaccinated against rinderpest and any other infectious or contagious or
parasitic diseases shall accompany each consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the
consignment for transport.
(c) The certificate shall be in the form specified in Schedule E.
48 Veterinary first-aid equipment shall accompany all batches of cattle.
49
(a) Each consignment shall bear a label showing in bold red letters the name,
address and telephone number (if any) of the consignor and consignee, the
number and types of cattle being transported and quantity of rations and
food provided.
(b) The consignee shall be informed about the train or vehicle in which the
consignment of cattle is being sent and its arrival time in advance.
(c) The consignment of cattle shall be booked by the next train or vehicle and
shall not be detained after the consignment is accepted for booking.
51
(a) Suitable rope and platforms should be used for loading cattle from
vehicles.

<!-- page 11 -->

(b) In case of railway wagon the dropped door of the wagon may be used as a
ramp when loading or unloading is done to the platform.
52 Cattle shall be loaded after they are properly fed and given water.
53 Cattle in advanced stage of pregnancy shall not be mixed with young cattle
in order to avoid stampede during transportation.
54
(1) Watering arrangements on route shall be made and sufficient quantities
of water shall be carried for emergency.
(2) Sufficient feed and fodder with adequate reserve shall be carried to last
during the journey.
(3) Adequate ventilation shall be ensured.
55 When cattle is to be transported by rail.—
(a) an ordinary goods wagon shall carry not more than ten adult cattle or
fifteen calves on broad gauge, not more than six adult cattle or ten calves on
metre gauge, or not more than four adult cattle or six calves on narrow
gauge;
(b) every wagon carrying cattle shall have atleast one attendant;
(c) cattle shall be loaded parallel to the rails, facing each other;
(d) rations for padding, such as straw, shall be placed on the floor to avoid
injury if a cattle lies down and this shall not be less than 6 cms thick;
(e) rations for the journey shall be carried in the middle of the wagon;
(f) to provide adequate ventilation, upper door of one side of the wagon shall
be kept open properly fixed and the upper door of the wagon shall have wire
gauge closely welded mesh arrangements to prevent burning cinders from
the engines entering the wagon and leading to fire outbreak;
56 When cattle are to be transported by goods vehicle the following
precautions are to be taken, namely:—
(a) specially fitted goods vehicles with a special type of tail board on padding
around the sides should be used;

<!-- page 12 -->

(b) ordinary goods vehicles shall be provided with anti-slipping material, such
as coir matting or wooden board on the floor and the superstructure, if low,
should be raised;
(c) no goods vehicle shall carry more than six cattle;
(d) each goods vehicle shall be provided with one attendant;
(e) while transporting the cattle, the goods vehicle shall not be loaded with
any other merchandise; and
(f) to prevent cattle being frightened or injured, they should preferably face
the engine.

57 Rules 57 to 63 shall apply to the transport by rail, road or sea of
horses, mules and donkeys (hereinafter in these rules referred to as
‘equines’).
58
(a) A valid certificate by a qualified veterinary surgeon to the effect that the
equines are in a fit condition to travel by rail; road or sea and are not
suffering from any infectious contagious disease or diseases shall accompany
each consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the
consignment for transport.
(c) The certificate shall be in a form specified in Schedule 1.
59
(a) Each consignment shall bear a lable showing in bold red letters the name,
address and telephone number (if any) of the consignor and consignee, the
number and type of equines being transported and quantity of rations and
food provided.
(b) The consignee shall be informed in advance about the train or vehicle or
ship in which the consignment of equines is being sent and its arrival time.
(c) The consignment of equines shall be booked by the next train or vehicle or
ship and shall be accepted for booking.

<!-- page 13 -->

60
(a) Pregnant and young equines shall not be mixed with other animals.
(b) Different species of equines shall be kept separately.
(c) Equines shall be loaded after being fed and given water adequately,
watering arrangements shall be made en route and sufficient food carried to
last during the journey.
(d) Veterinary first-aid equipment shall accompany all batches of equines.
(e) Adequate ventilation shall be ensured.
(f) Suitable ramps and platforms, improvised where not available, shall be
used for loading and unloading equines.
61 For the transport of equines by rail, the following precautions shall be
taken:—
(a) equines shall be transported by passenger or mixed trains only;
(b) ordinary goods wagon when used for transportation shall carry not more
then eight to ten horses or ten mules or ten donkeys on broad gauge and not
more than six horses or eight donkeys on metre-gauge;
(c) in extreme hot water shall be sprinkled over the wagons containing
equines by the railway authorities to bring down temperature. Ice slabs in
specially made containers may be placed inside the wagon, if recommended
by a qualified veterinary surgeon;
(d) every wagon shall have two attendants if the equines are more than two
in number;
(e) equines shall be loaded parallel to the rails, facing each other;
(f) material for padding, such as paddy straw, shall be placed on the floor to
avoid injury if an animal lies down and this shall not be less than 6 cm thick;
(g) to provide adequate ventilation, upper door of the side of the wagon shall
be kept upon and properly fixed and the upper door of the wagon shall have
wire gauge closely welded mesh arrangements to prevent burning cinders
from the engines entering the wagon and leading to fire break out;
(h) two breast bars shall be provided on each side of the wagon, one at a
height of 50 to 80 cm and the other at 110 cm.

<!-- page 14 -->

63 For the transport of equines by sea the following precautions shall be taken,
namely:—
(a) horses may normally be accommodated in single stalls and mules in pens,
each pen holding four to five mules;
(b) ample ventilation shall be ensured by keeping portholes and providing
permanent air trunks or electric blowers on all decks, and exhaust fans shall
be installed to blow out foul air;
(c) all standings shall be artwart the ship with heads facing inwards;
(d) to avoid distress specially during hot weather, the ship may go under way
immediately after embarking and disembarking shall be done as early as
possible after enchoring;
(e) colts and fillies shall be kept on the exposed decks;
(f) a pharmacy and spare stalls for five per cent of equines shall be available;
(g) passage between two rows of pens shall not be less than 1.5 metres.

64 Rules 65 to 75 shall apply to the transport of sheep and goats by
rail or road involving journeys of more than six hours.
65
(a) A valid health certificate by a qualified veterinary surgeon to the effect
that the sheep and goats are in a fit condition to travel by rail or road and are
not suffering from infectious or contagious or parasitic disease shall
accompany each consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the
consignment for transport.
(c) The certificate shall be in a form specified in Schedule J.
66
(a) Each consignment shall bear a label showing in bold red letter the name,
address and telephone number (if any) of the consignor and consignee, the
number and type of sheep or goats being transported and quantity of rations
and food provided.

<!-- page 15 -->

(b) The consignee shall be informed in advance about the train or vehicle in
which the consignment of sheep or goats are being sent and its arrival time.
(c) The consignment of sheep or goats shall be booked by the next train or
vehicle and shall not be detained after the consignment is accepted for
booking.
67
(a) First-aid equipment shall accompany the sheep or goats in transit.
(b) Suitable ramps shall be provided for loading and unloading the sheep or
goats.
(c) In the case of a railway wagon, when the loading or unloading is done on
the platform the dropped door of the wagon shall be used as a ramp.
68 Sheep and goats shall be transported separately; but if the lots are small
special partition shall be provided to separate them.
69 Rams and male young stock shall not be mixed with female stock in the
same compartment.
70 Sufficient food and fodder shall be carried to last during the journey and
watering facility shall be provided at regular intervals.
71 Material for padding, such as straw, shall be placed on the floor to avoid
injury if an animal lies down, and this shall be not less than 5 cm thick.
72 The animals shall not be fettered unless there is a risk of their jumping out
and their legs shall not be tied down.
75
(1) Goods vehicles of capacity of 5 or 4.5 tons, which are generally used for
transporting animals, shall carry not more than forty sheep or goats.
(2) In the case of large goods vehicles and wagons, partition shall be provided
at every two or three metres across the width to prevent the crowding and
trapping of sheep and goats.
(3) In the case of ewes, goats or lambs or kids under six weeks of age,
separate panels shall be provided.

<!-- page 16 -->

1 [ 76 Definitions. —In this Chapter, unless the context otherwise
requires, “Poultry” includes day old chicks and turkey poults,
chickens, quails, guinea fowls, ducks, geese and turkeys. ]
2 [ 77 General requirement. —In transport of poultry by rail, road or air—
(a) the containers shall be properly cleaned and sterilised before the poultry
is placed in them;
(b) poultry shall not be exposed to the sunlight, rain and direct blast of air
during transport;
(c) poultry shall not be transported when the temperature exceeds 25 degree
Celsius or when the temperature falls below 15 degree Celsius.]

3 [ 78 Day-old chicks and turkey poults. —In transport of day old
chicks and poultry by rail, road and air—
(a) Chicks and poults shall be packed and dispatched immediately after
hatching and shall not be stored in boxes for any length of time before
dispatch. Note: In the said transport endeavour shall be made by the
consignor or his agent so that consignments shall arrive at destination within
the shortest possible time after being taken out of the incubator. Seventytwo hours shall normally be regarded as the maximum period to be taken
from incubator to brooder in winter and 48 hours in summer;
(b) chicks or poults shall not be fed or watered before and during
transportation;
(c) every effort shall be made to ensure that chicks and poults arrive as
quickly as possible at the dispatching site;
(d) personal attention shall be given by the consignor or the forwarding agent
to ensure that all consignments are kept out of direct sunlight, rain and heat;
(e) care shall be taken to carry the boxes in a level position so that chicks are
not in danger of falling over on to their backs and the putting up of other
merchandise over and around chick boxes shall be avoided.]

<!-- page 17 -->

4 [ 79 Poultry other than day-old chicks and turkey poults. —In
transport of poultry other than day old chicks and turkey poult by
rail, road or air—
(a) the poultry to be transported shall be healthy and in good condition and
shall be examined and certified by a veterinary doctor for freedom from
infectious diseases and fitness to undertake the journey;
(b) poultry transported in the same container shall be of the same species
and of the same age group;
(c) poultry shall be properly fed and watered before it is placed in containers
for transportation and extra feed and water shall be provided in suitable
troughs fixed in the containers;
(d) arrangements shall be made for watering and feeding during
transportation and during hot weather, watering shall be ensured every six
hours;
(e) male stock shall not be transported with female stock in the same
container. ]

5 [ 80 Road Travel. —In transport of poultry by road the container
shall not be placed one on the top of the other and shall be covered
properly in order to provide light, ventilation and to protect from
rain, heat and cold air. ]
6 [ 81 Rail Travel. —In transport of poultry by rail,—
(a) in case the journey is for more than twelve hours, an attendant shall
accompany the consignment;
(b) poultry shall not be exposed to rain or direct blast of air;
(c) as far as possible poultry shall be transported in wagons having adequate
facilities for ventilation and no other merchandise which may result in
mortality of birds shall be loaded in the same wagon. ]

7 [ 82 Air travel. —In transport of poultry by air or for international
transport the containers carrying poultry shall be kept near the
door and shall be unloaded immediately on arrival. ]

<!-- page 18 -->

8 [ 84 Special requirement of containers for chicks and poults. —In
transport of poultry by road, rail or air,—
(a) wire mesh or a net of any material shall not be used as a bottom for the
containers;
(b) the container shall be properly secured to avoid pilferage;
(c) the following instruction shall be printed on a label and fixed to the lid or
printed directly on sides, namely “Care in Transit”;
(d) the consignee shall be informed about the train, transport or flight
number and its time of arrival well in advance;
(e) poultry shall not be transported continuously for more than 6 hours and
whole batch shall be inspected at every 6 hours interval;
(f) the transportation shall not remain stationary for more than 30 min and
during this period, it shall be parked in shade and arrangements shall be
made for feeding and watering;
(g) all precautions against fire shall be taken and provision of fire
extinguishers in transport shall be provided.]

9 [ 85 Definition. —In this chapter, unless context otherwise
requires, “pigs” includes piglets, hogs, hoglets and animals of pigs
family.]
10 [ 86 Duration of travel. —Rules 87 to 95 shall apply to the
transport of pigs by rail or road involving journeys of more than six
hours.]
11 [ 87 Health Certificate. —
(1) A valid health certificate by a veterinary doctor to the effect that the pigs
are in a fit condition to travel by rail or road and are not suffering from
infectious or contagious or parasitic disease shall accompany each
consignment in the transport of pigs by rail or road.
(2) In the absence of a certificate under sub-rule (1), the carrier shall refuse to
accept the consignment for transport.

<!-- page 19 -->

(3) The certificate under sub-rule (1) shall be in a form specified in Schedule
K.]
12 [ 88 Identification of consignor and consignee. —For the purpose of this
Chapter—
(a) each consignment shall bear a label showing in bold red letters the name,
address and telephone number (if any) of the consignor and consignee, the
number and type of pigs being transported and quantity of rations and food
provided to them;
(b) the consignee shall be informed in advance about the train or vehicle in
which the consignment of pigs is being sent and its arrival time;
(c) the consignment of pigs shall be booked by the next train or vehicle and
shall not be detained after the consignment is accepted for booking. ]
13 [ 89 First aid. —In transport of pigs by rail or road—
(a) first-aid equipment shall accompany the pigs;
(b) suitable ramps shall be provided for loading and unloading the pigs;
(c) in the case of a railway wagon, when the loading or unloading is done on
the platform the dropped door of the wagon shall be used as a ramp. ]

14 [ 90 Group of pigs. —In transport of pigs by rail or road, male
young stock shall not be mixed with female stock in the same
compartment. ]
15 [ 91 Facility of food and water. —In transport of pigs by rail or road,
sufficient food and fodder shall be carried to last during the journey and
watering facility shall be provided at regular intervals. ]
16 [ 92 Padding of floor during travel. —In transport of pigs by rail or road,
material for padding, such as straw, shall be placed on the floor to avoid injury
if an animal lies down, and this shall be not less than 5 cm thick. ]
17 [ 93 Ban on fettering. —In transport of pigs by rail or road, the animals shall
not be fettered unless there is a risk of their jumping out and their legs shall
not be tied down. ]

<!-- page 20 -->

18 [ 96 Issue of certificate before transportation. —
(1) A valid certificate issued by an officer or any person or Animal Welfare
Organisation duly recognised and authorised for this purpose by the Animal
Welfare Board of India or the Central Government shall be procured by any
person making transport of any animal before transportation of such animal
verifying that all the relevant Central and State Acts, rules and orders
pertaining to the said animals including the rules relating to transport of such
animals have been duly complied with and that the animal is not being
transported for any purpose contrary to the provision of any law.
(2) In the absence of such certificate, the carrier shall refuse to accept the
consignment for transport. ] Explanation.— For the purpose of this rule the
certificate shall be issued in such form as may be specified for this purpose by
the Central Government. ]

19 [ 97 Cancellation of permit or authorisation for transport. —
(1) In the event of contravention or non-compliance of any of the rules
contained in these rule for transport of animals, if it is pointed out in writing
by any officer or persons or Animal Welfare Organisation authorised for this
purpose by the Animal Welfare Board of India or the Central Government,
then, any permit or authorisation issued for such transport shall be
immediately cancelled by the concerned authority and it shall be the duty of
the police to stop the further transport even from the intermediary station
and proceed against the said offenders and deal with the animal in
accordance with law.
(2) The custody of the animals immediately after unloading from the rail
wagons, truck or any other vehicle shall be given to the authorised Animal
Welfare Organisation if available, till the competent authority or the
Magistrate having jurisdiction decides about their care and upkeep.]

20 [ 98 General conditions of transport. —
(1) Animals to be transported shall be healthy and in good condition and such
animals shall be examined by a veterinary doctor for freedom from infectious
diseases and their fitness to undertake the journey; provided that the nature
and duration of the proposed journey shall be taken into account while
deciding upon the degree of fitness.

<!-- page 21 -->

(2) An animal which is unfit for transport shall not be transported and the
animals who are new born, diseased, blind emaciated, lame, fatigued or
having given birth during the preceding seventy-two hours or likely to give
birth during transport shall not be transported.
(3) Pregnant and very young animals shall not be mixed with other animals
during transport.
(4) Different classes of animals shall be kept separately during transport.
(5) Diseased animal, whenever transported for treatment, shall not be mixed
with other animals.
(6) Troublesome animals shall be given tranquilisers before loading during
transport.
(7) Animals shall be transported in their on-farm social groups (established
atleast one week prior to journey).]
The Transport of Animals Rules, 1978 SCHEDULE A (See rule 4) Proforma for
certificate of fitness to Travel Dogs/Cats This Certificate should be completed
and signed by a qualified Veterinary Surgeon. Date and time of
examination................................................................................ Species of
dogs/cats........................................................................................................
Number of cages.......................................Number of
dogs/cats.............................. Sex
..............................................................Age...........................................................
. Breed and identification marks, if any
...................................................................... Transported from
.........................................to..............................via ...................... I hereby certify
that I have read rules 8 to 14 in Chapter II of the Transport of Animals Rules,
1978. 1. That, at the request of (consignor)
............................................................... I have examined the above mentioned
dogs/cats in their travelling cages not more than 12 hours before their
departure. 2. That each of the dogs/cats appeared to be in good health, free
from signs of injury, contagious and infectious disease including rabies and in a
fit condition to travel by rail/road/inland waterway/sea/air. 3. That the
dogs/cats were adequately fed and watered for the purpose of the journey. 4.
That the dogs/cats have been vaccinated. (a) Type of vaccine/s: (b) Date of
vaccination/s: Signed.........................................

<!-- page 22 -->

Address........................................ Date.........................
Qualifications........................................ The Transport of Animals Rules, 1978
SCHEDULE B (See rule 11) Size and Type of Crate for Transport of Dogs The
design of the cage mentioned in rule 11 in Chapter II of Transport of Animal
Rules, 1978 shall be as per the design as printed on page 7 of IS: 4746-1968
published by the Indian Standards Institution. All dimensions in Centimetres By
rail/road/inland waterway/sea, by air Length (L) A × 1½ A + C + 10 Width (W) A
D + 2 + 10 Height (H) B + 15 B + 10 Length—Tip of nose to root of tail (A)
Width—Width across the shoulders (D) Height—Tip of ears to toe while
standing (B) Elbow Size—Toe to tip of elbow (C) Note.—Cages, cartons or
crates, used to transport dogs, shall be of such material which will not tear or
crumble. They shall be well constructed, well ventilated and designed to
protect the health of the dogs by giving them adequate space and safety. It is
essential that wire mesh should be nose and paw proof; suitable material is a
welded wire mesh of not less than 3 mm, with a spacing 12×12 mm. Expended
metal and wire netting are unsuitable for this purpose. There should be no
protruding nails or unprotected edges of wire. Dogs Kennels in rail coaches
shall be so placed as to give protection to dogs from extreme of temperature
and disturbance from birds and by giving them adequate space for health and
safety. The Transport of Animals Rules, 1978 SCHEDULE C (See rule 11) SIZE
AND TYPE OF CRATE FOR TRANSPORT OF CATS The design of the cage
mentioned in rule 11 in Chapter II of Transport of Animals Rules, 1978 shall be
as per the design as printed on page 8 of IS: 4746-1968 published by the Indian
Standards Institution. All dimensions in Centimetres By rail/road/inland water
way/sea by air Length (L) A × 2 A × 2 Width (W) A A Height (H) B + 15 B + 10
Length—Tip of nose to root of tail (A) Width—Width across the shoulders (D)
Height—Tip of ears to toe while standing (B) Elbow Size—Toe to tip of elbow
(C) Note.—Cages, cartons or crates, used to transport cats, shall be of such
material which will not tear or crumble. They shall be well constructed, well
ventilated and designed to protect the health of the cats by giving them
adequate space and safety. It is essential that wire mesh should be nose and
paw proof; suitable material is a welded wire mesh of not less than 3 mm, with
a spacing 12x12 mm. Expended metal and wire netting are unsuitable for this
purpose. There should be no protruding nails or unprotected edges of wire.
Cats Kennels in rail coaches shall be so placed as to give protection to cats from
extremes of temperature and disturbance from birds and by giving them
adequate space for health and safety. The Transport of Animals Rules, 1978

<!-- page 23 -->

SCHEDULE D (See rules 16 and 32) PROFORMA FOR CERTIFICATE OF FITNESS
TO TRAVEL MONKEYS This Certificate should be completed and signed by a
qualified Veterinary Surgeon. Date and time of examination
................................................................................. Species of Monkeys
...................................................................................................... Number of
Cages ..........................................................................................................
Number of Monkeys
......................................................................................................
Sex....................................................................Age
...................................................... Breed and identification marks, if any
.......................................................................... Transported from
............................to ..................................via................................. I hereby
certify that I have read rules 15 to 45 in Chapter III of the Transport of Animals
Rules, 1978. 1. That, at the request of (consignor)
...................................................... I examined the above mentioned monkeys in
their travelling cages not more than 12 hours before their departure. 2. That
each monkey appeared to be in a fit condition to travel from the trapping area
to the nearest rail-head/from the nearest rail-head to another rail-head/from
the rail-head to the nearest airport/by air and is not showing any signs of
infectious or contagious diseases. 3. That no monkeys appeared to be under 6
months of age and that no animal appeared to be pregnant. 4. That the
monkeys were adequately fed and watered for the purpose of the journey. 5.
That the monkeys have been vaccinated. (a) Type of vaccine/s: (b) Date of
vaccination/s: Signed.........................................
Address........................................ Date.........................
Qualifications........................................ The Transport of Animals Rules, 1978
SCHEDULE E [See rule 23(5)(a) and rule 23(6)] SIZE AND TYPE OF CRATE FOR
TRANSPORT OF MONKEYS FROM TRAPPING AREA TO NEAREST RAIL-HEAD The
construction detail of two types of cages mentioned in rule 22(5)(a) in Chapter
III of the Transport of Animals Rules, 1978 shall be as per the dimensions and
design as printed on page 5 of IS: 3699 (Part-I)—1966 published by Indian
Standard Institution. The Transport of Animals Rules, 1978 SCHEDULE F [See
rule 40(4)] SIZE AND TYPE OF CRATE FOR TRANSPORT OF MONKEYS BY AIR The
construction details of the two types of cages mentioned in rule 40(3)(a) and
(b) in Chapter III of Transport of Animal Rules, 1978 shall be as per the
dimensions and design as printed on page 6 of IS: 3059—1965 published by
Indian Standards Institution. The Transport of Animals Rules, 1978 SCHEDULE G

<!-- page 24 -->

[See rule 40(5)] Size and types of crate for transport by air of pregnant and
nursing monkeys and monkeys weighing over 5 kg The construction details of
the two type of cages mentioned in rule 40(5) in Chapter III of Transport of
Animal Rules, 1978 shall be as per the dimensions and design as printed on
page 7 of IS: 3059—1965 published by Indian Standards Institution. The
Transport of Animals Rules, 1978 SCHEDULE H (See rule 47) proforma for
certificate of fitness to travel cattle This Certificate should be completed and
signed by a qualified Veterinary Surgeon. Date and time of
examination.................................................................................... Species of
Cattle .........................................................................................................
Number of Trucks/Railway Wagons
.............................................................................. Number of Cattle
......................................................................................................... Sex
...................................................................... Age .........................................
Breed and identification marks, if any
......................................................................... Transported from
.....................................to ................................via ......................... I hereby
certify that I have read rules 46 to 56 in Chapter IV of the Transport of Animals
Rules, 1978, 1. That, at the request of (consignor)
........................................................ I examined the above mentioned cattle in
the goods vehicle/railway wagons not more than 12 hours before their
departure. 2. That each cattle appeared to be in a fit condition to travel by
rail/road and is not showing any signs of infectious or contagious or parasitic
disease and that it has been vaccinated against rinderpest and any other
infectious or contagious or parasitic disease(s). 3. That the cattle were
adequately fed and watered for the purpose of the journey. 4. That the cattle
have been vaccinated. (a) Type of vaccine: (b) Date of vaccination:
Signed.......................................... Address..........................................
Date.......................... Qualifications......................................... The Transport of
Animals Rules, 1978 SCHEDULE I proforma for certificate of fitness to travel
equines (See rule 58) This Certificate should be completed and signed by a
qualified Veterinary Surgeon. Date and time of examination
.............................................................................. Species of Equines
...................................................................................................... Number of
Equines ....................................................................................................... Sex
...................................................................... Age ................................................
Breed and identification marks, if any

<!-- page 25 -->

.......................................................................... Transported from
.....................................to ................................via .......................... I hereby
certify that I have read rules 57 to 63 in Chapter V of the Transport of Animals
Rules, 1978, 1. That, at the request of (consignor)
........................................................ I examined the above mentioned equines
not more than 12 hours before their departure. 2. That each equine appeared
to be in a fit condition to travel by rail/road/sea and is not showing any signs of
infectious or contagious disease(s) and that it has been vaccinated against any
infectious or contagious disease(s). 3. That the equines were adequately fed
and watered for the purpose of the journey. 4. That the equines have been
vaccinated. (a) Type of vaccine(s): (b) Date of vaccination:
Signed......................................... Address........................................
Date......................... Qualifications........................................ The Transport of
Animals Rules, 1978 SCHEDULE J proforma for certificate of fitness to travel
sheep and goats (See rule 65) This Certificate should be completed and signed
by a qualified Veterinary Surgeon. Date and time of examination
...................................................................................... Species of Animals
...................................................................................................... Number of
Animals ...................................................................................................... Sex
...................................................................... Age ................................................
I hereby certify that I have read rules 64 to 75 in Chapter V of the Transport of
Animals Rules, 1978. 1. That, at the request of (consignor)
........................................................ I examined the above mentioned animals
not more than 12 hours before their departure. 2. That each appeared to be in
a fit condition to travel by rail/road/sea and is not showing any signs of
infectious or contagious or parasitic disease(s) and that it has been vaccinated
against any infectious or contagious disease (s). 3. That the animals were
adequately fed and watered for the purpose of the journey. 4. That the
animals have been vaccinated. (a) Type of vaccine(s): (b) Date of vaccination:
Signed......................................... Address........................................
Date......................... Qualifications........................................ The Transport of
Animals Rules, 1978 1[ SCHEDULE K [ See rule 87(3)] PROFORMA FOR
CERTIFICATE OF FITNESS TO TRAVEL PIGS (This certificate should be completed
and signed by a Veterinary doctor.) Date and time of
examination............................................................................................. Species
of Animals
................................................................................................................

<!-- page 26 -->

Sex..........................................................................................................................
..................
Age.........................................................................................................................
.................. I hereby certify that I have read Rules 86 to 95 in Chapter VIII of the
Transport of Animals Rules, 1978. 1. That, at the request of
(consignor)....................... I examined the above mentioned animals not more
than 12 hours before their departure. 2. That each appeared to be in a fit
condition to travel by rail/road/sea and is not showing any signs of any
infectious or contagious or parasitic disease(s) and that it has been vaccinated
against any infectious or contagious disease(s). 3. That the animals were
adequately fed and watered for the purpose of the journey. 4. That the
animals have been vaccinated. (a) Type of vaccine(s): (b) Date of vaccination:
Signed......................................... Address........................................
Date......................... Qualifications.........................................
