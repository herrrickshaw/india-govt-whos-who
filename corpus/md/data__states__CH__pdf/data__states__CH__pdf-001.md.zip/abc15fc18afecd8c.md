---
doc_id: "abc15fc18afecd8c"
source_url: "https://citcochandigarh.com/pdf/CMSTender10.07.25.pdf"
ministry: "Chandigarh Industrial and Tourism Development Corporation (CITCO) - Luxury Hotels in Chandigarh"
title: ""
date: ""
pages: 36
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "409b38c5dd24877f"
---

<!-- page 1 -->

CHANDIGARH INDUSTRIAL & TOURISM
DEVELOPMENT CORPORATION LTD.
Table of contents
1. Acronyms

2

2. Bid Data Sheet

3

3. Introduction

4

4. Scope of Work

5

5. Role and Responsibilities

9

5.1 Bank
5.2 CITCO
6. Qualification Extension for bidders

12

7. General Instructions for bid process

14

8. Bid Instructions & Conditions

17

9. Bid Evaluation Process

21

10. Service Level Agreements

26

11. Annexures
11.1 Annexure I-List of existing Units

27

11.2 Annexure II-Transaction volumes AND

28

11.2 Reconciliation Reports

28

11.3 Annexure III-Format for Qualification Bid Letter

29

11.4 Annexure IV-Format for Technical Bid Letter

30

11.5 Annexure V-Format for Citations

31

11.6 Annexure VI-e-Tendering Guidelines

32

11.7 Annexure VII- Indicative checklist

33

11.8 Pre-Qualification Assessment

34

11.9 Technical Criteria

35

1

<!-- page 2 -->

Acronyms
Term

Explanation

AMC

Annual Maintenance Cost

BACS

Bankers’ Automated Clearing Services

BBPS

Bharat Bill Payment System

CA

Chandigarh Administration

CMS

Cash Management System

CV

Curriculum Vitae

DD

Demand Draft

DDI

Direct Debit Instruction

CITCO

Chandigarh Industrial & Tourism Development Corporation Ltd.

EMD

Earnest Money Deposit

EOI

Expression of Interest

GBPS

Giga Bits Per Second

GST

Goods and Service Tax

H/W

Hardware

INR

Indian Rupees

ISO

International Organization for Standards

ITSM

IT Service Management

IVR

Interactive Voice Recording

MDR

Merchant Discount Rate

PBG

Performance Bank Guarantee

SLA

Service Level Agreement

SMS

Short Service Messaging

SSL

Secure Sockets Layer

Tricity

Chandigarh, Mohali and Panchkula

UDIN

Unique Document Identification Number

VAT

Value Added Tax
2

<!-- page 3 -->

2. Bid Data Sheet
Event

Target Date

EMD

INR Rs.10.00 Lakh (Rupees Ten
Lakh Only)

Availability of Request for Proposal

Website https://etenders.chd.nic.in

Last Date to send in requests for
clarification on the RFP

18.07.2025

Date and time for Pre-Bid Conference 22.07.2025 at 11:00 A.M.
Venue for Pre-Bid Conference

O/o Chief General Manager, CITCO
SCO NO.121-122 Sector-17 B,
Chandigarh.

Issue of Clarifications

11.07.2025

Last Date for Submission of Bids
Online
Opening of Technical Bids

11.08.2025 upto 4:00 PM

Contact Person

Dy. General
Manager(Tech.)/Manager(EDP)

Contact Address and numbers
Website

SCO No. 121-122, Sector-17 B,
Chandigarh.
0172 4644430-39
info@citcochandigarh.com

e-Tendering Website

http://etenders.chd.nic.in

12.08.2025 at 10.00 AM

3

<!-- page 4 -->

3. INTRODUCTION
The Chandigarh Industrial and Tourism Development Corporation Limited
(CITCO) was incorporated as a Company under the Companies Act 1956 on
28.03.1974. It was originally known as Chandigarh Small Industries
Development Corporation (CSIDC) and started functioning as such from
20.09.1974. The Corporation was given additional functions of promotion of
Tourism and other related activists in the year 1982. As a result of which,
its name was changed to Chandigarh Industries and General Development
Corporation Limited.(CIGDC). CITCO Chandigarh is the list of Luxury hotels
around Chandigarh. Explore the best hotels in Chandigarh and get the best
deals.
In 1992, the Corporation was allotted land in Sector 9, Chandigarh for
setting up a Petrol Pump for which CITCO tied up with BPCL. The Petrol
Pump is running as one of the most preferred outlets in the City.
In 2000, Baithak Restaurant/ Banquet at Kalagram, Manimajra was set-up
by CITCO. The unit is designed as an ethnic Punjabi outlet. Thereafter, the
space for fast-food outlet “Stop-n-Stare” in the hub of the Sub-city Centre,
Sector 10, Chandigarh was allotted.
In 2009, Indian Oil Corporation Limited offered its Sector 56 Petrol Station
to CITCO for managing its operations w.e.f. 18th December, 2009. Later, in
2011, U.T Administration allotted space for setting up of Petrol Pump in
Sector 38 West. CITCO had set-up a Petrol Station and LPG outlet in
collaboration with Indian Oil Corporation Limited.
UNITS/OUTLETS OF CITCO
1. Head Office, Sector-17 B, Chandigarh.
2. Hotel Mountview, Sector 10, Chandigarh,
3. Hotel Shivalikview, Sector 17, Chandigarh,
4. Hotel Parkview, Sector 24, Chandigarh
5. Mermaid Restaurant, Sukhna Lake, Chandigarh.
6. Chef Lakeview Cafeteria & Boating at Sukhna Lake, Chandigarh.
7. Boat House Cafe, Sukhna Lake, Chandigarh.
8. The Chef Restaurants and Transit Lodge at ISBT, Sector 17,
Chandigarh
9. Baithak Restaurant & Banquet at Kalagram, Manimajra, Chandigarh
10. Petrol Pumps at Sector 9, 56, 38(W), 17, Raipur Kalan, Hallomajra &
Dhanas
11. Steel Depot – Distribution of Iron and Steel to SSI units
12. Managing SAIL’s stockyard as Consignment Agent
13. Industrial Development Cum Facility Centre (IDFC) to provide Testing
facilities SSI Units
4

<!-- page 5 -->

4.Scope of Work
Scope of work for a Bank can be described as follows: Collection of cash/cheques/Demand draft etc. received at functional
units of CITCO.
 Handling of such cash/cheques/drafts/online/digital receipts etc.
 Timely encashment of cheques/drafts/online/digital receipts etc.
 Supply, Commissioning and maintenance of point of sale swipe
machines (latest features) at each sole unit of CITCO.
 Providing Stand along dynamic QR Codes (as per site requirement).
 Handling the receipt of payment through debit and credit cards using
swipe machines at the sole unit /pumps of CITCO, and also the swipe
machines should be compatible with all kind of cards(VISA,
MasterCard, RuPay, American Express etc)
 Rendering of online payment facility to customers/ depositor with
option of paying through Internet banking, debit cards, credit card,
digital wallets, etc. Selected bank would be required to provide online
payment gateway on non-exclusive basis.
 Timely reporting about the success and dishonored and bounced
cheques/Demand Drafts to the concerned CITCO Unit and
cheque/demand draft holder. If any delay in clearing of cheque/DD
due to banking reason, the bank will deposit the same amount within
time.
 Timely transfer of funds to the specific bank accounts of CITCO and
private entities.
 Maintain separate accounts under separate receipts/heads/accounts
and providing its online access to all participating agencies for greater
transparency.
 Establishment of ATMs at designated Units of CITCO for ensuring
Banking Services. The selected banking partner will have to pay rent
@INR 15,000 per month for each ATM, with an annual rental
increment @10% on previous year Rent. The space may be allotted to
some other bank to set up ATMs, however selected banking partner
will have first right of refusal.
 Deployment of dedicated team for timely interaction with CITCO.
 Timely Reconciliation of all financial transactions with CITCO.
 The Bank has to provide a certificate of settlement of reconciliation for
all types of transactions by 5th of every month. The Bank to circulate
the report of settlement of reconciliation and conduct a monthly
meeting by 10th of every month with all stakeholders and resolve any
grievances if any.
 The Bank has to nominate a Single Point Contact for coordination
with CITCO for all matters- admin, accounting, technical, etc.

5

<!-- page 6 -->

 CITCO will not pay any charges to selected Banking partner for online
and off-line transaction/services to be offered by the Bank. Selected
Banking partner has to provide payment gateway services (for online
payment services) without any MDR or any kind of charges.
 The selected Banker needs to provide integration/implementation/
maintenance support for Bharat Bill Payment System Agent
Institution services for all CITCO web portal/Mobile App without any
cost (CITCO will not pay any cost).
 Bank to provide what percentage of commission it would offer to
CITCO for payment collection under BBPS Agent Institution services/
any other platform. Preference will be given to banker, offering
maximum revenue/commission sharing % to CITCO under BBPS
Agent Institution/any other platform.
 Preference
will
be
given
to
banker,
offering
maximum
revenue/commission sharing % to CITCO under Bank Agent
commission paid by RBI per transaction.
4.1 Proposed Procedure
Based on the As Is process and requirements of CMS Project the following
process could be followed for Money Collection, Online Collection, Transfer
and Bank Reconciliation.
Money Collection Process
 Customers avail services at CITCO Hotels, Restaurants, Petrol Pumps
etc. and make the payment for the services.
 Modes of payment-Cash/Cheque/DD/PO/Debit & Credit card payment
using swipe machines.
 The operator collects the payments and acknowledgement receipt is
given to the customers. This acknowledgement receipt/cash memo/Bill
records the department/organization name and the purpose (i.e. the
service availed etc.). The receipt for acceptance of Cheque shall be issued
as 'subject to realization'.
 The selected Bank shall collect all the cash/cheques/DD accumulated
at the Units of CITCO on the same day. This is to be done once a day,
starting from 10 AM from each Unit of CITCO along with the MIS
reports(which includes debit and credit card transactions) to be
prepared and generated by Accounts Clerk at each Unit of CITCO.
Online Collection Process
 Depositors will login to CITCO (http://citcochandigarh.com/) and will
choose the option that he/she wishes to apply pay for and fill in certain
personal information like name, address, etc. as required by CITCO for
initiating the payment. On completion of the details, Customers shall be
provided with options to make payment for the requisite amount
6

<!-- page 7 -->

through Payment Gateway Services provided by the selected banking
partner.
 The depositor should be provided e-Receipt for the amount deposited by
him/her.
Money Transfer Process
 The Bank will transfer the total amount of successful transactions (as
per the MIS) to the designated bank accounts, alongwith requisite MIS
reports.
 All the Cash is to be deposited by the Bank in the bank account as the
case may be and cheques/DD/other sent for realization.
 The Bank to transfer the money collected in to the respective bank
accounts of other Organizations Institutes as follows:
 Cash & Debit Card: T+1 (T is date of transaction / settlement)
 Cheque & Credit Card:T+3 (T is date of transaction/settlement)
 The Bank to automatically segregate the Cash as well as money collected
through debit and credit cards.
 A copy of the receipt scrolls shall also be sent to the CITCO Units and a
copy also to be retained by the Bank. The scrolls will contain the details
of the transactions including the CITCO Units name, the service availed
and all other details as per prescribed challan.
 Details of the transactions for which the cheque/DD etc. has been
bounced is to be updated to concerned CITCO unit.
Reconciliation Procedure (VDMS)
 The Bank to send report for collection and deposits to the concerned
CITCO unit on a daily basis.
 In case of bounced cheques, intimation is to be sent to the respective
concerned CITCO unit for updating the payment status and for taking
necessary actions.
 An intimation about success/ bounced cheques to be send to the
respective cheque holder.
4.2 Features of the Payment Service (online, manually and via Swipe
machines)
The payment Service should have the following features 4.2.1

Authorization

Any transaction made with a debit or credit card via swipe machines and
online must first be authorized by the card issuing authority. The service
must afford a secure link between CITCO and card processor to avoid
fraudulent transactions. The secure line should also ensure fast and
Customer efficient transaction processing.

7

<!-- page 8 -->

4.2.2 MIS and other reports
The MIS provided to CITCO Units should include customer Account no.,
amount paid, transaction ID, date, time and payment mode(e.g. debit card
and credit card). The MIS reports to be submitted by the Bank shall be
finalized with the CITCO on fortnightly basis.
4.2.3 Availability
The payment Service via swipe machines and online payment gateway
should facilitate multiple users making transactions from various locations
at a single point of time. Hence, the Service must support unlimited or a
reasonably large number of user access. Service unavailability resulting
from loss of network availability can be excluded from service availability
calculations if the network availability loss is caused by any factors beyond
the Bank's control, such as natural disasters or end user's portion of the
network failure.
4.2.4 Data Backup
The Bank shall make regular backups of payment transactions related data
via swipe machines. The Bank shall make backups available to authorized
personnel of the CITCO.
4.2.5 Maintenance
Scheduled Maintenance: The Bank shall specify the basis for scheduled
maintenance causing/or not causing disruption to provided electronic
payment service via swipe machines and online payment gateway.
Disruption of service due to scheduled maintenance is to be excluded from
service up time (availability) calculations provided that CITCO is notified.
Maintenance shall be performed during off-peak hours and the Bank shall
always provide advanced notice of scheduled maintenance to CITCO.
Emergency Maintenance: The Bank shall specify the reasons for
performing emergency maintenance (Example: security related issues). The
Bank shall notify immediately the CITCO regarding the emergency
maintenance. Un-notified service unavailability due to emergency
maintenance will be included in the service downtime calculations.
4.2.6 Auditing
All Bank records related to payments with respect to consumer shall be
available for inspection and auditing by CITCO or other authorized
representatives. The Bank shall be acting to correct or remedy any audit
results within a time period agreed upon with the CITCO.
During the course of financial audit and at any time after the completion of
the transaction, in case of any discrepancies, the Bank will be liable to pay
CITCO the principal amount along with interest to be calculated at
8

<!-- page 9 -->

prevailing rate of PLR+2% from the date of the transaction till the date of
payment.
4.2.7 Information Accessibility
 The Bank shall provide access to payment information to specified users
and administrators authorized by the CITCO and CITCO using the
service on a timely basis in an accurate, understandable and logical
format.
 The Bank shall provide real time access to transaction data and MIS
support.
 The Bank shall not provide access of payment information to "any third
party" unless mutually agreed to with the CITCO or requested by legal
authority.
5. Roles and Responsibilities
5.1

Bank

1. Collection of cash/cheques/drafts from CITCO Units once daily from
10.00 AM onwards OR as mutually agreed upon.
2. Collection & Deposit of cash/money from any temporary CITCO Unit.
3. Provide information online on bounced cheques to customer as well as to
CITCO Units.
4. Provide minimum two dynamic swipe machines at each CITCO Units
along with required telephone lines for debit and credit card transactions.
The cost of telephone connectivity, consumables and infrastructure will
be borne by the Bank. The Bank also needs to take care of the uptime
and connectivity of the swipe machines and also the swipe machines
should be compatible with all kind of cards (VISA, Master Card, RuPay,
American Express etc)
5. Provide online payment services. Selected bank would be required to
provide online payment gateway on non-exclusive basis.
6. To setup ATMs at designated CITCO Units to facilitate the provision of
the Banking Services. The installation, operations, maintenance
(including energy charges), security etc. will be sole responsibility of the
Bank. The selected banking partner will have to pay rent @INR 15,000per
month for each ATM, with annual rental increment @ 10% of previous
rate. The space can also be allotted to some other bank to set up ATMs
however, selected banking partner will have first right of refusal.
7. To set up a mechanism for the resolution of failed online transactions
and transactions using swipe machines.
8. Provide centralized application Software for Accounting & Data
Management for all the collections & provide related IT Hardware.
9. Provide at least one Currency counting and Fake note detection machine
at each CITCO Unit.
9

<!-- page 10 -->

10. The Bank would be responsible for reconciliation of funds collected
during a day through Online Transactions, Cash Collections and through
Swipe Machines at the CITCO Units and will further transfer the funds to
the Respective Bank account of CITCO Units. MIS for the same will also
be submitted by the Bank to the respective CITCO Units and Head Office.
Bank shall also highlight the discrepancies in case of mismatch between
funds collected and the number of transactions done. Bank shall be
responsible for transferring the funds through online transactions made
via the Payment Aggregator to the Bank (in cases where payment
aggregator services are being provided by entity other than selected
banking partner).
11. The Bank shall ensure compliance with latest international information
security standards like ISO 27001.
12. The Bank shall ensure that all the information and/or data obtained by it
from client/customers are stored securely and equipped with reasonable
precautions against damage.
13. Provide online access to the CITCO with respect to all transactions done
by the Bank on CITCO's behalf.
14. The Bank shall be responsible for maintaining the confidentiality of all
the transactions conducted on behalf of the CITCO.
15. The Bank shall preserve all the records pertaining to money collection &
deposit and be able to produce the same whenever required.
16. Application Development (this would include either upgrading the
existing application or developing a new one) & Implementation (Digital
Signature Certificates, Touch Screen Panels, Mobile, Electronic Token
System).This should be compliant with its respective standards.
 Generate MIS for stakeholders
 Portal Design and Development
 Integration of new e-Go initiatives with the CITCO Units.
17. Bank should take a complete backup of all the data and transactions on
a monthly basis and submit to Manager Accounts, CITCO Head Office.
18. Bank to tieup with Payment Aggregator for payment gateway to manage
the financial transactions that occur at the portal through Direct Debit,
Debit Cards, Credit Cards, Cash Cards, digital wallets, etc.
19. Provide reporting and MIS (including information and details regarding
bounced cheques on the same day) to the CITCO Units on a daily basis.
5.2

ROLES & RESPONSIBILITIES OF CITCO
As owner of the Project, the role of CITCO includes discharging the
following responsibilities:

1. Signing MoU/Agreements with the Bank for creating legal framework.
10

<!-- page 11 -->

2. Ensuring that the different CITCO Units are responsive to the needs of
the Banks.
3. Opening of new CITCO Unit/ Outlets and adding on more services.
4. Facilitating to set up ATMs at CITCO Units.
5. Provide physical space at the CITCO Units for swipe machines
(provided by the bank) for debit and credit card transactions and
ensure the application is integrated with the swipe machines.
6. Respective Head of CITCO/Unit shall coordinate with a Bank selected
by CITCO for collections at the CITCO Units (Cash, Swipe
machines)and complete reconciliation of all the transactions either
through Units or through Portal via Payment Aggregator. To handover
cash/cheque/drafts once a day at cach CITCO Unit, between 10:00
AM to 4:00 PM everyday to the Bank from every centre.
7. Provide physical space at the CITCO Units for swipe machines
(provided by the bank) for debit and credit card transactions and
ensure the application is integrated with the swipe machines.
8. Manager
Accounts (H.O.)/HMV,HSV,HPV
is the
authorized
representative of CITCO for financial transactions and is responsible
for reconciliation of transactions conducted through CITCO Units.
9. To conduct bipartite reconciliation of receipts with the Head Office
CITCO (at the CITCO Units and online portal) and with the bank (with
respect to the collection deposits in the Bank) on a daily basis.
10. To conduct financial audit with respect to financial transactions from
the CITCO Units.
11. To conduct reconciliation of bounced/dishonoured Cheques as well as
charge back transactions in case of refund transactions at CITCO
Units.
12. To keep record of transaction backup submitted by CITCO on daily
basis.
13. Manager Accounts, Head Office, Shall be responsible for maintain the
confidentiality of all the transactions conducted by it on behalf of
CITCO

11

<!-- page 12 -->

6.

Eligibility Criteria for Bidders

This invitation for bids is open to all Indian scheduled Commercial banks
that fulfill all the qualification criteria as specified in this section. The
Bidder shall be responsible to CITCO & for discharging of all responsibilities
related to the Bid finalization and implementation of project.
Qualification criteria for the participating bidders are as given below:

Bidder shall comply with the following qualification eligibility criteria for
getting short-listed in the Qualification round:

i.

The Bidder should be a scheduled commercial bank having operations
for the previous 10 financial years in the tricity comprising of
Chandigarh, Mohali and Panchkula cities.

ii.

The Bidder should be a profit-making bank with net profits after tax of
at least INR 700 Crores in each of the last 5 financial years preceding
the current financial year i.e. financial year ending 31.3.2024.

iii.

The Bidder should be handling cash collection services on behalf
Central Government/State Governments/Autonomous bodies/Board,
Corporation.

iv.

The Bidder shall have atleast 5 branches (excluding extension
counters) operational in U.T. Chandigarh as on 31.03.2024.

v.

The Bidder should have implemented core-banking solutions for their
internal operations.

vi.

The Bidder should be authorized by RBI for offering debit, credit &
other card transactions through swipe machines and also online
payment services.

12

<!-- page 13 -->

Requirement of Documents
The Table below gives the detail of the Documents that the bidder needs to
submit for its Qualification against each criteria on for qualifying for the
opening of Technical Bids.
Table-1
Sr.
No.
1.

Criteria

Reference Document

The Bidder should be a scheduled Self Certification by the Bidder
commercial bank having operations
for the last 10 financial years in the
tricity (defined as Chandigarh,
Mohali & Panchkula cities)

2.

The Bidder should be a profitmaking bank with net profits after
tax of at least INR 700 crores in each
of the last 5 financial years
preceding the current Financial year
i.e., ending 31.3.2024

3.

The Bidder should be handling Cash Copy of Authorization/work
Collection
Services
on
Central order by relevant organisation.
Government/behalf
of
State
Governments/
Autonomous
bodies/Board/Corporation or any
other Undertaking of either the
Central or State Government.

4.

Shall have at least 5 branches Self Certification by the Bidder
(excluding
extension
counters)
operational in the Chandigarh as on
31.03.2024

5.

The Bank should have implemented Self Certification by the Bidder
core banking solutions for their
internal Operations

6.

The Bidder should be authorized by Copy of authorization issued by
RBI for offering debit, credit & other RBI.
card transactions through swipe
machines and also online payment
services.

13

Relevant extract of Profit and
Loss certified/statements
attested duly by Chartered
Accountant having UDIN,

<!-- page 14 -->

7.

General Instructions for Bid Process

7.1

Pre-Bid Conference

CITCO will host a Pre-Bid Conference as per schedule given in Bid Data
Sheet. The purpose of the conference is to provide bidders with information
regarding the RFP and the proposed Project solution requirements, and to
provide each bidder with an opportunity to seek clarifications regarding any
aspect of the RFP and the Project. The bidders are requested to submit any
questions by email before the pre-bid conference at the email id as
mentioned in the Bid Data Sheet. The subject line of the mail should be: Pre
Bid Clarification Question for Selection of Banking partner for Bidder's
Company Name. CITCO will endeavor to provide a complete, accurate, and
timely response to all questions. However, CITCO makes no representation
or warranty as to the completeness or accuracy of any response, nor does
the CITCO undertake to answer all the queries that have been posed by the
bidders. All responses will be made available to all the bidders.
7.2

Site Visits

The Bidder at its own responsibility may visit any of the CITCO Unit for
reconnaissance and obtain information regarding the functioning of the
CITCO, services provided at these Units, IT infrastructure available,
functionality of the applications deployed etc. The costs of visiting the
CITCO Units or shall be at the bidder's own expense.
7.3

Supplemental Information to the Request for proposals

If CITCO seems it appropriate to revise any part of this RFP or to issue
additional data to clarify an interpretation of provisions of this RFP, it may
issue supplements to this RFP. Any such supplement shall be deemed to be
incorporated by this reference into this RFP which will be in the form of an
addendum hosted on our website. It would be the sole responsibility of the
bidders to regularly check the website for any such addendums as no
advertisement, written communication etc. will be issued in this regard. Any
change decided shall be uploaded on the e-Tendering system as
corrigendum (http://etenders.chd.nic.in)
7.4

Bid Preparation Costs

The bidder is responsible for all costs incurred in connection with
participation in the bid process, including, but not limited to, costs incurred
in conduct of informative and other diligence activities, participation in
meetings/discussions/presentations, preparation of bid, in providing any
additional information required by CITCO to facilitate the evaluation
process, and in negotiating a definitive Service Agreement and all such
activities related to the bid process. This RFP does not commit CITCO to

14

<!-- page 15 -->

award a contract or to engage in negotiations with any bidder. Further, no
reimbursable cost may be incurred in anticipation of award.
7.5

CITCO's right to terminate the Process

i. CITCO reserves the right to expand, alter, rescind, modify or annul
the terms of this RFP at any time without as signing any reason
CITCO makes no commitments, express or implied, that the bid
process will result in a business transaction with bidder.
ii. This RFP does not constitute an offer by CITCO.
7.6
Earnest Money Deposit (EMD)
i. The Bidders shall submit, alongwith their Bids, Earnest Money
Deposit of Rs. 10 lakh (Rupees Ten Lakh Only) in the shape of DD in
favour of MD CITCO payable at Chandigarh as per details mentioned
in Bid Data Sheet with validity of 180 days. The EMD in any other
form shall not be entertained. The EMD amount should be submitted
along with the qualification bid.
ii. The EMD of all unsuccessful bidders would be refunded by CITCO
within 60 days after the bid process is completed. The EMD of the
successful bidder would be adjusted towards partial fulfillment of the
Performance Guarantee.
iii. The bid without adequate EMD will be liable for rejection without
providing any opportunity to the bidder concerned.
iv. The EMD can be forfeited if a Bidder:
1. Withdraws its bid during the period of bid validity as specified
in the RFP.
2. During the bid process, if a Bidder indulges in any such
deliberate act as would jeopardise or unnecessarily delay the
process of bid evaluation and finalisation.
3. Violates any of such important conditions of this RFP document
or indulges in any such activity as would jeopardize the interest
of the client. The decision of the client regarding forfeiture of the
EMD shall be final & shall not be called upon question under
any circumstances.
7.7

Venue & Deadline for submission of bids

Bids must be submitted at the address and as per the schedule specified in
Bid Data Sheet.
CITCO may, in exceptional circumstances and at its discretion, extend the
deadline for submission of bids by issuing an Addendum which shall be
hosted on the website mentioned in the Bid Data Sheet, in which case all
rights and obligations of the proposed Project and the bidders previously
15

<!-- page 16 -->

subject to the original deadline wilt hereafter be subject to the deadline as
extended.
7.8

Late Bids

Bids received after the due date and the specified time for any reason
whatsoever, shall not be entertained.
7.9

Bid Opening

Total transparency will be observed while opening of bids. CITCO reserves
the right at all times to postpone or cancel scheduled Bid opening. The
venue and date and timing for the opening of bid is specified in Bid Data
Sheet of RFP. In the event of the specified date of bid opening being declared
a holiday, the bids shall be opened at the appointed time and location on the
next working day.
7.10 General Guidelines for bid opening
i.

Bids will be in two parts (qualification and technical) as indicated in
the RFP through e-Tendering process. There will be two bid-opening
events (a) for the qualifications and (b) for the Technical Bids.

ii.

CITCO will open the qualification bids and list them for further
evaluation. The Technical Bid' covers shall not be opened until the
evaluation of the qualification bid is complete.

iii.

The technical bids of only those bidders who qualify in the
qualification evaluation will be opened.

iv.

All the bids will be opened in presence of the bidder's representatives,
if present at the time of bid opening. However, if there is no
representative of any bidder, CITCO is entitled to still go ahead and
open the bid of the qualified representative.

16

<!-- page 17 -->

8.

Bid Instructions and Conditions

For the bidding process, the bidders shall upload bids at the eTendering website (http://etenders.chd.nic.in). For further details
about the e Tendering procedure and its requirements, refer Annexure
VII.
Tender offers shall be received by the Managing Director, CITCO through the
e- Tendering system before the time and date specified in the schedule of the
tender notice. In the event of the specified date for the submission of tender
offers being declared a holiday, the offers will be received upto the appointed
time on the next working day.
CITCO, at its discretion, extend this deadline for submission of offers by
issuing corrigendum and uploading the same on e-Tendering system.
Check List for the Pre-Qualification cum Technical Bid is placed at
Annexure- VIII
8.1

Documents comprising the bidder's bid

Bids submitted by the bidders shall comprise the following:
i.

Qualification bid alongwith the EMD

ii.

Technical bid

* The bids must be complete in all respects.
Qualification Bid
The qualification bid should contain document to evaluate that the bidder's
technical skill base and financial capacity are consistent with the needs of
the project and meets the qualification criteria as mentioned. The bid should
contain following:a. Cover letter, as per template in Annexure of the RFP
b. EMD
c. Compliance and Required documents as per the RFP
d. Citations are to be provided as per format given in Annexure.
8.2

Technical Bid
a. The technical bid should contain a copy of the presentation.
b. The presentation should address the following at the minimum:
i. Implementation methodology, project plan and implementation
schedule
ii. Project Management, reporting and review methodology
iii. Problem escalation methodology
17

<!-- page 18 -->

iv.
v.
vi.
vii.

Scalability & Performance
Operational environment
On-site Post Implementation Support Strategy
Key Deliverables(alongwith sample deliverables, wherever possible)

c.

CITCO is also open to any suggestions that the bidder may want to
render with respect to the approach adopted for the assignment in
the light of their expertise or experience from similar assignments.
However, this should not lead to the submission date being missed
or extended

*

The Technical bid shall address the following:
i. Cover letter, as per template in Annexure of the RFP
ii. Compliance and Required documents as per the RFP
iii. Understanding of the Project



Operations and their Challenges.
Understanding of the Scope of the Work

iv. Approach and Methodology
v. Project Plan
vi. Key Deliverables(alongwith sample deliverables, wherever possible)
8.3

Validity of Bid

The bid as submitted must be valid for acceptance for at least 180days from
the date of opening of bid, unless specified otherwise.
8.4

Amendment of Bidding Document

The requirements specified in this RFP reflect those presently known. CITCO
reserves the right to modify bidding documents by issuing addenda at any
time prior to the deadline for submission of bids, for any reason, whether at
its own initiative or in response to a clarification requested by a prospective
bidder.
8.5

Disqualification

a. The bid is liable to be disqualified in the following cases or incase
bidder fails to meet the bidding requirements as indicated in this RFP:
i.
ii.
iii.
iv.
v.
vi.

Bid not submitted in accordance with this document.
The Bidder submits the bid with its own conditions.
Bid is received in incomplete form.
Bid is received after due date and time.
Bid is not accompanied by all requisite documents.
Information submitted in technical bid is found to be misrepresented,
incorrect or false, accidentally, unwittingly or otherwise, at anytime
18

<!-- page 19 -->

vii.
viii.

ix.

during the processing of the contract (no matter at what stage) or during
the tenure of the contract including the extension period if any.
The Bidder tries to influence the bid evaluation process by unlawful
means at any point of time during the bid process.
In case anyone party submits multiple bids or if common interests are
found in two or more bidders, the bidders are likely to be disqualified,
unless additional bids/bidders are withdrawn upon notice immediately.
In case the selected Bidder fails to deposit the Performance Bank
Guarantee (PBG) within 15 working days of the issue of the Work Order
or within such extended period by CITCO but before the execution of the
contract. The EMD shall be forfeited, bidder shall be blacklisted.

b. Bidders may specifically note that while evaluating the bids, if it comes
to CITCO’s knowledge expressly or implied, that some bidders may have
compounded in any manner whatsoever or otherwise joined to form an
alliance resulting in delaying the processing of bid then the bidders so
involved are liable to be disqualified for this contract as well as for a
further period of two years from participation in any of the bids floated
by CITCO. It is also clarified that if need arises CITCO would go in for
appointment of outside party(s) to undertake the work under the
captioned bid.
8.6

Modification and Withdrawal of Bids

No bid may be withdrawn in the interval between the deadline for
submission of bids and the expiration of the validity period specified
by the bidder on the bid form. In case any Bidder withdraws its bid
before the completion of the evaluation process, the EMD submitted
alongwith the bid will be liable to be forfeited.
8.7

Conflict of Interest

CITCO requires that the bidder must provide professional, objective,
and impartial advice and at all times hold CITCO’s interests
paramount, strictly avoid conflicts with other assignments/ jobs or
their own corporate interests and act without any consideration for
future work. In case the bidders have any subsisting interest, either
by themselves or through their partners, that is likely to conflict the
work specified in the Scope of Work, they shall declare such interests
as part of their proposal.
8.8

Acknowledgement of Understanding of Terms

By submitting a bid, each bidder shall be deemed to acknowledge that
it has carefully read all sections of this RFP, including all forms,
schedules and annexure hereto, and has fully inform edit self as to all
existing conditions and limitations.
19

<!-- page 20 -->

8.9

Conditions

The following terms are applicable to the RFP and the bidder’s bid.
i. Any work product, whether acceptable or unacceptable, developed
under a contract awarded as a result of this RFP shall be the sole
property of CITCO unless stated otherwise in the definitive service
agreement.
ii. Timing and sequence of events resulting from this RFP shall
ultimately be determined by CITCO.
iii. No oral conversations or agreements with any official, agent, or
employee of CITCO shall affect or modify any terms of this RFP,
and any alleged oral agreement or arrangement made by a bidder
with any department, agency, official or employee of CITCO shall be
superseded by the definitive service agreement that results from
this RFP process. Oral communications by CITCO to bidders shall
not be considered binding on CITCO, nor shall any written
materials provided by any person other than CITCO.
iv. Bids are subject to rejection if they limit or modify any of the terms
and conditions or specifications of this RFP.
v. By responding, the bidder shall be deemed to have represented and
warranted: that its bid is not made in connection with any
competing bidder submitting a separate response to this RFP, and
is in all respects fair and without collusion or fraud; that the
bidder did not participate in the RFP development process and had
no knowledge of the specific contents of the RFP prior to its
issuance; and that no employee or official of CITCO participated
directly or indirectly in the bidder’s bid preparation.
vi. Neither the bidder nor any of bidder’s representatives shall have
any claims whatsoever against CITCO or any of its respective
officials, agents, or employees arising out of or relating to this RFP
or these procedures (other than those arising under a definitive
service agreement with the bidder in accordance with the terms
thereof).
vii. Until the contract is awarded, bidders shall not, directly or
indirectly, solicit any employee of CITCO to leave CITCO or any
other officials involved in this RFP process in order to accept
employment with the bidder, its affiliates, actual or prospective
consortium members, or any person acting in concert with the
bidder, without prior written approval of CITCO.

20

<!-- page 21 -->

9.

Bid Evaluation Process

Bids will be reviewed by the Bid Evaluation Committee appointed by CITCO.
Evaluation of the bids will be done in two stages and at the end of first stage
shortlisted bidders will be informed of the result to have a fair and healthy
competition. The following is the procedure for evaluation.
9.1

Evaluation of Qualification Bids

a. The documentation furnished by the bidder will be examined to see if
they are consistent with the requirements of this project and meet the
qualification criteria as specified above in this RFP.
b. The Bid Evaluation committee may ask bidder(s) for additional
information and/or arrange discussions to verify the claims made in
bid documentation.
c. Any bid not complying with the requirements of the qualification
criteria will not be processed further.
9.2

Evaluation of Technical Bids

The technical bids of only those bidders, who qualify in the evaluation of the
qualification bids, shall be opened.
1. The technical bids are evaluated as per the requirements
specified in the RFP and adopting the evaluation criteria given
below. The Bidders are required to submit all required
documentation in support of the evaluation criteria and as
mentioned in this RFP.
2. The Bid Evaluation committee may ask bidder(s) for additional
information and/or arrange discussions to verify the claims
made in bid documentation.
3. Based on the evaluation methodology mentioned below, each
Technical Bid will be evaluated on a score of a maximum of 100
marks and only those bids whose score is more than 70
(Seventy) marks shall be considered.
4. The Bidder scoring maximum marks out of a total of 100 marks
(after crossing the threshold of 70 marks) shall qualify for the
award of the project by CITCO. In case of more than one bidder
scoring same maximum marks CITCO reserves the right to
choose the successful bidder by draw of lots.

21

<!-- page 22 -->

Technical Evaluation
Sr.No. Evaluation Criteria

Numbers

Marks

1.1

Relevant Experience

1.2

The Bidder should be
handling Cash Collection
Services on behalf of State
Governments/Autonomous
Bodies
/Board/Corporation or
any other Undertaking of
either the Central or State
Government at the time of
last date of bid.
Number of branches of the
Bank in Tricity (defined as
Chandigarh, Mohali &
Panchkula cities) (self
Declaration to be
provided).
Experience of providing
online payment gateway
services along with
success rate self certified
report (Bank has to
provide work order(s) in
support of each Project).
Providing of Application
Software and Hardware for
any Govt./State
Govt./Board/Autonomous
Corporation etc. (self
certification by bidder)

None
1-2 projects
3-4 projects
>=5 projects
Max.Marks

0
5
10
20
20

0-4
branches
5
6-10
>=10
Max.Marks
0
1-3 projects
3-5
>=5
Max.Marks

0
5
10
20
20
0
5
10
20
20

0
1-2 projects
3-4
>=4
Max.Marks

0
5
10
20
20

Financial Cost involved in
implementation of
Project(s) as mentioned at
1.5 (self certified by bidder)

10-50 lacs
51-1.00 cr.
1.01-5.00
cr.
>=5.01 cr.
Max.Marks

0
5
10

1.3

1.4

1.5

1.6

100

22

20
20

Compliance

<!-- page 23 -->

9.3 Contract Finalization and Award
If CITCO is unable to finalize a service agreement with the bidder ranked
first, CITCO may proceed to the next ranked bidder, and so on until a
contract is awarded. The Managing Director, CITCO reserves the right to
present a contract to the bidder selected for negotiations or not to award the
contract at all. The contract will be awarded to the responsible, responsive
bidder whose bid conforms to the RFP and is, in the opinion of CITCO, the
most advantageous.
Evaluations will be based on the bids, and any additional information
requested by CITCO.
9.4

Awarding of Contract

CITCO will award the Contract to the successful bidder for a period 10
years. The period of 10 years will start from date of signing of the agreement.
9.5

Notification of Award

Before the expiry of the period of bid validity period prescribed in the RFP,
CITCO will notify the successful bidder/bank, in writing or by fax or email,
to be confirmed in writing by letter, that its bid has been accepted. Upon the
successful bidder's furnishing of performance guarantee deposit, and
signing of contract, CITCO will notify the other banks that their bids have
been unsuccessful.
9.6

Signing of Contract

When CITCO notifies the successful bank that its bid has been accepted,
CITCO will send the bank the Form of Contract Agreement in corporating all
agreeable terms between the parties. The successful bank shall sign and
execute the contract agreement failing which acceptance of his bid shall be
cancelled and his earnest money will be forfeited.
9.7

Performance Bank Guarantee
a)

b)

The successful bidder shall at his own expense deposit with
CITCO, within fifteen (15) working days of the issue of work order
or prior to signing of the contract whichever is earlier, a confirmed
unconditional and irrevocable Performance Bank Guarantee (PBG)
for the due performance and fulfilment of its contractual
obligations by the bidder.
This Performance Bank Guarantee off Rs.5.00 Crore (Rupees Five
Crore Only) should be provided by the successful bidder. This PBG
shall be sourced from other scheduled Bank i.e. Bank who is
successful shall not provide PBG from its own Bank All incidental
charges whatsoever such as premium, commission etc. with
respect to the issuance of the performance bank guarantee shall be
23

<!-- page 24 -->

c)

9.8

borne by the bidder. The performance bank guarantee shall be
valid for 123 months from signing of the agreement. The
performance bank guarantee may be discharged/returned by
CITCO upon being satisfied that there has been due performance of
the obligations of the bidder under the contract. However, no
interest shall be payable on the performance bank guarantee.
In the event of the bidder being unable to service the contract for
whatever reason, CITCO would evoke the PBG. Notwithstanding
and without prejudice to any rights whatsoever of CITCO under the
contract in the matter, CITCO shall invoke the PBG by giving notice
to the bank issuing the PBG for invoking the same, the proceeds of
the PBG shall be paid to CITCO as compensation for any loss
resulting from the bidder's failure to perform/comply with its
obligations under the contract. CITCO shall notify the bidder in
writing of the exercise of its right to invoke the PBG within 14 days
of the invocation thereof, indicating the contractual obligation(s) for
which the bidder is in default.

CITCO's Right to Accept any bid

CITCO reserves the right to accept or reject any bid and to annul the bidding
process and reject all bids, at any time prior to award of Contract without
thereby incurring any liability to the affected bidder or any obligation to
inform the affected bidder of the reasons for its action.
9.9

Special Powers of termination

If at any time after the acceptance of the bid, CITCO shall for any reason
whatsoever not require the whole or any part of the work, to be carried out,
CITCO shall give notice in writing to the fact to the Bank who shall have no
claim to any payment of compensation or otherwise howsoever on account of
any profit or advantage which he might have derived from the execution of
the work in full but which he did not derive in consequence of the for closing
of the work.
9.10 Indemnity of CITCO against any fraud or failed transaction
CITCO stands indemnified against any fraud or failed transactions. The
bank must take care and rectify consumer complaints regarding fraud or
money being debited inspite of unsuccessful transaction.
9.11 Force Majeure
If at any time during the continuance of the work the performance in whole
or in part by either party of any obligation under this contract, shall be
prevented or delayed by reasons, of any war, hostility, acts of public enemy,
Civil Commotion, sabotage, floods, explosion, epidemics, fires or other acts
of God, strikes and lockout (hereinafter referred to as 'eventualities') then,
24

<!-- page 25 -->

provided notice of the happening of any such eventuality is given by either
party to the other within 15 days from the date of occurrence thereof,
neither party shall by reason of such eventuality been titled to terminate
this contract nor shall either party have any claim for damages against the
other in respect of such non-performance or delay in performance and
construction of work under this contract shall be resumed as soon as
practicable after such eventuality has ceased. Appropriate extension in time
of completion shall be granted.
9.12 Completion of contract
The contract shall be considered as successfully completed on fulfillment of
following conditions:
a) Successful running & operation of the project for specified period of 10
years.
b) Money & required data have been transferred to CITCO.
9.13 Action where no explicit specifications mentioned in the RFP.
In the case of any class of work for which there is no such specification
mentioned in the contract, such work shall be carried out in accordance to
specifications as decided by CITCO
In case of any conditions not covered specifically under this contract, the
standard terms and conditions of the Regulation of CITCO governing such
contracts will be applicable.
9.14 Termination
Either party can terminate the agreement by giving 12 months written
notice to the opposite party. The notice period would begin from receipt of
the notice.
9.15 Exit Options
The bidder's tenure ends after 10 year from acceptance of contract.




If CITCO chooses to discontinue with the existing bank after the end
of his tenure The bid process for the selection of new bank will commence
before the end of his tenure.
If CITCO chooses to continue with the existing bank after the end of
its tenure CITCO can choose to extend the contract with the same bank
for a period mutually agreed. The bank must continue on the
same Terms & Conditions as mutually agreed upon in this
contract.
 CITCO can initiate fresh RFP for the selection of bank.
25

<!-- page 26 -->

9.16 Mediation Clause
If at any time any question, dispute or difference, whatsoever, shall arise
between CITCO and the selected banking partner, upon or in relation to, or
in connection with the Contract, either party may forthwith give to the other
party, notice in writing of the existence of such question, dispute or
difference and the same shall be referred to Chairperson, CITCO for
mediation. Any statutory amendment, modification or re-enactment thereof
for the time being in force shall be deemed to apply to and be incorporated
in the Contract. The work under the Contract shall, if reasonably possible,
continue during the mediation proceedings and no payment due or payable
to CITCO shall be withheld on account of such proceedings.
9.17 Jurisdiction
Jurisdiction for filing any suit in case of any dispute shall be Chandigarh
only.

26

<!-- page 27 -->

10.

Service Level Agreements

Sr.
No.

Parameters

1.

2.

3.

4.

5.

Norms

Penalty

Money
Collection 10:00 AM to 4:00
PM
Process
The
collection
time
punching at the CITCO
Units
will
be
the
responsibility
of
the
Bank
Debit Card &
Money Deposit Process i.
Cash = Day T+1
ii. Credit Card &
Cheque/D.D.=
Day T+3

INR 1.00 Lakh
Rupees One Lakh
Only) per unit for
first hour and
INR 1.00 Lakh
per unit for every
next half an hour
Transaction
amount+ Per day
2%
of
the
transaction
amount

Reconciliation
Process-Transactions
should be reconciled by
Bank with and CITCO

INR10,000/transaction/day

i. Day T (for
transactions at
CITCO Units)
ii. Day T+1(for
online
transactions)
Bounced
Cheque Day T+ 4
Information and return
of instrument to the
concerned Department
as well as Cheque holder
Transaction settlement i. Debit Card =
Day T+1
via swipe machines
ii. Credit Card =
Day T+3

Value of each
bounced cheque
per day
Transaction
amount + Per day
2% of the
Transaction
amount

Miscellaneous
7.

Any mis-reporting on
the part of Bank

24 hours after pick
up

8.

Downtime of Fake
currency detector

At the point of pick
up

9.

Downtime of swipe
machines

24 hours

27

Transaction
amount+ Per day
2% of the
transaction
amount
Face value of
currency after
pick up from
CITCO unit
INR 1000 per
hour after 1 day

<!-- page 28 -->

11.

Annexures
11.1 Annexure I- List of CITCO Units

S.No

Name of Unit

Address

1.

Hotel Mountview,

Sector 10, Chandigarh

2.

Hotel Shivalikview,

Sector 17, Chandigarh

3.

Hotel Parkview,

Sector 24, Chandigarh

4.

Chef Lakeview Cafeteria & Boating

5.

The Chef Restaurants and Transit
Lodge

Sukhna Lake,
Chandigarh
ISBT, Sector 17,
Chandigarh

6.

Petrol Station,

Sector-17, Chandigarh.

7.

Petrol Station,

Sector-9, Chandigarh

7.

Petrol Station,

Sector-38 W,
Chandigarh.

8.

Petrol Station,

Sector-56, Chandigarh.

9.

Petrol Station,

Raipur Kalan, Indl.Area,
Chandigarh.

10.

Petrol Station,

Dhanas, Chandigarh.

11.

Petrol Station,

Hallomajra, Chandigarh

28

<!-- page 29 -->

11.2 Annexure II – Reconciliation Reports.
RECEIPTS
Dat
e

Cash
receive
d

Deman
d
Draft

Cheques
received
/
cleared

Amoun
t
receive
d
throug
h
POS
Machin
e or QR
Code

Amount
received
through
Debit/Cred
it
Card

Amoun
t
receive
d
online

Tota
l

Transaction
al Amount
at the
counters

Transaction
al Amount
through
swipe
machines
and portal

Total
Transaction
al Amount

NOTE : POS Machine details as per TID/MID Nos.

PAYMENTS
S.No.

Date of
Payment

Party Name

UTR No.

29

Amount paid

Variatio
n

<!-- page 30 -->

11.3 Annexure III – Format for Qualification Bid Letter

To
Managing Director
CITCO
Respected Sir/Madam,
Ref: Request for Proposal (RFP): Selection of Banking Partner for CITCO
Units.
We, the undersigned, apply to be qualified for the above referred Project and
declare the following:a)
b)

We have examined and have no reservations to the Qualification
Document.
We understand that you may cancel the qualification process at
anytime and that you are not bound either to accept any application
that you may receive or to invite the qualified applicants to bid for the
contract(s) subject of this qualification, without incurring any liability
to the Applicants.

Dated (Signature)

(In the capacity of)
Duly authorized to sign the RFP Response for and on behalf of:
(Name and Address of Bank) (Seal/Stamp of bidder)

30

<!-- page 31 -->

11.4 Annexure IV-Format for Technical Bid Letter
To
Managing Director,
CITCO
Respected Sir/Madam,
Ref: Request for Proposal (RFP) for selection of Banking Partner for
CITCO Units
Having examined the RFP documents, the receipt of which is hereby duly
acknowledged, we, the undersigned, offer to provide the services as required
and outlined in the RFP for selection of Banking partner for CITCO Units
Project.
We attach here to our response to the RFP document, which constitutes our
bid for being considered for appointment as Bank
If our bid is accepted, we will submit a Performance Bank Guarantee issued
by a Nationalized/ Scheduled bank in India, acceptable to CITCO, as per the
details specified in the RFP documents for due performance of the contract.
We agree to abide by our offer for a period of 180 days from the last date of
submission of bid prescribed by CITCO and that we shall remain bound by a
communication of acceptance within that time.
We have carefully read and understood the terms and conditions of the bid
and the conditions of the contract applicable to the bid. We agree to
unconditional acceptance of all the terms and conditions set out in the RFP
documents.
We confirm that the information contained in this bid or any part thereof,
including its exhibits, schedules, and other documents and instruments
delivered or to be delivered to the CITCO is true, accurate, and complete.
This bid includes all information necessary to ensure that the statements
therein do not in whole or in part mislead CITCO as to any material fact."
It is here by confirmed that I/We are entitled to act on behalf of our bank
and empowered to sign this document as well as such other documents,
which may be required in this connection.
Dated
(Signature)
(In the capacity of)
Duly authorized to sign the RFP Response for and on behalf of:
(Name and Address of Bank)

(Seal/Stamp of bidder)
31

<!-- page 32 -->

11.5

Annexure V- Format for Citations

For each of the projects, please provide a profile based on the following
template.
S.No.
Information Sought
Details
Customer Information
1.
Customer Name
2.
Name of the contact person
from the client organization
who can act as a reference
with contact coordinates:
 Name
 Designation
 Address
 Phone Number
 Mobile Number
 Email ID
Project Details
3.
Project Title
4.
State Date/End Date
5.
Current Status (In
Progress/Completed)
6.
Number
of
responding
firm’s staff Deployed on this
project (peaktime)
Value of the Project
7.
Order value of the project
(in rupees lacs)
8.
Narrative
description
of
project:
Highlight
the
components/services involved in the project that are of similar
nature to the project for which this RFP is floated.
9.
Description of actual services provided by the responding firm
within the project and their relevance to the envisaged
components/services involved in the project for which this
RFP is floated.
10.
Description of the key areas where significant contributions
are made for the success of the project.

32

<!-- page 33 -->

11.6 Annexure VI-e-Tendering Guidelines
The Agencies shall submit their tenders online in electronic format and
with digital signatures for participation in the e-tendering process. The
Agencies
need
to
register
themselves
on
the
website
http//etenders.chd.nic.in.
For clarification and necessary information on the process to obtain
digital
signatures,
the
Agencies
are
required
to
visit
www.cca.gov.inandwebsitehttp//etenders.chd.nic.in
Instructions to the Agencies regarding e-tendering process:a. The tenders shall be received electronically through the website
http//etenders.chd.nic.in with digital signatures. Tenders without
digital signatures will not be accepted by the Electronic Tendering
System.
b. Before submission of online tenders, Agencies must ensure that scanned
copies of all the necessary documents including Tender Security (EMD)
have been uploaded with the Tender within the time limit as specified in
the tender document. The documents to be submitted by the Agencies,
as specified in the tender document, could be scanned in low resolution
(75-100DPI), and in gray scale. The PDF so prepared by the Agencies
could be shrunk in size and then uploaded by the Agencies. In case of
any technical problem, the Agencies are required to contact the
Sh.Neeraj Raheja, Manager(EDP), 2nd Floor, CITCO Building, SCO
No.121-122, Sector-17 B, Chandigarh on -0172-4644439
c. It will be mandatory for all the Agencies to upload all the documents as
required in this tender document.
d. The tender shall be uploaded in 2covers:i. Cover1:-Pre-Qualification details at section 8: Bid Instructions &
Condition, otherwise the bid will be rejected summarily. It shall
also contain all the detailed documents as specified in the tender
document.
II. II. Cover2:-Technical Bid. As specified in the tender document, the
cover 2 of those Agencies shall only be opened whose cover No.1 is
found to be order and qualify for technical evaluation as per
evaluation criteria mentioned in the RFP.
e. CITCO will not be responsible for any delay in online submission of the
tenders due to any reason whatsoever.
f. Tenders will be opened online as per the time schedule as stated in this
tender document.
g. CITCO reserves the right to verify the particulars furnished by the
Agency independently. If any information furnished by the Agency is
found incorrect at a later stage, the Agency shall liable to be debarred for
future bidding in CITCO.
33

<!-- page 34 -->

h. All disputes concerning in any way with this project are subjected to
Chandigarh Jurisdiction only.
i. Corrigendum/Addendum to this tender, if any, will be uploaded on the
website http//etenders.chd.nic.in. This may be noted by the Agency.
j. Conditional bids, bids without processing fee will be rejected without
assigning any reason.
k. In case, the date of receipt/opening of bid is declared or happens to be a
public holiday. The bids will be received/ opened on the next working
day at the stipulated time.
l. For any Technical issue related to Electronic Tendering Portal Bidders
may contact Sh.Neeraj Raheja, Manager(EDP), 2nd Floor, CITCO
Building, SCO No.121-122, Sector-17 B, Chandigarh on 0172-4644439
11.7 Annexures VII- Indicative checklist
Document Name
Earnest Money Deposited
Covering letter-Qualification
letter-Annexure III
Covering letter- Technical
Letter- Annexure IV

Document Attached (Yes/No)
Scanned Copy
Bid Scanned Copy
Bid Scanned Copy

34

<!-- page 35 -->

11.8

Pre-Qualification Assessment

Sr.
No.

Criteria

Reference
document

1.

The Bidder should be as
scheduled commercial bank
having operations for the
last 10 financial years in
the tricity (defined as
Chandigarh,
Mohali
&
Panchkula cities)
The Bidder should be a
profit making bank with net
profits after tax of atleast
INR 700 crores in each of
the last 5 financial years
preceding
the
current
financial year i.e. for yearly
ending 31.03.2024.
The Bidder should be
undertaking
Treasury
banking
operations
on
behalf of either the Central
Government or any of the
State Governments. This
shall
not
include
the
management of account of
any Board, Corporation or
any other Undertaking of
either the Central or State
Government.
Shall
have
atleast
5
branches
(excluding
extension
counters)
Operational in Chandigarh
as on 31.03.2024
The Bank should have
implemented core banking
solutions for their internal
Operations
The Bidder should be
authorized by RBI for
offering debit, credit &
other card transactions
through swipe machines
and Also online payment
services.

Self Certification by
the Bidder

2.

3.

4.

5.

6.

35

Document
Attached
(Yes/No)&
Page No.

Relevant extract of
Profit
and
Loss
statements(Duly
certified/attested by
Chartered
Accountant)
Copy
Authorization

of

Self-Certification by
the Bidder

Self-Certification by
the Bidder
Copy
Authorization

of

<!-- page 36 -->

11.9 Technical Criteria
Sr.
No.

Evaluation Criteria

1.
1.1

Relevant Experience
Experience in providing similar services
(Bank has to provide work order(s) in
support of each project)
The Bidder should be handling Cash
Collection Services on behalf of State
Governments/Autonomous
Bodies/Board/Corporation or any other
Undertaking of either the Central or State
Government at the time of last date of
bid.
Number of Branches of the Bank in the
Tricity (defined as Chandigarh, Mohali &
Panchkula cities) (self Declaration to be
provided)
Number of ATMs in the Tricity(defined as
Chandigarh, Mohali & Panchkula cities)
(self Declaration to be provided)
Experience of providing online payment
gateway services along with success rate
self certified report (Bank has to provide
work order(s) in support of each project
Providing of Application Software and
hardware for any Government/ State
Government./Board/Autonomous
Corporation etc.

1.2

1.3

1.4
1.5

1.6

Document
Attached (Yes/No)&
Page No.

36
